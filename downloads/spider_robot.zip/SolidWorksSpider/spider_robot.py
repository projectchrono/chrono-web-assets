# PyChrono script generated from SolidWorks using Chrono::SolidWorks add-in 
# Assembly: D:\files\CAD\spider_robot\spider_robot_CAD\SPIDER_ROBOT.SLDASM


import pychrono as chrono 
import builtins 

shapes_dir = 'spider_robot_shapes/' 

if hasattr(builtins, 'exported_system_relpath'): 
    shapes_dir = builtins.exported_system_relpath + shapes_dir 

exported_items = [] 

body_0= chrono.ChBodyAuxRef()
body_0.SetName('ground')
body_0.SetBodyFixed(True)
exported_items.append(body_0)

# Rigid body part
body_1= chrono.ChBodyAuxRef()
body_1.SetName('Part3^SPIDER_ROBOT-1')
body_1.SetPos(chrono.ChVectorD(-0.620670357955037,1.94456417249918,0.727403113437383))
body_1.SetRot(chrono.ChQuaternionD(1.74574066942157e-15,1,0,0))
body_1.SetMass(1472.20792264893)
body_1.SetInertiaXX(chrono.ChVectorD(1948.56933336626,2184.15530557198,283.239773065818))
body_1.SetInertiaXY(chrono.ChVectorD(-1.01016366504143e-05,0.000194532690180911,5.83016939382041))
body_1.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.200000019877454,0.0526986503540632,1.84480172081189),chrono.ChQuaternionD(1,0,0,0)))
body_1.SetBodyFixed(True)

# Visualization shape 
body_1_1_shape = chrono.ChObjShapeFile() 
body_1_1_shape.SetFilename(shapes_dir +'body_1_1.obj') 
body_1_1_level = chrono.ChAssetLevel() 
body_1_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_1_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_1_1_level.GetAssets().push_back(body_1_1_shape) 
body_1.GetAssets().push_back(body_1_1_level) 

exported_items.append(body_1)



# Rigid body part
body_2= chrono.ChBodyAuxRef()
body_2.SetName('M-410iB-300 -2/M-410iB-300-08-1')
body_2.SetPos(chrono.ChVectorD(-0.0705010578312056,3.00995602354386,-1.15720151327207))
body_2.SetRot(chrono.ChQuaternionD(0.775225945120091,0.0029627102134376,-0.00363604740942613,-0.631666633217308))
body_2.SetMass(7.16874140056196)
body_2.SetInertiaXX(chrono.ChVectorD(0.0767806514249317,1.02468807605989,1.09928791468397))
body_2.SetInertiaXY(chrono.ChVectorD(0.21107146003781,-1.85658814945769e-06,0.000285495021568692))
body_2.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0995028745288738,0.617303418169042,1.66091348054003e-08),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_2_1_shape = chrono.ChObjShapeFile() 
body_2_1_shape.SetFilename(shapes_dir +'body_2_1.obj') 
body_2_1_level = chrono.ChAssetLevel() 
body_2_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_2_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_2_1_level.GetAssets().push_back(body_2_1_shape) 
body_2.GetAssets().push_back(body_2_1_level) 

exported_items.append(body_2)



# Rigid body part
body_3= chrono.ChBodyAuxRef()
body_3.SetName('M-410iB-300 -2/M-410iB-300-09-1')
body_3.SetPos(chrono.ChVectorD(1.44718886310698,2.75811166841875,-1.30281437081086))
body_3.SetRot(chrono.ChQuaternionD(0.999989000687802,1.54637654106924e-08,-0.00469025506145738,-3.29696289697581e-06))
body_3.SetMass(8.44776262879024)
body_3.SetInertiaXX(chrono.ChVectorD(0.110140787877959,0.723341003926602,0.82871654746704))
body_3.SetInertiaXY(chrono.ChVectorD(0.00476638845840011,0.00670445634934793,0.00135319267362521))
body_3.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.00309747019490023,0.11726872541838,-0.0225919700688117),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_3_1_shape = chrono.ChObjShapeFile() 
body_3_1_shape.SetFilename(shapes_dir +'body_3_1.obj') 
body_3_1_level = chrono.ChAssetLevel() 
body_3_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_3_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_3_1_level.GetAssets().push_back(body_3_1_shape) 
body_3.GetAssets().push_back(body_3_1_level) 

exported_items.append(body_3)



# Rigid body part
body_4= chrono.ChBodyAuxRef()
body_4.SetName('M-410iB-300 -2/ArmBase-1')
body_4.SetPos(chrono.ChVectorD(-0.140670357955037,1.75770592148926,-1.07259688656261))
body_4.SetRot(chrono.ChQuaternionD(1,0,0,0))
body_4.SetMass(29.4636133436255)
body_4.SetInertiaXX(chrono.ChVectorD(0.754351795243641,1.45825924231452,0.754351795243641))
body_4.SetInertiaXY(chrono.ChVectorD(-1.65340831304039e-18,-2.64545330086463e-17,8.26704156520197e-18))
body_4.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-9.77354995986777e-18,0.231605672678633,-6.24094154063845e-18),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_4_1_shape = chrono.ChObjShapeFile() 
body_4_1_shape.SetFilename(shapes_dir +'body_4_1.obj') 
body_4_1_level = chrono.ChAssetLevel() 
body_4_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_4_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_4_1_level.GetAssets().push_back(body_4_1_shape) 
body_4.GetAssets().push_back(body_4_1_level) 

# Auxiliary marker (coordinate system feature)
marker_4_1 =chrono.ChMarker()
marker_4_1.SetName('marker_M1_B')
body_4.AddMarker(marker_4_1)
marker_4_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-0.140670357955037,1.75770592148926,-1.07259688656261),chrono.ChQuaternionD(0.707106781186548,-0.707106781186547,0,0)))

exported_items.append(body_4)



# Rigid body part
body_5= chrono.ChBodyAuxRef()
body_5.SetName('M-410iB-300 -2/M-410iB-300-03-1')
body_5.SetPos(chrono.ChVectorD(0.249329345659439,2.51550127212935,-1.07110800107725))
body_5.SetRot(chrono.ChQuaternionD(0.77422047430858,0.00296848859246101,-0.00363133144298775,-0.632898616421955))
body_5.SetMass(64.4233324323959)
body_5.SetInertiaXX(chrono.ChVectorD(1.38045361088929,10.239962763691,10.6382427790646))
body_5.SetInertiaXY(chrono.ChVectorD(2.03255261947257,-0.744009410101586,0.186032607535412))
body_5.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.0515352333247145,0.525779243665004,-0.000216254075872922),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_5_1_shape = chrono.ChObjShapeFile() 
body_5_1_shape.SetFilename(shapes_dir +'body_5_1.obj') 
body_5_1_level = chrono.ChAssetLevel() 
body_5_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_5_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_5_1_level.GetAssets().push_back(body_5_1_shape) 
body_5.GetAssets().push_back(body_5_1_level) 

# Auxiliary marker (coordinate system feature)
marker_5_1 =chrono.ChMarker()
marker_5_1.SetName('marker_M2_A')
body_5.AddMarker(marker_5_1)
marker_5_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(0.250839641457433,2.51550127212935,-1.23210627732678),chrono.ChQuaternionD(0.632898616421955,-0.00363133144298775,-0.00296848859246101,0.77422047430858)))

# Auxiliary marker (coordinate system feature)
marker_5_2 =chrono.ChMarker()
marker_5_2.SetName('marker_M3_B')
body_5.AddMarker(marker_5_2)
marker_5_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(1.44642035239278,2.75811166842827,-1.22089075026679),chrono.ChQuaternionD(0.77422047430858,0.00296848859246101,-0.00363133144298775,-0.632898616421955)))

exported_items.append(body_5)



# Rigid body part
body_6= chrono.ChBodyAuxRef()
body_6.SetName('M-410iB-300 -2/M-410iB-300-06-1')
body_6.SetPos(chrono.ChVectorD(1.44456382188138,2.75811166842827,-1.02298368296424))
body_6.SetRot(chrono.ChQuaternionD(0.887172776838507,0.00216417105143073,-0.00416111237922648,-0.461413551539268))
body_6.SetMass(57.487443257986)
body_6.SetInertiaXX(chrono.ChVectorD(7.93927675297921,5.21298383839116,12.7990170860625))
body_6.SetInertiaXY(chrono.ChVectorD(-5.76626932315198,0.0133490660572137,-0.0601683307732725))
body_6.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.216990574023306,0.112589145111018,-0.097224117310279),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_6_1_shape = chrono.ChObjShapeFile() 
body_6_1_shape.SetFilename(shapes_dir +'body_6_1.obj') 
body_6_1_level = chrono.ChAssetLevel() 
body_6_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_6_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_6_1_level.GetAssets().push_back(body_6_1_shape) 
body_6.GetAssets().push_back(body_6_1_level) 

# Auxiliary marker (coordinate system feature)
marker_6_1 =chrono.ChMarker()
marker_6_1.SetName('marker_M3_A')
body_6.AddMarker(marker_6_1)
marker_6_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(1.44606467961892,2.75811166325655,-1.18297664345243),chrono.ChQuaternionD(0.00416111237922648,0.461413551539268,0.887172776838507,0.00216417105143073)))

exported_items.append(body_6)



# Rigid body part
body_7= chrono.ChBodyAuxRef()
body_7.SetName('M-410iB-300 -2/M-410iB-300-10-1')
body_7.SetPos(chrono.ChVectorD(-0.248692028434912,2.78749692402065,-1.39060828636822))
body_7.SetRot(chrono.ChQuaternionD(0.774222505853924,0.00296847693412176,-0.00363134096902962,-0.632896131238554))
body_7.SetMass(2.24487855545089)
body_7.SetInertiaXX(chrono.ChVectorD(0.0178763294593344,0.411607493967004,0.428955494007621))
body_7.SetInertiaXY(chrono.ChVectorD(0.0833272236595937,8.18911403407745e-07,4.03828534293205e-06))
body_7.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-7.0126896985531e-15,0.610001635976697,-2.13860676946226e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_7_1_shape = chrono.ChObjShapeFile() 
body_7_1_shape.SetFilename(shapes_dir +'body_7_1.obj') 
body_7_1_level = chrono.ChAssetLevel() 
body_7_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_7_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_7_1_level.GetAssets().push_back(body_7_1_shape) 
body_7.GetAssets().push_back(body_7_1_level) 

exported_items.append(body_7)



# Rigid body part
body_8= chrono.ChBodyAuxRef()
body_8.SetName('M-410iB-300 -2/M-410iB-300-12-1')
body_8.SetPos(chrono.ChVectorD(2.44627511940635,1.53476735988757,-1.0471692874388))
body_8.SetRot(chrono.ChQuaternionD(0.999989000688573,1.55031962380309e-08,-0.00469025489108105,-3.30536966097703e-06))
body_8.SetMass(16.1636065115335)
body_8.SetInertiaXX(chrono.ChVectorD(0.279047290630491,0.400769297031642,0.419166909944415))
body_8.SetInertiaXY(chrono.ChVectorD(-0.0515548458279066,0.0513289089327675,0.0676089098598876))
body_8.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0294847451383035,0.131793864973377,-0.039955675141979),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_8_1_shape = chrono.ChObjShapeFile() 
body_8_1_shape.SetFilename(shapes_dir +'body_8_1.obj') 
body_8_1_level = chrono.ChAssetLevel() 
body_8_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_8_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_8_1_level.GetAssets().push_back(body_8_1_shape) 
body_8.GetAssets().push_back(body_8_1_level) 

# Collision material 
mat_8 = chrono.ChMaterialSurfaceNSC()

# Collision shapes 
body_8.GetCollisionModel().ClearModel()
mr = chrono.ChMatrix33D()
mr[0,0]=0; mr[1,0]=0; mr[2,0]=-1 
mr[0,1]=0; mr[1,1]=-1; mr[2,1]=0 
mr[0,2]=-1; mr[1,2]=0; mr[2,2]=0 
body_8.GetCollisionModel().AddCylinder(mat_8, 0.0891514706007005,0.0891514706007005,0.0737653824400992,chrono.ChVectorD(4.57739150408006E-17,0.0737653824400992,0),mr)
body_8.GetCollisionModel().BuildModel()
body_8.SetCollide(True)

exported_items.append(body_8)



# Rigid body part
body_9= chrono.ChBodyAuxRef()
body_9.SetName('M-410iB-300 -2/M-410iB-300-02-1')
body_9.SetPos(chrono.ChVectorD(-0.140670357955083,2.15049691615605,-1.07259688656366))
body_9.SetRot(chrono.ChQuaternionD(0.999989000693237,-1.71939564698091e-15,-0.0046902550614829,3.04004373359531e-17))
body_9.SetMass(286.960740367602)
body_9.SetInertiaXX(chrono.ChVectorD(20.2590706850909,23.3528740040787,23.2840669201357))
body_9.SetInertiaXY(chrono.ChVectorD(-5.56147216553128,-0.22734341938684,0.692970035795246))
body_9.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.175382085214385,0.199890816413736,-0.00351536323719578),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_9_1_shape = chrono.ChObjShapeFile() 
body_9_1_shape.SetFilename(shapes_dir +'body_9_1.obj') 
body_9_1_level = chrono.ChAssetLevel() 
body_9_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_9_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_9_1_level.GetAssets().push_back(body_9_1_shape) 
body_9.GetAssets().push_back(body_9_1_level) 

# Auxiliary marker (coordinate system feature)
marker_9_1 =chrono.ChMarker()
marker_9_1.SetName('marker_M1_A')
body_9.AddMarker(marker_9_1)
marker_9_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-0.140670357955083,2.15049691615605,-1.07259688656366),chrono.ChQuaternionD(0.00331651115946906,-0.0033165111594691,0.707099003502148,0.707099003502146)))

# Auxiliary marker (coordinate system feature)
marker_9_2 =chrono.ChMarker()
marker_9_2.SetName('marker_M2_B')
body_9.AddMarker(marker_9_2)
marker_9_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(0.250513175309517,2.51549691615605,-1.19693289624145),chrono.ChQuaternionD(0.0046902550614829,-3.04004373359531E-17,0.999989000693237,-1.71939564698091E-15)))

exported_items.append(body_9)



# Rigid body part
body_10= chrono.ChBodyAuxRef()
body_10.SetName('M-410iB-300 -2/M-410iB-300-04-1')
body_10.SetPos(chrono.ChVectorD(0.246790088586688,2.78049691677857,-0.800049894650865))
body_10.SetRot(chrono.ChQuaternionD(0.497615698966725,0.507019545596668,0.492969550379498,-0.502285594979033))
body_10.SetMass(1.58709182620022)
body_10.SetInertiaXX(chrono.ChVectorD(0.112490999899515,0.112339649285695,0.00107522256830732))
body_10.SetInertiaXY(chrono.ChVectorD(-8.72415787683974e-07,-9.67173256947305e-06,-0.00311670203462774))
body_10.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.002504718931018,0.259643195204338,6.66879538414608e-09),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_10_1_shape = chrono.ChObjShapeFile() 
body_10_1_shape.SetFilename(shapes_dir +'body_10_1.obj') 
body_10_1_level = chrono.ChAssetLevel() 
body_10_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_10_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_10_1_level.GetAssets().push_back(body_10_1_shape) 
body_10.GetAssets().push_back(body_10_1_level) 

exported_items.append(body_10)



# Rigid body part
body_11= chrono.ChBodyAuxRef()
body_11.SetName('M-410iB-300 -2/M-410iB-300-05-1')
body_11.SetPos(chrono.ChVectorD(0.573557803429006,2.77437872021165,-0.79698454564128))
body_11.SetRot(chrono.ChQuaternionD(0.700449547156082,0.00334740858353244,-0.00328532317242855,-0.71368650918752))
body_11.SetMass(44.264758578016)
body_11.SetInertiaXX(chrono.ChVectorD(0.419986310544538,2.77614167703968,2.76540990748346))
body_11.SetInertiaXY(chrono.ChVectorD(-0.0447368107774969,-0.0535308236364203,-0.00112175762366347))
body_11.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-5.19600690940307e-06,0.410805913274014,-0.00264008387504332),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_11_1_shape = chrono.ChObjShapeFile() 
body_11_1_shape.SetFilename(shapes_dir +'body_11_1.obj') 
body_11_1_level = chrono.ChAssetLevel() 
body_11_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_11_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_11_1_level.GetAssets().push_back(body_11_1_shape) 
body_11.GetAssets().push_back(body_11_1_level) 

exported_items.append(body_11)



# Rigid body part
body_12= chrono.ChBodyAuxRef()
body_12.SetName('M-410iB-300 -2/M-410iB-300-11-1')
body_12.SetPos(chrono.ChVectorD(1.94686605174249,3.0281083663764,-1.26586756987837))
body_12.SetRot(chrono.ChQuaternionD(0.887172779059437,0.00216417103140192,-0.00416111238964336,-0.461413547269022))
body_12.SetMass(2.26635866531324)
body_12.SetInertiaXX(chrono.ChVectorD(0.341320308660793,0.168434671120988,0.508901325901854))
body_12.SetInertiaXY(chrono.ChVectorD(-0.238603758774088,0.00273548059950271,0.0039004020288025))
body_12.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.650000000546566,-0.000267013560427983,-4.19077490083406e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_12_1_shape = chrono.ChObjShapeFile() 
body_12_1_shape.SetFilename(shapes_dir +'body_12_1.obj') 
body_12_1_level = chrono.ChAssetLevel() 
body_12_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_12_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_12_1_level.GetAssets().push_back(body_12_1_shape) 
body_12.GetAssets().push_back(body_12_1_level) 

exported_items.append(body_12)



# Rigid body part
body_13= chrono.ChBodyAuxRef()
body_13.SetName('M-410iB-300 -2/M-410iB-300-07-1')
body_13.SetPos(chrono.ChVectorD(0.249455005756102,2.51550127212935,-1.08450342929929))
body_13.SetRot(chrono.ChQuaternionD(0.888766803937314,0.00214973475788003,-0.00416858885513608,-0.458335651816961))
body_13.SetMass(6.52835644128616)
body_13.SetInertiaXX(chrono.ChVectorD(0.208817770417523,0.125335501568925,0.315989576343094))
body_13.SetInertiaXY(chrono.ChVectorD(-0.13450454853505,0.00102152747932435,0.00089465533213971))
body_13.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.244379956813902,-0.0286291495785353,-0.0666992297731388),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_13_1_shape = chrono.ChObjShapeFile() 
body_13_1_shape.SetFilename(shapes_dir +'body_13_1.obj') 
body_13_1_level = chrono.ChAssetLevel() 
body_13_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_13_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_13_1_level.GetAssets().push_back(body_13_1_shape) 
body_13.GetAssets().push_back(body_13_1_level) 

exported_items.append(body_13)



# Rigid body part
body_14= chrono.ChBodyAuxRef()
body_14.SetName('M-410iB-300 -3/M-410iB-300-12-1')
body_14.SetPos(chrono.ChVectorD(2.44301961035839,1.53528578498375,-2.6685494379497))
body_14.SetRot(chrono.ChQuaternionD(0.999595636064291,-9.3989718789005e-08,0.0284352659614848,-3.30405603942703e-06))
body_14.SetMass(16.1636065115335)
body_14.SetInertiaXX(chrono.ChVectorD(0.272879461348641,0.400769239345033,0.425334796912874))
body_14.SetInertiaXY(chrono.ChVectorD(-0.0559181430016173,0.0416218514929831,0.0640470846209274))
body_14.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0294847451383035,0.131793864973377,-0.039955675141979),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_8_1_shape = chrono.ChObjShapeFile() 
body_8_1_shape.SetFilename(shapes_dir +'body_8_1.obj') 
body_8_1_level = chrono.ChAssetLevel() 
body_8_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_8_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_8_1_level.GetAssets().push_back(body_8_1_shape) 
body_14.GetAssets().push_back(body_8_1_level) 

# Collision material 
mat_14 = chrono.ChMaterialSurfaceNSC()

# Collision shapes 
body_14.GetCollisionModel().ClearModel()
mr = chrono.ChMatrix33D()
mr[0,0]=0; mr[1,0]=0; mr[2,0]=-1 
mr[0,1]=0; mr[1,1]=-1; mr[2,1]=0 
mr[0,2]=-1; mr[1,2]=0; mr[2,2]=0 
body_14.GetCollisionModel().AddCylinder(mat_14, 0.0891514706007005,0.0891514706007005,0.0737653824400992,chrono.ChVectorD(4.57739150408006E-17,0.0737653824400992,0),mr)
body_14.GetCollisionModel().BuildModel()
body_14.SetCollide(True)

exported_items.append(body_14)



# Rigid body part
body_15= chrono.ChBodyAuxRef()
body_15.SetName('M-410iB-300 -3/M-410iB-300-07-1')
body_15.SetPos(chrono.ChVectorD(0.24781061519026,2.51550127212934,-2.56030761098453))
body_15.SetRot(chrono.ChQuaternionD(0.888576666851081,-0.0130242387066026,0.0252771348564548,-0.457845981512762))
body_15.SetMass(6.52835644128616)
body_15.SetInertiaXX(chrono.ChVectorD(0.208989330950575,0.12625922115222,0.314894296226747))
body_15.SetInertiaXY(chrono.ChVectorD(-0.134048342756629,-0.0103415885263089,-0.0145212617934297))
body_15.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.244379956813902,-0.0286291495785353,-0.0666992297731388),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_13_1_shape = chrono.ChObjShapeFile() 
body_13_1_shape.SetFilename(shapes_dir +'body_13_1.obj') 
body_13_1_level = chrono.ChAssetLevel() 
body_13_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_13_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_13_1_level.GetAssets().push_back(body_13_1_shape) 
body_15.GetAssets().push_back(body_13_1_level) 

exported_items.append(body_15)



# Rigid body part
body_16= chrono.ChBodyAuxRef()
body_16.SetName('M-410iB-300 -3/M-410iB-300-11-1')
body_16.SetPos(chrono.ChVectorD(1.92948885042878,3.02810836635585,-2.85365982741116))
body_16.SetRot(chrono.ChQuaternionD(0.886983829684242,-0.0131118041804073,0.0252318237860964,-0.460924203680211))
body_16.SetMass(2.26635866531324)
body_16.SetInertiaXX(chrono.ChVectorD(0.341516388376477,0.169835229134998,0.507304688172161))
body_16.SetInertiaXY(chrono.ChVectorD(-0.237972588011775,-0.0165676815724929,-0.0235889143997505))
body_16.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.650000000546566,-0.000267013560427983,-4.19077490083406e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_12_1_shape = chrono.ChObjShapeFile() 
body_12_1_shape.SetFilename(shapes_dir +'body_12_1.obj') 
body_12_1_level = chrono.ChAssetLevel() 
body_12_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_12_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_12_1_level.GetAssets().push_back(body_12_1_shape) 
body_16.GetAssets().push_back(body_12_1_level) 

exported_items.append(body_16)



# Rigid body part
body_17= chrono.ChBodyAuxRef()
body_17.SetName('M-410iB-300 -3/M-410iB-300-08-1')
body_17.SetPos(chrono.ChVectorD(-0.0766004308201383,3.0097326206868,-2.61164222470186))
body_17.SetRot(chrono.ChQuaternionD(0.774921781901543,-0.0179617787108951,0.0220440206400468,-0.631417189815181))
body_17.SetMass(7.16874140056196)
body_17.SetInertiaXX(chrono.ChVectorD(0.0767815745013347,1.02478073492509,1.09919433274237))
body_17.SetInertiaXY(chrono.ChVectorD(0.211083172685069,1.17827430601179e-05,-0.00172752435257774))
body_17.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0995028745288738,0.617303418169042,1.66091348054003e-08),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_2_1_shape = chrono.ChObjShapeFile() 
body_2_1_shape.SetFilename(shapes_dir +'body_2_1.obj') 
body_2_1_level = chrono.ChAssetLevel() 
body_2_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_2_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_2_1_level.GetAssets().push_back(body_2_1_shape) 
body_17.GetAssets().push_back(body_2_1_level) 

exported_items.append(body_17)



# Rigid body part
body_18= chrono.ChBodyAuxRef()
body_18.SetName('M-410iB-300 -3/ArmBase-1')
body_18.SetPos(chrono.ChVectorD(-0.140670357955037,1.75770592148926,-2.52259688656261))
body_18.SetRot(chrono.ChQuaternionD(1,0,0,0))
body_18.SetMass(29.4636133436255)
body_18.SetInertiaXX(chrono.ChVectorD(0.754351795243641,1.45825924231452,0.754351795243641))
body_18.SetInertiaXY(chrono.ChVectorD(-1.65340831304039e-18,-2.64545330086463e-17,8.26704156520197e-18))
body_18.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-9.77354995986777e-18,0.231605672678633,-6.24094154063845e-18),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_4_1_shape = chrono.ChObjShapeFile() 
body_4_1_shape.SetFilename(shapes_dir +'body_4_1.obj') 
body_4_1_level = chrono.ChAssetLevel() 
body_4_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_4_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_4_1_level.GetAssets().push_back(body_4_1_shape) 
body_18.GetAssets().push_back(body_4_1_level) 

# Auxiliary marker (coordinate system feature)
marker_18_1 =chrono.ChMarker()
marker_18_1.SetName('marker_M1_B')
body_18.AddMarker(marker_18_1)
marker_18_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-0.140670357955037,1.75770592148926,-2.52259688656261),chrono.ChQuaternionD(0.707106781186548,-0.707106781186547,0,0)))

exported_items.append(body_18)



# Rigid body part
body_19= chrono.ChBodyAuxRef()
body_19.SetName('M-410iB-300 -3/M-410iB-300-06-1')
body_19.SetPos(chrono.ChVectorD(1.44437023416278,2.75811166840772,-2.57805133730703))
body_19.SetRot(chrono.ChQuaternionD(0.886983827465352,-0.0131118043018734,0.0252318237229761,-0.460924207950154))
body_19.SetMass(57.487443257986)
body_19.SetInertiaXX(chrono.ChVectorD(7.94919684381944,5.26164180351977,12.7404390300937))
body_19.SetInertiaXY(chrono.ChVectorD(-5.74111847726713,-0.48332185652256,-0.688476764526364))
body_19.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.216990574023306,0.112589145111018,-0.097224117310279),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_6_1_shape = chrono.ChObjShapeFile() 
body_6_1_shape.SetFilename(shapes_dir +'body_6_1.obj') 
body_6_1_level = chrono.ChAssetLevel() 
body_6_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_6_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_6_1_level.GetAssets().push_back(body_6_1_shape) 
body_19.GetAssets().push_back(body_6_1_level) 

# Auxiliary marker (coordinate system feature)
marker_19_1 =chrono.ChMarker()
marker_19_1.SetName('marker_M3_A')
body_19.AddMarker(marker_19_1)
marker_19_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(1.43527462117808,2.75811166323088,-2.73779259623582),chrono.ChQuaternionD(-0.0252318237229761,0.460924207950154,0.886983827465352,-0.0131118043018734)))

exported_items.append(body_19)



# Rigid body part
body_20= chrono.ChBodyAuxRef()
body_20.SetName('M-410iB-300 -3/M-410iB-300-10-1')
body_20.SetPos(chrono.ChVectorD(-0.269510616840608,2.78749692402099,-2.8327583274092))
body_20.SetRot(chrono.ChQuaternionD(0.773917950762877,-0.0179967676599929,0.0220154648878966,-0.632647169555473))
body_20.SetMass(2.24487855545089)
body_20.SetInertiaXX(chrono.ChVectorD(0.0178763840870494,0.411608820294421,0.428954113052488))
body_20.SetInertiaXY(chrono.ChVectorD(0.0833274928328416,-4.95864337788027e-06,-2.44337445176723e-05))
body_20.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-7.0126896985531e-15,0.610001635976697,-2.13860676946226e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_7_1_shape = chrono.ChObjShapeFile() 
body_7_1_shape.SetFilename(shapes_dir +'body_7_1.obj') 
body_7_1_level = chrono.ChAssetLevel() 
body_7_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_7_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_7_1_level.GetAssets().push_back(body_7_1_shape) 
body_20.GetAssets().push_back(body_7_1_level) 

exported_items.append(body_20)



# Rigid body part
body_21= chrono.ChBodyAuxRef()
body_21.SetName('M-410iB-300 -3/M-410iB-300-04-1')
body_21.SetPos(chrono.ChVectorD(0.263985291593456,2.78049691677856,-2.27630180800248))
body_21.SetRot(chrono.ChQuaternionD(-0.481013859592587,-0.490103967834855,-0.509181724270222,0.518804143450665))
body_21.SetMass(1.58709182620022)
body_21.SetInertiaXX(chrono.ChVectorD(0.112490768255212,0.112339941615541,0.00107516188276481))
body_21.SetInertiaXY(chrono.ChVectorD(5.27968196979613e-06,5.85814830893718e-05,-0.00311508411715979))
body_21.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.002504718931018,0.259643195204338,6.66879538414608e-09),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_10_1_shape = chrono.ChObjShapeFile() 
body_10_1_shape.SetFilename(shapes_dir +'body_10_1.obj') 
body_10_1_level = chrono.ChAssetLevel() 
body_10_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_10_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_10_1_level.GetAssets().push_back(body_10_1_shape) 
body_21.GetAssets().push_back(body_10_1_level) 

exported_items.append(body_21)



# Rigid body part
body_22= chrono.ChBodyAuxRef()
body_22.SetName('M-410iB-300 -3/M-410iB-300-05-1')
body_22.SetPos(chrono.ChVectorD(0.590238935173268,2.77437872020596,-2.29487856449075))
body_22.SetRot(chrono.ChQuaternionD(0.700174012050365,-0.0202940887991843,0.019917688125101,-0.713405767084103))
body_22.SetMass(44.264758578016)
body_22.SetInertiaXX(chrono.ChVectorD(0.419853549725334,2.77623946013083,2.76544488521151))
body_22.SetInertiaXY(chrono.ChVectorD(-0.0411922485132793,-0.0534679233833276,-0.00035431692053331))
body_22.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-5.19600690940307e-06,0.410805913274014,-0.00264008387504332),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_11_1_shape = chrono.ChObjShapeFile() 
body_11_1_shape.SetFilename(shapes_dir +'body_11_1.obj') 
body_11_1_level = chrono.ChAssetLevel() 
body_11_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_11_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_11_1_level.GetAssets().push_back(body_11_1_shape) 
body_22.GetAssets().push_back(body_11_1_level) 

exported_items.append(body_22)



# Rigid body part
body_23= chrono.ChBodyAuxRef()
body_23.SetName('M-410iB-300 -3/M-410iB-300-09-1')
body_23.SetPos(chrono.ChVectorD(1.42846184947971,2.75811166841886,-2.85744179327167))
body_23.SetRot(chrono.ChQuaternionD(0.999595636069256,-9.37510361643379e-08,0.0284352657879117,-3.295665518805e-06))
body_23.SetMass(8.44776262879024)
body_23.SetInertiaXX(chrono.ChVectorD(0.112405020583065,0.723341002607099,0.826452316081436))
body_23.SetInertiaXY(chrono.ChVectorD(0.00466634326720386,-0.0408270211157756,0.00166576161941222))
body_23.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.00309747019490023,0.11726872541838,-0.0225919700688117),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_3_1_shape = chrono.ChObjShapeFile() 
body_3_1_shape.SetFilename(shapes_dir +'body_3_1.obj') 
body_3_1_level = chrono.ChAssetLevel() 
body_3_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_3_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_3_1_level.GetAssets().push_back(body_3_1_shape) 
body_23.GetAssets().push_back(body_3_1_level) 

exported_items.append(body_23)



# Rigid body part
body_24= chrono.ChBodyAuxRef()
body_24.SetName('M-410iB-300 -3/M-410iB-300-02-1')
body_24.SetPos(chrono.ChVectorD(-0.140670357955045,2.15049691615661,-2.52259688656262))
body_24.SetRot(chrono.ChQuaternionD(0.999595636074689,-1.77550371855288e-15,0.0284352657880662,-4.40304238690008e-17))
body_24.SetMass(286.960740367602)
body_24.SetInertiaXX(chrono.ChVectorD(20.3023705434486,23.3528740040787,23.240767061778))
body_24.SetInertiaXY(chrono.ChVectorD(-5.59515031961364,-0.425196497062899,0.323222863387797))
body_24.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.175382085214385,0.199890816413736,-0.00351536323719578),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_9_1_shape = chrono.ChObjShapeFile() 
body_9_1_shape.SetFilename(shapes_dir +'body_9_1.obj') 
body_9_1_level = chrono.ChAssetLevel() 
body_9_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_9_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_9_1_level.GetAssets().push_back(body_9_1_shape) 
body_24.GetAssets().push_back(body_9_1_level) 

# Auxiliary marker (coordinate system feature)
marker_24_1 =chrono.ChMarker()
marker_24_1.SetName('marker_M1_A')
body_24.AddMarker(marker_24_1)
marker_24_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-0.140670357955045,2.15049691615661,-2.52259688656262),chrono.ChQuaternionD(-0.0201067692635834,0.0201067692635835,0.706820852712894,0.706820852712892)))

# Auxiliary marker (coordinate system feature)
marker_24_2 =chrono.ChMarker()
marker_24_2.SetName('marker_M2_B')
body_24.AddMarker(marker_24_2)
marker_24_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(0.241422477355736,2.51549691615661,-2.6725604328135),chrono.ChQuaternionD(-0.0284352657880662,4.40304238690008E-17,0.999595636074689,-1.77550371855288E-15)))

exported_items.append(body_24)



# Rigid body part
body_25= chrono.ChBodyAuxRef()
body_25.SetName('M-410iB-300 -3/M-410iB-300-03-1')
body_25.SetPos(chrono.ChVectorD(0.248572145885059,2.51550127212934,-2.54693325448516))
body_25.SetRot(chrono.ChQuaternionD(0.773915920011722,-0.0179968383277939,0.0220154071195883,-0.632649653767369))
body_25.SetMass(64.4233324323959)
body_25.SetInertiaXX(chrono.ChVectorD(1.3999144965047,10.2157703700748,10.6429742870654))
body_25.SetInertiaXY(chrono.ChVectorD(2.07805173400565,-0.73242895267987,0.186315165680174))
body_25.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.0515352333247145,0.525779243665004,-0.000216254075872922),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_5_1_shape = chrono.ChObjShapeFile() 
body_5_1_shape.SetFilename(shapes_dir +'body_5_1.obj') 
body_5_1_level = chrono.ChAssetLevel() 
body_5_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_5_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_5_1_level.GetAssets().push_back(body_5_1_shape) 
body_25.GetAssets().push_back(body_5_1_level) 

# Auxiliary marker (coordinate system feature)
marker_25_1 =chrono.ChMarker()
marker_25_1.SetName('marker_M2_A')
body_25.AddMarker(marker_25_1)
marker_25_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(0.239419388017528,2.51550127212934,-2.70767824809969),chrono.ChQuaternionD(0.632649653767369,0.0220154071195883,0.0179968383277939,0.773915920011722)))

# Auxiliary marker (coordinate system feature)
marker_25_2 =chrono.ChMarker()
marker_25_2.SetName('marker_M3_B')
body_25.AddMarker(marker_25_2)
marker_25_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(1.43311921029243,2.75811166840772,-2.77564705505362),chrono.ChQuaternionD(0.773915920011722,-0.0179968383277939,0.0220154071195883,-0.632649653767369)))

exported_items.append(body_25)



# Rigid body part
body_26= chrono.ChBodyAuxRef()
body_26.SetName('M-410iB-300 -8/M-410iB-300-03-1')
body_26.SetPos(chrono.ChVectorD(-1.89023798629732,2.51550127212935,-1.05418361560889))
body_26.SetRot(chrono.ChQuaternionD(-0.0161290657088895,-0.632768225751381,0.774060968294888,0.01318495662444))
body_26.SetMass(64.4233324323959)
body_26.SetInertiaXX(chrono.ChVectorD(1.25197727739062,10.3648233299809,10.6418585462733))
body_26.SetInertiaXY(chrono.ChVectorD(1.72864184541375,0.749844829764355,-0.115005843215683))
body_26.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.0515352333247145,0.525779243665004,-0.000216254075872922),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_5_1_shape = chrono.ChObjShapeFile() 
body_5_1_shape.SetFilename(shapes_dir +'body_5_1.obj') 
body_5_1_level = chrono.ChAssetLevel() 
body_5_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_5_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_5_1_level.GetAssets().push_back(body_5_1_shape) 
body_26.GetAssets().push_back(body_5_1_level) 

# Auxiliary marker (coordinate system feature)
marker_26_1 =chrono.ChMarker()
marker_26_1.SetName('marker_M2_A')
body_26.AddMarker(marker_26_1)
marker_26_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.8835311786329,2.51550127212935,-0.89331800499037),chrono.ChQuaternionD(-0.01318495662444,0.774060968294888,0.632768225751381,-0.0161290657088895)))

# Auxiliary marker (coordinate system feature)
marker_26_2 =chrono.ChMarker()
marker_26_2.SetName('marker_M3_B')
body_26.AddMarker(marker_26_2)
marker_26_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-3.07812670840691,2.7581116684078,-0.843512938362607),chrono.ChQuaternionD(-0.0161290657088895,-0.632768225751381,0.774060968294888,0.01318495662444)))

exported_items.append(body_26)



# Rigid body part
body_27= chrono.ChBodyAuxRef()
body_27.SetName('M-410iB-300 -8/M-410iB-300-02-1')
body_27.SetPos(chrono.ChVectorD(-1.50067035795504,2.15049691615662,-1.07259688656262))
body_27.SetRot(chrono.ChQuaternionD(-0.020832422850692,-4.91689207710726e-17,0.999782981530577,-1.42838265737958e-15))
body_27.SetMass(286.960740367602)
body_27.SetInertiaXX(chrono.ChVectorD(20.2901175317484,23.3528740040787,23.2530200734781))
body_27.SetInertiaXY(chrono.ChVectorD(5.58958696126103,-0.380312658085633,-0.408286322315498))
body_27.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.175382085214385,0.199890816413736,-0.00351536323719578),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_9_1_shape = chrono.ChObjShapeFile() 
body_9_1_shape.SetFilename(shapes_dir +'body_9_1.obj') 
body_9_1_level = chrono.ChAssetLevel() 
body_9_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_9_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_9_1_level.GetAssets().push_back(body_9_1_shape) 
body_27.GetAssets().push_back(body_9_1_level) 

# Auxiliary marker (coordinate system feature)
marker_27_1 =chrono.ChMarker()
marker_27_1.SetName('marker_M1_A')
body_27.AddMarker(marker_27_1)
marker_27_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.50067035795504,2.15049691615662,-1.07259688656262),chrono.ChQuaternionD(0.706953325955175,-0.706953325955177,0.0147307474662699,0.0147307474662699)))

# Auxiliary marker (coordinate system feature)
marker_27_2 =chrono.ChMarker()
marker_27_2.SetName('marker_M2_B')
body_27.AddMarker(marker_27_2)
marker_27_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.88499990300986,2.51549691615662,-0.928462224534612),chrono.ChQuaternionD(0.999782981530577,-1.42838265737958E-15,0.020832422850692,4.91689207710726E-17)))

exported_items.append(body_27)



# Rigid body part
body_28= chrono.ChBodyAuxRef()
body_28.SetName('M-410iB-300 -8/M-410iB-300-06-1')
body_28.SetPos(chrono.ChVectorD(-3.08637104907159,2.7581116684078,-1.0412569264908))
body_28.SetRot(chrono.ChQuaternionD(-0.018481933509325,-0.461339547949564,0.886979048036571,0.00961290671893371))
body_28.SetMass(57.487443257986)
body_28.SetInertiaXX(chrono.ChVectorD(9.23626109073719,3.95176601271154,12.7632505739842))
body_28.SetInertiaXY(chrono.ChVectorD(-5.28377900155736,-0.386710943461003,-0.533012355625827))
body_28.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.216990574023306,0.112589145111018,-0.097224117310279),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_6_1_shape = chrono.ChObjShapeFile() 
body_6_1_shape.SetFilename(shapes_dir +'body_6_1.obj') 
body_6_1_level = chrono.ChAssetLevel() 
body_6_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_6_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_6_1_level.GetAssets().push_back(body_6_1_shape) 
body_28.GetAssets().push_back(body_6_1_level) 

# Auxiliary marker (coordinate system feature)
marker_28_1 =chrono.ChMarker()
marker_28_1.SetName('marker_M3_A')
body_28.AddMarker(marker_28_1)
marker_28_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-3.07970611312048,2.75811166323643,-0.881395803610682),chrono.ChQuaternionD(0.886979048036571,0.00961290671893371,0.018481933509325,0.461339547949564)))

exported_items.append(body_28)



# Rigid body part
body_29= chrono.ChBodyAuxRef()
body_29.SetName('M-410iB-300 -8/M-410iB-300-08-1')
body_29.SetPos(chrono.ChVectorD(-1.56645472584531,3.00997129509906,-0.984521016814328))
body_29.SetRot(chrono.ChQuaternionD(-0.0161500112114716,-0.631536562382859,0.77506617816275,0.0131592925227534))
body_29.SetMass(7.16874140056196)
body_29.SetInertiaXX(chrono.ChVectorD(0.0717675745024931,1.02975018800294,1.09923887966336))
body_29.SetInertiaXY(chrono.ChVectorD(0.199439173611424,-0.00050893233775333,-0.0011600771527437))
body_29.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0995028745288738,0.617303418169042,1.66091348054003e-08),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_2_1_shape = chrono.ChObjShapeFile() 
body_2_1_shape.SetFilename(shapes_dir +'body_2_1.obj') 
body_2_1_level = chrono.ChAssetLevel() 
body_2_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_2_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_2_1_level.GetAssets().push_back(body_2_1_shape) 
body_29.GetAssets().push_back(body_2_1_level) 

exported_items.append(body_29)



# Rigid body part
body_30= chrono.ChBodyAuxRef()
body_30.SetName('M-410iB-300 -8/M-410iB-300-09-1')
body_30.SetPos(chrono.ChVectorD(-3.07471396400296,2.75811166841889,-0.761656824464445))
body_30.SetRot(chrono.ChQuaternionD(-0.0208324228505788,-3.2962831752888e-06,0.999782981525143,6.8684469401832e-08))
body_30.SetMass(8.44776262879024)
body_30.SetInertiaXX(chrono.ChVectorD(0.111328535597946,0.723340879094317,0.827528924579338))
body_30.SetInertiaXY(chrono.ChVectorD(-0.0046992070556587,-0.0299488851291984,-0.00159500040188627))
body_30.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.00309747019490023,0.11726872541838,-0.0225919700688117),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_3_1_shape = chrono.ChObjShapeFile() 
body_3_1_shape.SetFilename(shapes_dir +'body_3_1.obj') 
body_3_1_level = chrono.ChAssetLevel() 
body_3_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_3_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_3_1_level.GetAssets().push_back(body_3_1_shape) 
body_30.GetAssets().push_back(body_3_1_level) 

exported_items.append(body_30)



# Rigid body part
body_31= chrono.ChBodyAuxRef()
body_31.SetName('M-410iB-300 -8/M-410iB-300-11-1')
body_31.SetPos(chrono.ChVectorD(-3.57562548590889,3.02810836635593,-0.773058849182538))
body_31.SetRot(chrono.ChQuaternionD(-0.0184819335555947,-0.461339543680291,0.886979050257125,0.00961290662997541))
body_31.SetMass(2.26635866531324)
body_31.SetInertiaXX(chrono.ChVectorD(0.341618751538391,0.168972836608596,0.508064717536649))
body_31.SetInertiaXY(chrono.ChVectorD(-0.238202272084954,-0.0121365437494163,-0.0173070226498984))
body_31.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.650000000546566,-0.000267013560427983,-4.19077490083406e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_12_1_shape = chrono.ChObjShapeFile() 
body_12_1_shape.SetFilename(shapes_dir +'body_12_1.obj') 
body_12_1_level = chrono.ChAssetLevel() 
body_12_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_12_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_12_1_level.GetAssets().push_back(body_12_1_shape) 
body_31.GetAssets().push_back(body_12_1_level) 

exported_items.append(body_31)



# Rigid body part
body_32= chrono.ChBodyAuxRef()
body_32.SetName('M-410iB-300 -8/M-410iB-300-12-1')
body_32.SetPos(chrono.ChVectorD(-4.0854928369569,1.53473191923498,-0.965991376471005))
body_32.SetRot(chrono.ChQuaternionD(-0.020832423024185,-3.3047078221993e-06,0.999782981521498,6.88600126682097e-08))
body_32.SetMass(16.1636065115335)
body_32.SetInertiaXX(chrono.ChVectorD(0.274179246822686,0.400770705016092,0.42403354576777))
body_32.SetInertiaXY(chrono.ChVectorD(0.0549358563645918,0.0439219971951611,-0.0648895987113479))
body_32.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0294847451383035,0.131793864973377,-0.039955675141979),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_8_1_shape = chrono.ChObjShapeFile() 
body_8_1_shape.SetFilename(shapes_dir +'body_8_1.obj') 
body_8_1_level = chrono.ChAssetLevel() 
body_8_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_8_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_8_1_level.GetAssets().push_back(body_8_1_shape) 
body_32.GetAssets().push_back(body_8_1_level) 

# Collision material 
mat_32 = chrono.ChMaterialSurfaceNSC()

# Collision shapes 
body_32.GetCollisionModel().ClearModel()
mr = chrono.ChMatrix33D()
mr[0,0]=0; mr[1,0]=0; mr[2,0]=-1 
mr[0,1]=0; mr[1,1]=-1; mr[2,1]=0 
mr[0,2]=-1; mr[1,2]=0; mr[2,2]=0 
body_32.GetCollisionModel().AddCylinder(mat_32, 0.0891514706007005,0.0891514706007005,0.0737653824400992,chrono.ChVectorD(4.57739150408006E-17,0.0737653824400992,0),mr)
body_32.GetCollisionModel().BuildModel()
body_32.SetCollide(True)

exported_items.append(body_32)



# Rigid body part
body_33= chrono.ChBodyAuxRef()
body_33.SetName('M-410iB-300 -8/M-410iB-300-05-1')
body_33.SetPos(chrono.ChVectorD(-2.22803156401319,2.77437872020599,-1.31140581625378))
body_33.SetRot(chrono.ChQuaternionD(0.0145922216561281,0.713539474479197,-0.700305239533535,-0.0148679826798549))
body_33.SetMass(44.264758578016)
body_33.SetInertiaXX(chrono.ChVectorD(0.42004310873477,2.77606690602532,2.76542788030758))
body_33.SetInertiaXY(chrono.ChVectorD(-0.0462529492607062,0.0534855032075696,0.00147273903688276))
body_33.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-5.19600690940307e-06,0.410805913274014,-0.00264008387504332),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_11_1_shape = chrono.ChObjShapeFile() 
body_11_1_shape.SetFilename(shapes_dir +'body_11_1.obj') 
body_11_1_level = chrono.ChAssetLevel() 
body_11_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_11_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_11_1_level.GetAssets().push_back(body_11_1_shape) 
body_33.GetAssets().push_back(body_11_1_level) 

exported_items.append(body_33)



# Rigid body part
body_34= chrono.ChBodyAuxRef()
body_34.SetName('M-410iB-300 -8/M-410iB-300-10-1')
body_34.SetPos(chrono.ChVectorD(-1.37656248119926,2.78749692402101,-0.760511695268756))
body_34.SetRot(chrono.ChQuaternionD(-0.0161291080314693,-0.632765741073921,0.774062999426624,0.0131849048513525))
body_34.SetMass(2.24487855545089)
body_34.SetInertiaXX(chrono.ChVectorD(0.0178763580693232,0.411608188951686,0.428954770412949))
body_34.SetInertiaXY(chrono.ChVectorD(0.083327364668474,-3.63534335562181e-06,-1.79177747232414e-05))
body_34.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-7.0126896985531e-15,0.610001635976697,-2.13860676946226e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_7_1_shape = chrono.ChObjShapeFile() 
body_7_1_shape.SetFilename(shapes_dir +'body_7_1.obj') 
body_7_1_level = chrono.ChAssetLevel() 
body_7_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_7_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_7_1_level.GetAssets().push_back(body_7_1_shape) 
body_34.GetAssets().push_back(body_7_1_level) 

exported_items.append(body_34)



# Rigid body part
body_35= chrono.ChBodyAuxRef()
body_35.SetName('M-410iB-300 -8/ArmBase-1')
body_35.SetPos(chrono.ChVectorD(-1.50067035795504,1.75770592148925,-1.07259688656262))
body_35.SetRot(chrono.ChQuaternionD(1.00613961606655e-16,2.24047304958526e-17,1,-1.80641517110252e-15))
body_35.SetMass(29.4636133436255)
body_35.SetInertiaXX(chrono.ChVectorD(0.754351795243641,1.45825924231452,0.754351795243641))
body_35.SetInertiaXY(chrono.ChVectorD(1.23873904251348e-17,-1.41610608623833e-16,-2.75999744864809e-15))
body_35.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-9.77354995986777e-18,0.231605672678633,-6.24094154063845e-18),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_4_1_shape = chrono.ChObjShapeFile() 
body_4_1_shape.SetFilename(shapes_dir +'body_4_1.obj') 
body_4_1_level = chrono.ChAssetLevel() 
body_4_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_4_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_4_1_level.GetAssets().push_back(body_4_1_shape) 
body_35.GetAssets().push_back(body_4_1_level) 

# Auxiliary marker (coordinate system feature)
marker_35_1 =chrono.ChMarker()
marker_35_1.SetName('marker_M1_B')
body_35.AddMarker(marker_35_1)
marker_35_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.50067035795504,1.75770592148925,-1.07259688656262),chrono.ChQuaternionD(6.33262571962904E-17,-8.56131117349962E-17,0.707106781186549,0.707106781186546)))

exported_items.append(body_35)



# Rigid body part
body_36= chrono.ChBodyAuxRef()
body_36.SetName('M-410iB-300 -8/M-410iB-300-07-1')
body_36.SetPos(chrono.ChVectorD(-1.88967996441808,2.51550127212935,-1.04079922547358))
body_36.SetRot(chrono.ChQuaternionD(-0.018515142120481,-0.458262387448625,0.888572785093071,0.00954878809527384))
body_36.SetMass(6.52835644128616)
body_36.SetInertiaXX(chrono.ChVectorD(0.217776454762802,0.116996364473065,0.315370029093676))
body_36.SetInertiaXY(chrono.ChVectorD(-0.131177825981764,-0.00785983759678805,-0.0109112237466139))
body_36.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.244379956813902,-0.0286291495785353,-0.0666992297731388),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_13_1_shape = chrono.ChObjShapeFile() 
body_13_1_shape.SetFilename(shapes_dir +'body_13_1.obj') 
body_13_1_level = chrono.ChAssetLevel() 
body_13_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_13_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_13_1_level.GetAssets().push_back(body_13_1_shape) 
body_36.GetAssets().push_back(body_13_1_level) 

exported_items.append(body_36)



# Rigid body part
body_37= chrono.ChBodyAuxRef()
body_37.SetName('M-410iB-300 -8/M-410iB-300-04-1')
body_37.SetPos(chrono.ChVectorD(-1.90153311195666,2.78049691677857,-1.32501818692924))
body_37.SetRot(chrono.ChQuaternionD(0.505508842660258,0.515061852424014,-0.484872324889007,0.494035349673036))
body_37.SetMass(1.58709182620022)
body_37.SetInertiaXX(chrono.ChVectorD(0.112490878523098,0.112417005398895,0.000997987831524693))
body_37.SetInertiaXY(chrono.ChVectorD(2.26154194617753e-06,-4.30399510686146e-05,-0.00105481438653796))
body_37.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.002504718931018,0.259643195204338,6.66879538414608e-09),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_10_1_shape = chrono.ChObjShapeFile() 
body_10_1_shape.SetFilename(shapes_dir +'body_10_1.obj') 
body_10_1_level = chrono.ChAssetLevel() 
body_10_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_10_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_10_1_level.GetAssets().push_back(body_10_1_shape) 
body_37.GetAssets().push_back(body_10_1_level) 

exported_items.append(body_37)



# Rigid body part
body_38= chrono.ChBodyAuxRef()
body_38.SetName('M-410iB-300 -9/M-410iB-300-12-1')
body_38.SetPos(chrono.ChVectorD(-4.07901887109482,1.52899016742593,0.423705637598683))
body_38.SetRot(chrono.ChQuaternionD(-0.00920290070539668,-3.30543435019624e-06,0.999957652407181,3.04208697651878e-08))
body_38.SetMass(16.1636065115335)
body_38.SetInertiaXX(chrono.ChVectorD(0.27630299211672,0.400770684895774,0.421909820594053))
body_38.SetInertiaXY(chrono.ChVectorD(0.0534116881687834,0.0473590875475364,-0.0661498315148559))
body_38.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0294847451383035,0.131793864973377,-0.039955675141979),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_8_1_shape = chrono.ChObjShapeFile() 
body_8_1_shape.SetFilename(shapes_dir +'body_8_1.obj') 
body_8_1_level = chrono.ChAssetLevel() 
body_8_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_8_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_8_1_level.GetAssets().push_back(body_8_1_shape) 
body_38.GetAssets().push_back(body_8_1_level) 

# Collision material 
mat_38 = chrono.ChMaterialSurfaceNSC()

# Collision shapes 
body_38.GetCollisionModel().ClearModel()
mr = chrono.ChMatrix33D()
mr[0,0]=0; mr[1,0]=0; mr[2,0]=-1 
mr[0,1]=0; mr[1,1]=-1; mr[2,1]=0 
mr[0,2]=-1; mr[1,2]=0; mr[2,2]=0 
body_38.GetCollisionModel().AddCylinder(mat_38, 0.0891514706007005,0.0891514706007005,0.0737653824400992,chrono.ChVectorD(4.57739150408006E-17,0.0737653824400992,0),mr)
body_38.GetCollisionModel().BuildModel()
body_38.SetCollide(True)

exported_items.append(body_38)



# Rigid body part
body_39= chrono.ChBodyAuxRef()
body_39.SetName('M-410iB-300 -9/M-410iB-300-11-1')
body_39.SetPos(chrono.ChVectorD(-3.58203128566652,3.02810836634589,0.628597276315453))
body_39.SetRot(chrono.ChQuaternionD(-0.00814806623225839,-0.464847865120624,0.885342740928393,0.00427812983359814))
body_39.SetMass(2.26635866531324)
body_39.SetInertiaXX(chrono.ChVectorD(0.345064808753427,0.164817526658131,0.508773970272078))
body_39.SetInertiaXY(chrono.ChVectorD(-0.237169828875994,-0.00530677882361153,-0.00769347144600114))
body_39.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.650000000546566,-0.000267013560427983,-4.19077490083406e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_12_1_shape = chrono.ChObjShapeFile() 
body_12_1_shape.SetFilename(shapes_dir +'body_12_1.obj') 
body_12_1_level = chrono.ChAssetLevel() 
body_12_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_12_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_12_1_level.GetAssets().push_back(body_12_1_shape) 
body_39.GetAssets().push_back(body_12_1_level) 

exported_items.append(body_39)



# Rigid body part
body_40= chrono.ChBodyAuxRef()
body_40.SetName('M-410iB-300 -9/M-410iB-300-09-1')
body_40.SetPos(chrono.ChVectorD(-3.08152048977635,2.7581116684189,0.651647268668657))
body_40.SetRot(chrono.ChQuaternionD(-0.00920290053502591,-3.29685906413793e-06,0.999957652408777,3.03419491701508e-08))
body_40.SetMass(8.44776262879024)
body_40.SetInertiaXX(chrono.ChVectorD(0.110323182518711,0.723340878621822,0.828534278131068))
body_40.SetInertiaXY(chrono.ChVectorD(-0.0047350380765659,-0.0132623786625709,-0.00148525062232044))
body_40.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.00309747019490023,0.11726872541838,-0.0225919700688117),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_3_1_shape = chrono.ChObjShapeFile() 
body_3_1_shape.SetFilename(shapes_dir +'body_3_1.obj') 
body_3_1_level = chrono.ChAssetLevel() 
body_3_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_3_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_3_1_level.GetAssets().push_back(body_3_1_shape) 
body_40.GetAssets().push_back(body_3_1_level) 

exported_items.append(body_40)



# Rigid body part
body_41= chrono.ChBodyAuxRef()
body_41.SetName('M-410iB-300 -9/ArmBase-1')
body_41.SetPos(chrono.ChVectorD(-1.50067035795504,1.75770592148926,0.377403113437384))
body_41.SetRot(chrono.ChQuaternionD(1.11022302462516e-16,-3.10973640124651e-17,1,-1.77935638377312e-15))
body_41.SetMass(29.4636133436255)
body_41.SetInertiaXX(chrono.ChVectorD(0.754351795243641,1.45825924231452,0.754351795243641))
body_41.SetInertiaXY(chrono.ChVectorD(-4.2125923912256e-17,-2.6454533008646e-17,-2.51327146062721e-15))
body_41.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-9.77354995986777e-18,0.231605672678633,-6.24094154063845e-18),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_4_1_shape = chrono.ChObjShapeFile() 
body_4_1_shape.SetFilename(shapes_dir +'body_4_1.obj') 
body_4_1_level = chrono.ChAssetLevel() 
body_4_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_4_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_4_1_level.GetAssets().push_back(body_4_1_shape) 
body_41.GetAssets().push_back(body_4_1_level) 

# Auxiliary marker (coordinate system feature)
marker_41_1 =chrono.ChMarker()
marker_41_1.SetName('marker_M1_B')
body_41.AddMarker(marker_41_1)
marker_41_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.50067035795504,1.75770592148926,0.377403113437384),chrono.ChQuaternionD(5.65154659639482E-17,-1.00493779904429E-16,0.707106781186549,0.707106781186546)))

exported_items.append(body_41)



# Rigid body part
body_42= chrono.ChBodyAuxRef()
body_42.SetName('M-410iB-300 -9/M-410iB-300-10-1')
body_42.SetPos(chrono.ChVectorD(-1.38385506609402,2.78749692402101,0.692290584266532))
body_42.SetRot(chrono.ChQuaternionD(-0.00712517108533008,-0.632876290816386,0.774198235043348,0.00582454421077491))
body_42.SetMass(2.24487855545089)
body_42.SetInertiaXX(chrono.ChVectorD(0.0178763338135305,0.411607599764486,0.428955383855942))
body_42.SetInertiaXY(chrono.ChVectorD(0.0833272451226553,-1.60705863740812e-06,-7.92230673306738e-06))
body_42.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-7.0126896985531e-15,0.610001635976697,-2.13860676946226e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_7_1_shape = chrono.ChObjShapeFile() 
body_7_1_shape.SetFilename(shapes_dir +'body_7_1.obj') 
body_7_1_level = chrono.ChAssetLevel() 
body_7_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_7_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_7_1_level.GetAssets().push_back(body_7_1_shape) 
body_42.GetAssets().push_back(body_7_1_level) 

exported_items.append(body_42)



# Rigid body part
body_43= chrono.ChBodyAuxRef()
body_43.SetName('M-410iB-300 -9/M-410iB-300-03-1')
body_43.SetPos(chrono.ChVectorD(-1.89056087850963,2.51550127212935,0.38675017613716))
body_43.SetRot(chrono.ChQuaternionD(-0.00712515238641639,-0.632878775931211,0.774196203554121,0.00582456707994129))
body_43.SetMass(64.4233324323959)
body_43.SetInertiaXX(chrono.ChVectorD(1.25893262985013,10.3595414246395,10.6401850991553))
body_43.SetInertiaXY(chrono.ChVectorD(1.74524465478568,0.753663897458072,-0.116684142344287))
body_43.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.0515352333247145,0.525779243665004,-0.000216254075872922),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_5_1_shape = chrono.ChObjShapeFile() 
body_5_1_shape.SetFilename(shapes_dir +'body_5_1.obj') 
body_5_1_level = chrono.ChAssetLevel() 
body_5_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_5_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_5_1_level.GetAssets().push_back(body_5_1_shape) 
body_43.GetAssets().push_back(body_5_1_level) 

# Auxiliary marker (coordinate system feature)
marker_43_1 =chrono.ChMarker()
marker_43_1.SetName('marker_M2_A')
body_43.AddMarker(marker_43_1)
marker_43_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.88759757137752,2.51550127212935,0.547728263961428),chrono.ChQuaternionD(-0.00582456707994129,0.774196203554121,0.632878775931211,-0.00712515238641639)))

# Auxiliary marker (coordinate system feature)
marker_43_2 =chrono.ChMarker()
marker_43_2.SetName('marker_M3_B')
body_43.AddMarker(marker_43_2)
marker_43_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-3.08302836213116,2.75811166839776,0.569733920980174),chrono.ChQuaternionD(-0.00712515238641639,-0.632878775931211,0.774196203554121,0.00582456707994129)))

exported_items.append(body_43)



# Rigid body part
body_44= chrono.ChBodyAuxRef()
body_44.SetName('M-410iB-300 -9/M-410iB-300-02-1')
body_44.SetPos(chrono.ChVectorD(-1.50067035795504,2.15049691615663,0.377403113437382))
body_44.SetRot(chrono.ChQuaternionD(-0.00920290053507596,-8.109764871616e-17,0.999957652414212,-1.77888835718164e-15))
body_44.SetMass(286.960740367602)
body_44.SetInertiaXX(chrono.ChVectorD(20.2740333714216,23.3528740040787,23.269104233805))
body_44.SetInertiaXY(chrono.ChVectorD(5.57857811723677,-0.311003566173428,-0.538187986094341))
body_44.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.175382085214385,0.199890816413736,-0.00351536323719578),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_9_1_shape = chrono.ChObjShapeFile() 
body_9_1_shape.SetFilename(shapes_dir +'body_9_1.obj') 
body_9_1_level = chrono.ChAssetLevel() 
body_9_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_9_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_9_1_level.GetAssets().push_back(body_9_1_shape) 
body_44.GetAssets().push_back(body_9_1_level) 

# Auxiliary marker (coordinate system feature)
marker_44_1 =chrono.ChMarker()
marker_44_1.SetName('marker_M1_A')
body_44.AddMarker(marker_44_1)
marker_44_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.50067035795504,2.15049691615663,0.377403113437382),chrono.ChQuaternionD(0.707076836921469,-0.707076836921471,0.00650743337493746,0.00650743337493757)))

# Auxiliary marker (coordinate system feature)
marker_44_2 =chrono.ChMarker()
marker_44_2.SetName('marker_M2_B')
body_44.AddMarker(marker_44_2)
marker_44_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.88824845435147,2.51549691615663,0.512559390367805),chrono.ChQuaternionD(0.999957652414212,-1.77888835718164E-15,0.00920290053507596,8.109764871616E-17)))

exported_items.append(body_44)



# Rigid body part
body_45= chrono.ChBodyAuxRef()
body_45.SetName('M-410iB-300 -9/M-410iB-300-05-1')
body_45.SetPos(chrono.ChVectorD(-2.22228015683827,2.77437872020321,0.121740587561141))
body_45.SetRot(chrono.ChQuaternionD(0.00644623841410045,0.713664136106539,-0.700427589017672,-0.0065680581991154))
body_45.SetMass(44.264758578016)
body_45.SetInertiaXX(chrono.ChVectorD(0.419996509334001,2.77612917685278,2.76541220888089))
body_45.SetInertiaXY(chrono.ChVectorD(-0.0450090601105396,0.0535254883569696,0.00120447491576488))
body_45.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-5.19600690940307e-06,0.410805913274014,-0.00264008387504332),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_11_1_shape = chrono.ChObjShapeFile() 
body_11_1_shape.SetFilename(shapes_dir +'body_11_1.obj') 
body_11_1_level = chrono.ChAssetLevel() 
body_11_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_11_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_11_1_level.GetAssets().push_back(body_11_1_shape) 
body_45.GetAssets().push_back(body_11_1_level) 

exported_items.append(body_45)



# Rigid body part
body_46= chrono.ChBodyAuxRef()
body_46.SetName('M-410iB-300 -9/M-410iB-300-06-1')
body_46.SetPos(chrono.ChVectorD(-3.08667100624945,2.75811166839776,0.371851670291374))
body_46.SetRot(chrono.ChQuaternionD(-0.00814806621169793,-0.464847869375537,0.885342738694358,0.00427812987275728))
body_46.SetMass(57.487443257986)
body_46.SetInertiaXX(chrono.ChVectorD(9.30951023716423,3.85440744439184,12.7873599958768))
body_46.SetInertiaXY(chrono.ChVectorD(-5.25369228554295,-0.236335669710527,-0.295962216486022))
body_46.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.216990574023306,0.112589145111018,-0.097224117310279),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_6_1_shape = chrono.ChObjShapeFile() 
body_6_1_shape.SetFilename(shapes_dir +'body_6_1.obj') 
body_6_1_level = chrono.ChAssetLevel() 
body_6_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_6_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_6_1_level.GetAssets().push_back(body_6_1_shape) 
body_46.GetAssets().push_back(body_6_1_level) 

# Auxiliary marker (coordinate system feature)
marker_46_1 =chrono.ChMarker()
marker_46_1.SetName('marker_M3_A')
body_46.AddMarker(marker_46_1)
marker_46_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-3.08372619537801,2.75811166328358,0.531824568210539),chrono.ChQuaternionD(0.885342738694358,0.00427812987275728,0.00814806621169793,0.464847869375537)))

exported_items.append(body_46)



# Rigid body part
body_47= chrono.ChBodyAuxRef()
body_47.SetName('M-410iB-300 -9/M-410iB-300-04-1')
body_47.SetPos(chrono.ChVectorD(-1.89555341712115,2.78049691677857,0.115726156086998))
body_47.SetRot(chrono.ChQuaternionD(0.499835276820296,0.509281068622395,-0.490718919028785,0.499992431638751))
body_47.SetMass(1.58709182620022)
body_47.SetInertiaXX(chrono.ChVectorD(0.112490981423635,0.112416929520631,0.000997960809251486))
body_47.SetInertiaXY(chrono.ChVectorD(1.00020938219401e-06,-1.90140984556613e-05,-0.00105409202652946))
body_47.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.002504718931018,0.259643195204338,6.66879538414608e-09),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_10_1_shape = chrono.ChObjShapeFile() 
body_10_1_shape.SetFilename(shapes_dir +'body_10_1.obj') 
body_10_1_level = chrono.ChAssetLevel() 
body_10_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_10_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_10_1_level.GetAssets().push_back(body_10_1_shape) 
body_47.GetAssets().push_back(body_10_1_level) 

exported_items.append(body_47)



# Rigid body part
body_48= chrono.ChBodyAuxRef()
body_48.SetName('M-410iB-300 -9/M-410iB-300-07-1')
body_48.SetPos(chrono.ChVectorD(-1.89031432451593,2.51550127212935,0.400143924635621))
body_48.SetRot(chrono.ChQuaternionD(-0.00816279401074418,-0.461787176484233,0.886943014097592,0.00424996142765437))
body_48.SetMass(6.52835644128616)
body_48.SetInertiaXX(chrono.ChVectorD(0.219648919171062,0.114654560791054,0.315839368367427))
body_48.SetInertiaXY(chrono.ChVectorD(-0.130601565655687,-0.00400852357762291,-0.00540368020857384))
body_48.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.244379956813902,-0.0286291495785353,-0.0666992297731388),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_13_1_shape = chrono.ChObjShapeFile() 
body_13_1_shape.SetFilename(shapes_dir +'body_13_1.obj') 
body_13_1_level = chrono.ChAssetLevel() 
body_13_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_13_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_13_1_level.GetAssets().push_back(body_13_1_shape) 
body_48.GetAssets().push_back(body_13_1_level) 

exported_items.append(body_48)



# Rigid body part
body_49= chrono.ChBodyAuxRef()
body_49.SetName('M-410iB-300 -9/M-410iB-300-08-1')
body_49.SetPos(chrono.ChVectorD(-1.5723315078021,3.01244418440915,0.463995827078662))
body_49.SetRot(chrono.ChQuaternionD(-0.00713432483261393,-0.63165761977407,0.775192852136266,0.00581332842536353))
body_49.SetMass(7.16874140056196)
body_49.SetInertiaXX(chrono.ChVectorD(0.0717530931079861,1.02972309869606,1.09928045036475))
body_49.SetInertiaXY(chrono.ChVectorD(0.199400381411396,-0.00022492628502272,-0.000512941954407037))
body_49.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0995028745288738,0.617303418169042,1.66091348054003e-08),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_2_1_shape = chrono.ChObjShapeFile() 
body_2_1_shape.SetFilename(shapes_dir +'body_2_1.obj') 
body_2_1_level = chrono.ChAssetLevel() 
body_2_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_2_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_2_1_level.GetAssets().push_back(body_2_1_shape) 
body_49.GetAssets().push_back(body_2_1_level) 

exported_items.append(body_49)



# Rigid body part
body_50= chrono.ChBodyAuxRef()
body_50.SetName('M-410iB-300 -7/M-410iB-300-06-1')
body_50.SetPos(chrono.ChVectorD(-3.08662858178734,2.75811166844499,-2.50973659342481))
body_50.SetRot(chrono.ChQuaternionD(-0.0133137251429298,-0.461387726178252,0.887071675836397,0.00692479484802054))
body_50.SetMass(57.487443257986)
body_50.SetInertiaXX(chrono.ChVectorD(9.23158213882128,3.94273550596757,12.7769600326441))
body_50.SetInertiaXY(chrono.ChVectorD(-5.29028147443112,-0.31260612852436,-0.413457266396189))
body_50.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.216990574023306,0.112589145111018,-0.097224117310279),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_6_1_shape = chrono.ChObjShapeFile() 
body_6_1_shape.SetFilename(shapes_dir +'body_6_1.obj') 
body_6_1_level = chrono.ChAssetLevel() 
body_6_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_6_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_6_1_level.GetAssets().push_back(body_6_1_shape) 
body_50.GetAssets().push_back(body_6_1_level) 

# Auxiliary marker (coordinate system feature)
marker_50_1 =chrono.ChMarker()
marker_50_1.SetName('marker_M3_A')
body_50.AddMarker(marker_50_1)
marker_50_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-3.08182689639459,2.75811166327362,-2.34980866028893),chrono.ChQuaternionD(0.887071675836397,0.00692479484802054,0.0133137251429298,0.461387726178252)))

exported_items.append(body_50)



# Rigid body part
body_51= chrono.ChBodyAuxRef()
body_51.SetName('M-410iB-300 -7/M-410iB-300-04-1')
body_51.SetPos(chrono.ChVectorD(-1.898564530867,2.78049691677856,-2.77967214322347))
body_51.SetRot(chrono.ChQuaternionD(0.502675202279378,0.51217466243141,-0.487809391545363,0.497027920439889))
body_51.SetMass(1.58709182620022)
body_51.SetInertiaXX(chrono.ChVectorD(0.112490940020368,0.112416960053853,0.000997971679297083))
body_51.SetInertiaXY(chrono.ChVectorD(1.63024353782432e-06,-3.10064436612984e-05,-0.00105438260294262))
body_51.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.002504718931018,0.259643195204338,6.66879538414608e-09),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_10_1_shape = chrono.ChObjShapeFile() 
body_10_1_shape.SetFilename(shapes_dir +'body_10_1.obj') 
body_10_1_level = chrono.ChAssetLevel() 
body_10_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_10_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_10_1_level.GetAssets().push_back(body_10_1_shape) 
body_51.GetAssets().push_back(body_10_1_level) 

exported_items.append(body_51)



# Rigid body part
body_52= chrono.ChBodyAuxRef()
body_52.SetName('M-410iB-300 -7/M-410iB-300-05-1')
body_52.SetPos(chrono.ChVectorD(-2.22519943520991,2.77437872021626,-2.76986525328038))
body_52.SetRot(chrono.ChQuaternionD(0.0105117155778581,0.713613989939274,-0.700378372954277,-0.0107103639750882))
body_52.SetMass(44.264758578016)
body_52.SetInertiaXX(chrono.ChVectorD(0.420019769379015,2.77609966011531,2.76541846557334))
body_52.SetInertiaXY(chrono.ChVectorD(-0.0456299608146541,0.053509151506657,0.00133851252209333))
body_52.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-5.19600690940307e-06,0.410805913274014,-0.00264008387504332),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_11_1_shape = chrono.ChObjShapeFile() 
body_11_1_shape.SetFilename(shapes_dir +'body_11_1.obj') 
body_11_1_level = chrono.ChAssetLevel() 
body_11_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_11_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_11_1_level.GetAssets().push_back(body_11_1_shape) 
body_52.GetAssets().push_back(body_11_1_level) 

exported_items.append(body_52)



# Rigid body part
body_53= chrono.ChBodyAuxRef()
body_53.SetName('M-410iB-300 -7/M-410iB-300-02-1')
body_53.SetPos(chrono.ChVectorD(-1.50067035797968,2.15049691615661,-2.52259688654794))
body_53.SetRot(chrono.ChQuaternionD(-0.0150069337597208,-2.40318569521467e-17,0.999887389629018,-1.7046292949269e-15))
body_53.SetMass(286.960740367602)
body_53.SetInertiaXX(chrono.ChVectorD(20.2816571815776,23.3528740040787,23.261480423649))
body_53.SetInertiaXY(chrono.ChVectorD(5.5844498645171,-0.345686197800953,-0.473391834724932))
body_53.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.175382085214385,0.199890816413736,-0.00351536323719578),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_9_1_shape = chrono.ChObjShapeFile() 
body_9_1_shape.SetFilename(shapes_dir +'body_9_1.obj') 
body_9_1_level = chrono.ChAssetLevel() 
body_9_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_9_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_9_1_level.GetAssets().push_back(body_9_1_shape) 
body_53.GetAssets().push_back(body_9_1_level) 

# Auxiliary marker (coordinate system feature)
marker_53_1 =chrono.ChMarker()
marker_53_1.SetName('marker_M1_A')
body_53.AddMarker(marker_53_1)
marker_53_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.50067035797968,2.15049691615661,-2.52259688654794),chrono.ChQuaternionD(0.707027153629593,-0.707027153629595,0.0106115046263159,0.0106115046263159)))

# Auxiliary marker (coordinate system feature)
marker_53_2 =chrono.ChMarker()
marker_53_2.SetName('marker_M2_B')
body_53.AddMarker(marker_53_2)
marker_53_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.8866533532734,2.51549691615662,-2.38295044962934),chrono.ChQuaternionD(0.999887389629018,-1.7046292949269E-15,0.0150069337597208,2.40318569521467E-17)))

exported_items.append(body_53)



# Rigid body part
body_54= chrono.ChBodyAuxRef()
body_54.SetName('M-410iB-300 -7/M-410iB-300-03-1')
body_54.SetPos(chrono.ChVectorD(-1.89042609956163,2.51550127212934,-2.50872434230635))
body_54.SetRot(chrono.ChQuaternionD(-0.0116188031722166,-0.632834306207226,0.774141804081364,0.0094979720842894))
body_54.SetMass(64.4233324323959)
body_54.SetInertiaXX(chrono.ChVectorD(1.25545710521904,10.362186954822,10.6410150936039))
body_54.SetInertiaXY(chrono.ChVectorD(1.73694901630886,0.751810272180615,-0.115847259956654))
body_54.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.0515352333247145,0.525779243665004,-0.000216254075872922),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_5_1_shape = chrono.ChObjShapeFile() 
body_5_1_shape.SetFilename(shapes_dir +'body_5_1.obj') 
body_5_1_level = chrono.ChAssetLevel() 
body_5_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_5_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_5_1_level.GetAssets().push_back(body_5_1_shape) 
body_54.GetAssets().push_back(body_5_1_level) 

# Auxiliary marker (coordinate system feature)
marker_54_1 =chrono.ChMarker()
marker_54_1.SetName('marker_M2_A')
body_54.AddMarker(marker_54_1)
marker_54_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.8855942501943,2.51550127212934,-2.34779150171622),chrono.ChQuaternionD(-0.0094979720842894,0.774141804081364,0.632834306207226,-0.0116188031722166)))

# Auxiliary marker (coordinate system feature)
marker_54_2 =chrono.ChMarker()
marker_54_2.SetName('marker_M3_B')
body_54.AddMarker(marker_54_2)
marker_54_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-3.08068903286662,2.75811166844499,-2.31190996288065),chrono.ChQuaternionD(-0.0116188031722166,-0.632834306207226,0.774141804081364,0.0094979720842894)))

exported_items.append(body_54)



# Rigid body part
body_55= chrono.ChBodyAuxRef()
body_55.SetName('M-410iB-300 -7/M-410iB-300-07-1')
body_55.SetPos(chrono.ChVectorD(-1.89002407854074,2.51550127212934,-2.49533435848221))
body_55.SetRot(chrono.ChQuaternionD(-0.0133376474409522,-0.458310244328082,0.888665579328391,0.00687860608041415))
body_55.SetMass(6.52835644128616)
body_55.SetInertiaXX(chrono.ChVectorD(0.217683124633267,0.116815491298789,0.315644232397487))
body_55.SetInertiaXY(chrono.ChVectorD(-0.131307758250726,-0.00595307800070661,-0.00813880603055965))
body_55.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.244379956813902,-0.0286291495785353,-0.0666992297731388),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_13_1_shape = chrono.ChObjShapeFile() 
body_13_1_shape.SetFilename(shapes_dir +'body_13_1.obj') 
body_13_1_level = chrono.ChAssetLevel() 
body_13_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_13_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_13_1_level.GetAssets().push_back(body_13_1_shape) 
body_55.GetAssets().push_back(body_13_1_level) 

exported_items.append(body_55)



# Rigid body part
body_56= chrono.ChBodyAuxRef()
body_56.SetName('M-410iB-300 -7/M-410iB-300-08-1')
body_56.SetPos(chrono.ChVectorD(-1.56747657276173,3.00997129523558,-2.43529355568076))
body_56.SetRot(chrono.ChQuaternionD(-0.0116338915645698,-0.631602514215778,0.775147118923524,0.00947948458158366))
body_56.SetMass(7.16874140056196)
body_56.SetInertiaXX(chrono.ChVectorD(0.0717655134908897,1.02972740480959,1.09926372386832))
body_56.SetInertiaXY(chrono.ChVectorD(0.199431827409638,-0.000366729661724007,-0.000836129464553487))
body_56.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0995028745288738,0.617303418169042,1.66091348054003e-08),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_2_1_shape = chrono.ChObjShapeFile() 
body_2_1_shape.SetFilename(shapes_dir +'body_2_1.obj') 
body_2_1_level = chrono.ChAssetLevel() 
body_2_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_2_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_2_1_level.GetAssets().push_back(body_2_1_shape) 
body_56.GetAssets().push_back(body_2_1_level) 

exported_items.append(body_56)



# Rigid body part
body_57= chrono.ChBodyAuxRef()
body_57.SetName('M-410iB-300 -7/M-410iB-300-09-1')
body_57.SetPos(chrono.ChVectorD(-3.07823035692509,2.75811166843342,-2.23001963914353))
body_57.SetRot(chrono.ChQuaternionD(-0.0150069337596394,-3.29662741355177e-06,0.999887389623583,4.94778391930159e-08))
body_57.SetMass(8.44776262879024)
body_57.SetInertiaXX(chrono.ChVectorD(0.110727866042482,0.723340878853414,0.828129594375704))
body_57.SetInertiaXY(chrono.ChVectorD(-0.00471747584688973,-0.0215957201449394,-0.00154012607930295))
body_57.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.00309747019490023,0.11726872541838,-0.0225919700688117),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_3_1_shape = chrono.ChObjShapeFile() 
body_3_1_shape.SetFilename(shapes_dir +'body_3_1.obj') 
body_3_1_level = chrono.ChAssetLevel() 
body_3_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_3_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_3_1_level.GetAssets().push_back(body_3_1_shape) 
body_57.GetAssets().push_back(body_3_1_level) 

exported_items.append(body_57)



# Rigid body part
body_58= chrono.ChBodyAuxRef()
body_58.SetName('M-410iB-300 -7/M-410iB-300-11-1')
body_58.SetPos(chrono.ChVectorD(-3.57897500671502,3.02810836639312,-2.24725781238191))
body_58.SetRot(chrono.ChQuaternionD(-0.0133137251762607,-0.461387721908534,0.887071678057182,0.00692479478393801))
body_58.SetMass(2.26635866531324)
body_58.SetInertiaXX(chrono.ChVectorD(0.341479022897417,0.168688689704207,0.508488593082012))
body_58.SetInertiaXY(chrono.ChVectorD(-0.238401529357813,-0.0087473120811095,-0.0124738663180699))
body_58.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.650000000546566,-0.000267013560427983,-4.19077490083406e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_12_1_shape = chrono.ChObjShapeFile() 
body_12_1_shape.SetFilename(shapes_dir +'body_12_1.obj') 
body_12_1_level = chrono.ChAssetLevel() 
body_12_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_12_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_12_1_level.GetAssets().push_back(body_12_1_shape) 
body_58.GetAssets().push_back(body_12_1_level) 

exported_items.append(body_58)



# Rigid body part
body_59= chrono.ChBodyAuxRef()
body_59.SetName('M-410iB-300 -7/M-410iB-300-10-1')
body_59.SetPos(chrono.ChVectorD(-1.38020751187768,2.78749692403349,-2.20908670423232))
body_59.SetRot(chrono.ChQuaternionD(-0.0116188336598026,-0.632831821277613,0.774143835419226,0.00949793478891549))
body_59.SetMass(2.24487855545089)
body_59.SetInertiaXX(chrono.ChVectorD(0.0178763435747364,0.411607836830152,0.428955137029071))
body_59.SetInertiaXY(chrono.ChVectorD(0.0833272932271954,-2.61999494732671e-06,-1.29140974488009e-05))
body_59.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-7.0126896985531e-15,0.610001635976697,-2.13860676946226e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_7_1_shape = chrono.ChObjShapeFile() 
body_7_1_shape.SetFilename(shapes_dir +'body_7_1.obj') 
body_7_1_level = chrono.ChAssetLevel() 
body_7_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_7_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_7_1_level.GetAssets().push_back(body_7_1_shape) 
body_59.GetAssets().push_back(body_7_1_level) 

exported_items.append(body_59)



# Rigid body part
body_60= chrono.ChBodyAuxRef()
body_60.SetName('M-410iB-300 -7/M-410iB-300-12-1')
body_60.SetPos(chrono.ChVectorD(-4.08655957447754,1.53473191895536,-2.4461185220936))
body_60.SetRot(chrono.ChQuaternionD(-0.0150069339332635,-3.30505294272061e-06,0.99988738962095,4.96042942804574e-08))
body_60.SetMass(16.1636065115335)
body_60.SetInertiaXX(chrono.ChVectorD(0.275223136073722,0.40077069496942,0.422989666563406))
body_60.SetInertiaXY(chrono.ChVectorD(0.0541759973455762,0.0456561392753001,-0.0655253370462481))
body_60.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0294847451383035,0.131793864973377,-0.039955675141979),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_8_1_shape = chrono.ChObjShapeFile() 
body_8_1_shape.SetFilename(shapes_dir +'body_8_1.obj') 
body_8_1_level = chrono.ChAssetLevel() 
body_8_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_8_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_8_1_level.GetAssets().push_back(body_8_1_shape) 
body_60.GetAssets().push_back(body_8_1_level) 

# Collision material 
mat_60 = chrono.ChMaterialSurfaceNSC()

# Collision shapes 
body_60.GetCollisionModel().ClearModel()
mr = chrono.ChMatrix33D()
mr[0,0]=0; mr[1,0]=0; mr[2,0]=-1 
mr[0,1]=0; mr[1,1]=-1; mr[2,1]=0 
mr[0,2]=-1; mr[1,2]=0; mr[2,2]=0 
body_60.GetCollisionModel().AddCylinder(mat_60, 0.0891514706007005,0.0891514706007005,0.0737653824400992,chrono.ChVectorD(4.57739150408006E-17,0.0737653824400992,0),mr)
body_60.GetCollisionModel().BuildModel()
body_60.SetCollide(True)

exported_items.append(body_60)



# Rigid body part
body_61= chrono.ChBodyAuxRef()
body_61.SetName('M-410iB-300 -7/ArmBase-1')
body_61.SetPos(chrono.ChVectorD(-1.50067035795504,1.75770592148925,-2.52259688656262))
body_61.SetRot(chrono.ChQuaternionD(1.08554747315437e-16,-3.21041963728343e-17,1,-1.72084568816899e-15))
body_61.SetMass(29.4636133436255)
body_61.SetInertiaXX(chrono.ChVectorD(0.754351795243641,1.45825924231452,0.754351795243641))
body_61.SetInertiaXY(chrono.ChVectorD(-4.35433575050877e-17,-2.64545330086461e-17,-2.43089923188912e-15))
body_61.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-9.77354995986777e-18,0.231605672678633,-6.24094154063845e-18),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_4_1_shape = chrono.ChObjShapeFile() 
body_4_1_shape.SetFilename(shapes_dir +'body_4_1.obj') 
body_4_1_level = chrono.ChAssetLevel() 
body_4_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_4_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_4_1_level.GetAssets().push_back(body_4_1_shape) 
body_61.GetAssets().push_back(body_4_1_level) 

# Auxiliary marker (coordinate system feature)
marker_61_1 =chrono.ChMarker()
marker_61_1.SetName('marker_M1_B')
body_61.AddMarker(marker_61_1)
marker_61_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.50067035795504,1.75770592148925,-2.52259688656262),chrono.ChQuaternionD(5.40587029969616E-17,-9.9460892916513E-17,0.707106781186549,0.707106781186546)))

exported_items.append(body_61)



# Rigid body part
body_62= chrono.ChBodyAuxRef()
body_62.SetName('M-410iB-300 -1/M-410iB-300-04-1')
body_62.SetPos(chrono.ChVectorD(0.244076732280884,2.78049691677857,0.653767251829919))
body_62.SetRot(chrono.ChQuaternionD(0.515130300611062,0.49424039777516,0.505299792002175,-0.484808542418518))
body_62.SetMass(1.58709182620022)
body_62.SetInertiaXX(chrono.ChVectorD(0.112490979032812,0.112311933817442,0.00110295890326267))
body_62.SetInertiaXY(chrono.ChVectorD(-5.95279505476425e-07,-1.99309473486846e-05,0.00357754526448565))
body_62.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.002504718931018,0.259643195204338,6.66879538414608e-09),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_10_1_shape = chrono.ChObjShapeFile() 
body_10_1_shape.SetFilename(shapes_dir +'body_10_1.obj') 
body_10_1_level = chrono.ChAssetLevel() 
body_10_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_10_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_10_1_level.GetAssets().push_back(body_10_1_shape) 
body_62.GetAssets().push_back(body_10_1_level) 

exported_items.append(body_62)



# Rigid body part
body_63= chrono.ChBodyAuxRef()
body_63.SetName('M-410iB-300 -1/M-410iB-300-05-1')
body_63.SetPos(chrono.ChVectorD(0.55470784029864,2.79336243660645,0.659752855810517))
body_63.SetRot(chrono.ChQuaternionD(0.721553038213636,0.00666932888185166,-0.00695121929985649,-0.692292144724452))
body_63.SetMass(44.264758578016)
body_63.SetInertiaXX(chrono.ChVectorD(0.423079572631192,2.77304492040232,2.76541340203417))
body_63.SetInertiaXY(chrono.ChVectorD(0.0963375818423032,-0.0534976585604908,0.00198115806336956))
body_63.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-5.19600690940307e-06,0.410805913274014,-0.00264008387504332),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_11_1_shape = chrono.ChObjShapeFile() 
body_11_1_shape.SetFilename(shapes_dir +'body_11_1.obj') 
body_11_1_level = chrono.ChAssetLevel() 
body_11_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_11_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_11_1_level.GetAssets().push_back(body_11_1_shape) 
body_63.GetAssets().push_back(body_11_1_level) 

exported_items.append(body_63)



# Rigid body part
body_64= chrono.ChBodyAuxRef()
body_64.SetName('M-410iB-300 -1/M-410iB-300-02-1')
body_64.SetPos(chrono.ChVectorD(-0.140670357906007,2.15049691615666,0.377403113503883))
body_64.SetRot(chrono.ChQuaternionD(0.99995359922474,-1.7456505278865e-15,-0.00963324439059877,1.58685900705275e-17))
body_64.SetMass(286.960740367602)
body_64.SetInertiaXX(chrono.ChVectorD(20.2548714805427,23.3528740040787,23.2882661246839))
body_64.SetInertiaXY(chrono.ChVectorD(-5.55434962669852,-0.197395083705248,0.747917336931844))
body_64.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.175382085214385,0.199890816413736,-0.00351536323719578),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_9_1_shape = chrono.ChObjShapeFile() 
body_9_1_shape.SetFilename(shapes_dir +'body_9_1.obj') 
body_9_1_level = chrono.ChAssetLevel() 
body_9_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_9_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_9_1_level.GetAssets().push_back(body_9_1_shape) 
body_64.GetAssets().push_back(body_9_1_level) 

# Auxiliary marker (coordinate system feature)
marker_64_1 =chrono.ChMarker()
marker_64_1.SetName('marker_M1_A')
body_64.AddMarker(marker_64_1)
marker_64_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-0.140670357906007,2.15049691615666,0.377403113503883),chrono.ChQuaternionD(0.00681173243341965,-0.00681173243341967,0.70707397088371,0.707073970883707)))

# Auxiliary marker (coordinate system feature)
marker_64_2 =chrono.ChMarker()
marker_64_2.SetName('marker_M2_B')
body_64.AddMarker(marker_64_2)
marker_64_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(0.251723254698472,2.51549691615666,0.256940452122116),chrono.ChQuaternionD(0.00963324439059877,-1.58685900705275E-17,0.99995359922474,-1.7456505278865E-15)))

exported_items.append(body_64)



# Rigid body part
body_65= chrono.ChBodyAuxRef()
body_65.SetName('M-410iB-300 -1/M-410iB-300-03-1')
body_65.SetPos(chrono.ChVectorD(0.249295567718061,2.51550127212935,0.382747494906893))
body_65.SetRot(chrono.ChQuaternionD(0.792814332792253,0.00587064723908121,-0.00763772862068731,-0.609387097272075))
body_65.SetMass(64.4233324323959)
body_65.SetInertiaXX(chrono.ChVectorD(1.65167567735143,9.96941582488971,10.6375676514037))
body_65.SetInertiaXY(chrono.ChVectorD(2.54144464391589,-0.732989095196068,0.230214914916542))
body_65.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.0515352333247145,0.525779243665004,-0.000216254075872922),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_5_1_shape = chrono.ChObjShapeFile() 
body_5_1_shape.SetFilename(shapes_dir +'body_5_1.obj') 
body_5_1_level = chrono.ChAssetLevel() 
body_5_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_5_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_5_1_level.GetAssets().push_back(body_5_1_shape) 
body_65.GetAssets().push_back(body_5_1_level) 

# Auxiliary marker (coordinate system feature)
marker_65_1 =chrono.ChMarker()
marker_65_1.SetName('marker_M2_A')
body_65.AddMarker(marker_65_1)
marker_65_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(0.252397431744639,2.51550127212935,0.221772017307732),chrono.ChQuaternionD(0.609387097272075,-0.00763772862068731,-0.00587064723908121,0.792814332792253)))

# Auxiliary marker (coordinate system feature)
marker_65_2 =chrono.ChMarker()
marker_65_2.SetName('marker_M3_B')
body_65.AddMarker(marker_65_2)
marker_65_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(1.43112677510438,2.82931662753848,0.244485154748101),chrono.ChQuaternionD(0.792814332792253,0.00587064723908121,-0.00763772862068731,-0.609387097272075)))

exported_items.append(body_65)



# Rigid body part
body_66= chrono.ChBodyAuxRef()
body_66.SetName('M-410iB-300 -1/M-410iB-300-08-1')
body_66.SetPos(chrono.ChVectorD(-0.0644327245476014,3.01331234559424,0.293597201563423))
body_66.SetRot(chrono.ChQuaternionD(0.793707796902421,0.00585943202003774,-0.00764633597820303,-0.608222930954446))
body_66.SetMass(7.16874140056196)
body_66.SetInertiaXX(chrono.ChVectorD(0.105302263626959,0.996174893616159,1.09927948492568))
body_66.SetInertiaXY(chrono.ChVectorD(0.266034084005294,3.11625376234435e-05,0.000585451799741407))
body_66.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0995028745288738,0.617303418169042,1.66091348054003e-08),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_2_1_shape = chrono.ChObjShapeFile() 
body_2_1_shape.SetFilename(shapes_dir +'body_2_1.obj') 
body_2_1_level = chrono.ChAssetLevel() 
body_2_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_2_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_2_1_level.GetAssets().push_back(body_2_1_shape) 
body_66.GetAssets().push_back(body_2_1_level) 

exported_items.append(body_66)



# Rigid body part
body_67= chrono.ChBodyAuxRef()
body_67.SetName('M-410iB-300 -1/M-410iB-300-10-1')
body_67.SetPos(chrono.ChVectorD(-0.245542863013002,2.78749692403041,0.058339343420592))
body_67.SetRot(chrono.ChQuaternionD(0.792816163556978,0.00587062429319419,-0.00763774625771013,-0.609384715434598))
body_67.SetMass(2.24487855545089)
body_67.SetInertiaXX(chrono.ChVectorD(0.0292576330577341,0.400226314761131,0.428955369615094))
body_67.SetInertiaXY(chrono.ChVectorD(0.106278264803801,2.17605381270451e-06,8.17690080679584e-06))
body_67.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-7.0126896985531e-15,0.610001635976697,-2.13860676946226e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_7_1_shape = chrono.ChObjShapeFile() 
body_7_1_shape.SetFilename(shapes_dir +'body_7_1.obj') 
body_7_1_level = chrono.ChAssetLevel() 
body_7_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_7_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_7_1_level.GetAssets().push_back(body_7_1_shape) 
body_67.GetAssets().push_back(body_7_1_level) 

exported_items.append(body_67)



# Rigid body part
body_68= chrono.ChBodyAuxRef()
body_68.SetName('M-410iB-300 -1/M-410iB-300-12-1')
body_68.SetPos(chrono.ChVectorD(2.41815979602135,1.59830274717827,0.427869743944744))
body_68.SetRot(chrono.ChQuaternionD(0.999953599222751,2.6070016834079e-08,-0.00963324421692762,-2.70612966759351e-06))
body_68.SetMass(16.1636065115335)
body_68.SetInertiaXX(chrono.ChVectorD(0.280075697179052,0.400769427850542,0.418138372576954))
body_68.SetInertiaXY(chrono.ChVectorD(-0.0508837912136482,0.0527041268799599,0.0681152193038784))
body_68.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0294847451383035,0.131793864973377,-0.039955675141979),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_8_1_shape = chrono.ChObjShapeFile() 
body_8_1_shape.SetFilename(shapes_dir +'body_8_1.obj') 
body_8_1_level = chrono.ChAssetLevel() 
body_8_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_8_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_8_1_level.GetAssets().push_back(body_8_1_shape) 
body_68.GetAssets().push_back(body_8_1_level) 

# Collision material 
mat_68 = chrono.ChMaterialSurfaceNSC()

# Collision shapes 
body_68.GetCollisionModel().ClearModel()
mr = chrono.ChMatrix33D()
mr[0,0]=0; mr[1,0]=0; mr[2,0]=-1 
mr[0,1]=0; mr[1,1]=-1; mr[2,1]=0 
mr[0,2]=-1; mr[1,2]=0; mr[2,2]=0 
body_68.GetCollisionModel().AddCylinder(mat_68, 0.0891514706007005,0.0891514706007005,0.0737653824400992,chrono.ChVectorD(4.57739150408006E-17,0.0737653824400992,0),mr)
body_68.GetCollisionModel().BuildModel()
body_68.SetCollide(True)

exported_items.append(body_68)



# Rigid body part
body_69= chrono.ChBodyAuxRef()
body_69.SetName('M-410iB-300 -1/M-410iB-300-11-1')
body_69.SetPos(chrono.ChVectorD(1.93199233933189,3.09931392483892,0.204457973678208))
body_69.SetRot(chrono.ChQuaternionD(0.884741343579374,0.00448913434538585,-0.00852332507405904,-0.465982784621787))
body_69.SetMass(2.26635866531324)
body_69.SetInertiaXX(chrono.ChVectorD(0.346287428344189,0.163611371998758,0.508757505340689))
body_69.SetInertiaXY(chrono.ChVectorD(-0.236695977291224,0.00553411091655167,0.00806731092253501))
body_69.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.650000000546566,-0.000267013560427983,-4.19077490083406e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_12_1_shape = chrono.ChObjShapeFile() 
body_12_1_shape.SetFilename(shapes_dir +'body_12_1.obj') 
body_12_1_level = chrono.ChAssetLevel() 
body_12_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_12_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_12_1_level.GetAssets().push_back(body_12_1_shape) 
body_69.GetAssets().push_back(body_12_1_level) 

exported_items.append(body_69)



# Rigid body part
body_70= chrono.ChBodyAuxRef()
body_70.SetName('M-410iB-300 -1/M-410iB-300-07-1')
body_70.SetPos(chrono.ChVectorD(0.249553649965216,2.51550127212935,0.369353963585185))
body_70.SetRot(chrono.ChQuaternionD(0.886304383108221,0.0044604276357658,-0.00853838291452759,-0.463002960126247))
body_70.SetMass(6.52835644128616)
body_70.SetInertiaXX(chrono.ChVectorD(0.211668310690513,0.122539394310761,0.315935143328269))
body_70.SetInertiaXY(chrono.ChVectorD(-0.133566886491727,0.00268506176902588,0.00322950564632999))
body_70.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.244379956813902,-0.0286291495785353,-0.0666992297731388),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_13_1_shape = chrono.ChObjShapeFile() 
body_13_1_shape.SetFilename(shapes_dir +'body_13_1.obj') 
body_13_1_level = chrono.ChAssetLevel() 
body_13_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_13_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_13_1_level.GetAssets().push_back(body_13_1_shape) 
body_70.GetAssets().push_back(body_13_1_level) 

exported_items.append(body_70)



# Rigid body part
body_71= chrono.ChBodyAuxRef()
body_71.SetName('M-410iB-300 -1/M-410iB-300-09-1')
body_71.SetPos(chrono.ChVectorD(1.43270515185049,2.82931662754992,0.162573135317061))
body_71.SetRot(chrono.ChQuaternionD(0.999953599221101,2.59871037003212e-08,-0.00963324439056381,-2.69752313658094e-06))
body_71.SetMass(8.44776262879024)
body_71.SetInertiaXX(chrono.ChVectorD(0.110343584171981,0.723340992640604,0.828513762459016))
body_71.SetInertiaXY(chrono.ChVectorD(0.00478026880841137,0.0138066982542173,0.00130599595212749))
body_71.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.00309747019490023,0.11726872541838,-0.0225919700688117),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_3_1_shape = chrono.ChObjShapeFile() 
body_3_1_shape.SetFilename(shapes_dir +'body_3_1.obj') 
body_3_1_level = chrono.ChAssetLevel() 
body_3_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_3_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_3_1_level.GetAssets().push_back(body_3_1_shape) 
body_71.GetAssets().push_back(body_3_1_level) 

exported_items.append(body_71)



# Rigid body part
body_72= chrono.ChBodyAuxRef()
body_72.SetName('M-410iB-300 -1/ArmBase-1')
body_72.SetPos(chrono.ChVectorD(-0.140670357955037,1.75770592148926,0.37740311343739))
body_72.SetRot(chrono.ChQuaternionD(1,0,0,0))
body_72.SetMass(29.4636133436255)
body_72.SetInertiaXX(chrono.ChVectorD(0.754351795243641,1.45825924231452,0.754351795243641))
body_72.SetInertiaXY(chrono.ChVectorD(-1.65340831304039e-18,-2.64545330086463e-17,8.26704156520197e-18))
body_72.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-9.77354995986777e-18,0.231605672678633,-6.24094154063845e-18),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_4_1_shape = chrono.ChObjShapeFile() 
body_4_1_shape.SetFilename(shapes_dir +'body_4_1.obj') 
body_4_1_level = chrono.ChAssetLevel() 
body_4_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_4_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_4_1_level.GetAssets().push_back(body_4_1_shape) 
body_72.GetAssets().push_back(body_4_1_level) 

# Auxiliary marker (coordinate system feature)
marker_72_1 =chrono.ChMarker()
marker_72_1.SetName('marker_M1_B')
body_72.AddMarker(marker_72_1)
marker_72_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-0.140670357955037,1.75770592148926,0.37740311343739),chrono.ChQuaternionD(0.707106781186548,-0.707106781186547,0,0)))

exported_items.append(body_72)



# Rigid body part
body_73= chrono.ChBodyAuxRef()
body_73.SetName('M-410iB-300 -1/M-410iB-300-06-1')
body_73.SetPos(chrono.ChVectorD(1.42731380997847,2.82931662753848,0.442364196818721))
body_73.SetRot(chrono.ChQuaternionD(0.884741341340965,0.00448913438632869,-0.00852332505249492,-0.465982788871757))
body_73.SetMass(57.487443257986)
body_73.SetInertiaXX(chrono.ChVectorD(8.05892517294391,5.09369644065772,12.7986560638313))
body_73.SetInertiaXY(chrono.ChVectorD(-5.7364711265332,0.0872503781490775,0.034873008768974))
body_73.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.216990574023306,0.112589145111018,-0.097224117310279),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_6_1_shape = chrono.ChObjShapeFile() 
body_6_1_shape.SetFilename(shapes_dir +'body_6_1.obj') 
body_6_1_level = chrono.ChAssetLevel() 
body_6_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_6_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_6_1_level.GetAssets().push_back(body_6_1_shape) 
body_73.GetAssets().push_back(body_6_1_level) 

# Auxiliary marker (coordinate system feature)
marker_73_1 =chrono.ChMarker()
marker_73_1.SetName('marker_M3_A')
body_73.AddMarker(marker_73_1)
marker_73_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(1.43039629771942,2.82931662244337,0.282393892546175),chrono.ChQuaternionD(0.00852332505249492,0.465982788871757,0.884741341340965,0.00448913438632869)))

exported_items.append(body_73)




# Mate constraint: Coincident1 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_1 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_72 , SW name: M-410iB-300 -1/ArmBase-1 ,  SW ref.type:2 (2)

link_1 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.620670357955037,1.94456417249918,0.727403113437383)
cB = chrono.ChVectorD(-0.140670357955037,1.94456417249918,0.37740311343739)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
dB = chrono.ChVectorD(0,-1,0)
link_1.Initialize(body_1,body_72,False,cA,cB,dB)
link_1.SetDistance(0)
link_1.SetName("Coincident1")
exported_items.append(link_1)

link_2 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.620670357955037,1.94456417249918,0.727403113437383)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
cB = chrono.ChVectorD(-0.140670357955037,1.94456417249918,0.37740311343739)
dB = chrono.ChVectorD(0,-1,0)
link_2.SetFlipped(True)
link_2.Initialize(body_1,body_72,False,cA,cB,dA,dB)
link_2.SetName("Coincident1")
exported_items.append(link_2)


# Mate constraint: Distance1 [MateDistanceDim] type:5 align:0 flip:False
#   Entity 0: C::E name: body_72 , SW name: M-410iB-300 -1/ArmBase-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_1 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)

link_3 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.460670357955037,1.94456417249918,0.69740311343739)
cB = chrono.ChVectorD(-0.620670357955037,1.69456417249918,0.727403113437384)
dA = chrono.ChVectorD(0,0,1)
dB = chrono.ChVectorD(0,3.49148133884313e-15,1)
link_3.Initialize(body_72,body_1,False,cA,cB,dB)
link_3.SetDistance(-0.03)
link_3.SetName("Distance1")
exported_items.append(link_3)

link_4 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.460670357955037,1.94456417249918,0.69740311343739)
dA = chrono.ChVectorD(0,0,1)
cB = chrono.ChVectorD(-0.620670357955037,1.69456417249918,0.727403113437384)
dB = chrono.ChVectorD(0,3.49148133884313e-15,1)
link_4.Initialize(body_72,body_1,False,cA,cB,dA,dB)
link_4.SetName("Distance1")
exported_items.append(link_4)


# Mate constraint: Coincident3 [MateCoincident] type:0 align:2 flip:False
#   Entity 0: C::E name: body_1 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_72 , SW name: M-410iB-300 -1/ArmBase-1 ,  SW ref.type:1 (1)

link_5 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.179329642044963,1.69456417249918,0.727403113437384)
cB = chrono.ChVectorD(0.179329642044963,1.94456417249918,0.37740311343739)
dA = chrono.ChVectorD(1,5.53760424633245e-31,1.58603289232165e-16)
dB = chrono.ChVectorD(1,0,0)
link_5.Initialize(body_72,body_1,False,cB,cA,dA)
link_5.SetDistance(0)
link_5.SetName("Coincident3")
exported_items.append(link_5)


# ChLinkMateOrthogonal skipped because directions not orthogonal! 

# Mate constraint: Coincident4_issue [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_4 , SW name: M-410iB-300 -2/ArmBase-1 ,  SW ref.type:1 (1)
#   Entity 1: C::E name: body_1 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)

link_6 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.179329642044963,1.94456417249918,-1.07259688656261)
cB = chrono.ChVectorD(0.179329642044963,1.69456417249918,-0.722596886562616)
dA = chrono.ChVectorD(1,0,0)
dB = chrono.ChVectorD(1,5.53760424633245e-31,1.58603289232165e-16)
link_6.Initialize(body_4,body_1,False,cA,cB,dB)
link_6.SetDistance(0)
link_6.SetName("Coincident4_issue")
exported_items.append(link_6)


# ChLinkMateOrthogonal skipped because directions not orthogonal! 

# Mate constraint: Coincident5 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_1 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_4 , SW name: M-410iB-300 -2/ArmBase-1 ,  SW ref.type:2 (2)

link_7 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.620670357955037,1.94456417249918,-0.722596886562617)
cB = chrono.ChVectorD(-0.140670357955037,1.94456417249918,-1.07259688656261)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
dB = chrono.ChVectorD(0,-1,0)
link_7.Initialize(body_1,body_4,False,cA,cB,dB)
link_7.SetDistance(0)
link_7.SetName("Coincident5")
exported_items.append(link_7)

link_8 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.620670357955037,1.94456417249918,-0.722596886562617)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
cB = chrono.ChVectorD(-0.140670357955037,1.94456417249918,-1.07259688656261)
dB = chrono.ChVectorD(0,-1,0)
link_8.SetFlipped(True)
link_8.Initialize(body_1,body_4,False,cA,cB,dA,dB)
link_8.SetName("Coincident5")
exported_items.append(link_8)


# Mate constraint: Distance2 [MateDistanceDim] type:5 align:0 flip:False
#   Entity 0: C::E name: body_4 , SW name: M-410iB-300 -2/ArmBase-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_1 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)

link_9 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.460670357955037,1.94456417249918,-1.39259688656261)
cB = chrono.ChVectorD(-0.620670357955037,1.69456417249917,-1.42259688656262)
dA = chrono.ChVectorD(0,0,-1)
dB = chrono.ChVectorD(0,-3.49148133884313e-15,-1)
link_9.Initialize(body_4,body_1,False,cA,cB,dB)
link_9.SetDistance(-0.03)
link_9.SetName("Distance2")
exported_items.append(link_9)

link_10 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.460670357955037,1.94456417249918,-1.39259688656261)
dA = chrono.ChVectorD(0,0,-1)
cB = chrono.ChVectorD(-0.620670357955037,1.69456417249917,-1.42259688656262)
dB = chrono.ChVectorD(0,-3.49148133884313e-15,-1)
link_10.Initialize(body_4,body_1,False,cA,cB,dA,dB)
link_10.SetName("Distance2")
exported_items.append(link_10)


# Mate constraint: Coincident7 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_1 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_18 , SW name: M-410iB-300 -3/ArmBase-1 ,  SW ref.type:2 (2)

link_11 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.620670357955037,1.94456417249917,-2.17259688656262)
cB = chrono.ChVectorD(-0.140670357955037,1.94456417249918,-2.52259688656261)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
dB = chrono.ChVectorD(0,-1,0)
link_11.Initialize(body_1,body_18,False,cA,cB,dB)
link_11.SetDistance(0)
link_11.SetName("Coincident7")
exported_items.append(link_11)

link_12 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.620670357955037,1.94456417249917,-2.17259688656262)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
cB = chrono.ChVectorD(-0.140670357955037,1.94456417249918,-2.52259688656261)
dB = chrono.ChVectorD(0,-1,0)
link_12.SetFlipped(True)
link_12.Initialize(body_1,body_18,False,cA,cB,dA,dB)
link_12.SetName("Coincident7")
exported_items.append(link_12)


# Mate constraint: Distance3 [MateDistanceDim] type:5 align:0 flip:False
#   Entity 0: C::E name: body_18 , SW name: M-410iB-300 -3/ArmBase-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_1 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)

link_13 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.460670357955037,1.94456417249918,-2.84259688656261)
cB = chrono.ChVectorD(-0.620670357955037,1.69456417249917,-2.87259688656262)
dA = chrono.ChVectorD(0,0,-1)
dB = chrono.ChVectorD(0,-3.49148133884313e-15,-1)
link_13.Initialize(body_18,body_1,False,cA,cB,dB)
link_13.SetDistance(-0.03)
link_13.SetName("Distance3")
exported_items.append(link_13)

link_14 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.460670357955037,1.94456417249918,-2.84259688656261)
dA = chrono.ChVectorD(0,0,-1)
cB = chrono.ChVectorD(-0.620670357955037,1.69456417249917,-2.87259688656262)
dB = chrono.ChVectorD(0,-3.49148133884313e-15,-1)
link_14.Initialize(body_18,body_1,False,cA,cB,dA,dB)
link_14.SetName("Distance3")
exported_items.append(link_14)


# Mate constraint: Coincident9 [MateCoincident] type:0 align:2 flip:False
#   Entity 0: C::E name: body_1 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_18 , SW name: M-410iB-300 -3/ArmBase-1 ,  SW ref.type:1 (1)

link_15 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.179329642044963,1.69456417249917,-2.17259688656262)
cB = chrono.ChVectorD(0.179329642044963,1.94456417249918,-2.52259688656261)
dA = chrono.ChVectorD(1,5.53760424633245e-31,1.58603289232165e-16)
dB = chrono.ChVectorD(1,0,0)
link_15.Initialize(body_18,body_1,False,cB,cA,dA)
link_15.SetDistance(0)
link_15.SetName("Coincident9")
exported_items.append(link_15)


# ChLinkMateOrthogonal skipped because directions not orthogonal! 

# Mate constraint: Coincident11 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_1 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_61 , SW name: M-410iB-300 -7/ArmBase-1 ,  SW ref.type:2 (2)

link_16 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.82067035795504,1.69456417249917,-2.17259688656262)
cB = chrono.ChVectorD(-1.82067035795504,1.94456417249917,-2.20259688656262)
dA = chrono.ChVectorD(-1,-3.01405864546147e-31,-8.63260705973055e-17)
dB = chrono.ChVectorD(-1,-6.4208392745669e-17,-2.17109494630873e-16)
link_16.Initialize(body_1,body_61,False,cA,cB,dB)
link_16.SetDistance(0)
link_16.SetName("Coincident11")
exported_items.append(link_16)

link_17 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.82067035795504,1.69456417249917,-2.17259688656262)
dA = chrono.ChVectorD(-1,-3.01405864546147e-31,-8.63260705973055e-17)
cB = chrono.ChVectorD(-1.82067035795504,1.94456417249917,-2.20259688656262)
dB = chrono.ChVectorD(-1,-6.4208392745669e-17,-2.17109494630873e-16)
link_17.Initialize(body_1,body_61,False,cA,cB,dA,dB)
link_17.SetName("Coincident11")
exported_items.append(link_17)


# Mate constraint: Coincident12 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_1 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_35 , SW name: M-410iB-300 -8/ArmBase-1 ,  SW ref.type:2 (2)

link_18 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.02067035795504,1.94456417249918,-0.722596886562617)
cB = chrono.ChVectorD(-1.50067035795504,1.94456417249918,-1.07259688656262)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
dB = chrono.ChVectorD(-5.42136132923115e-17,-1,3.51853802391695e-15)
link_18.Initialize(body_1,body_35,False,cA,cB,dB)
link_18.SetDistance(0)
link_18.SetName("Coincident12")
exported_items.append(link_18)

link_19 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.02067035795504,1.94456417249918,-0.722596886562617)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
cB = chrono.ChVectorD(-1.50067035795504,1.94456417249918,-1.07259688656262)
dB = chrono.ChVectorD(-5.42136132923115e-17,-1,3.51853802391695e-15)
link_19.SetFlipped(True)
link_19.Initialize(body_1,body_35,False,cA,cB,dA,dB)
link_19.SetName("Coincident12")
exported_items.append(link_19)


# Mate constraint: Coincident14 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_1 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_41 , SW name: M-410iB-300 -9/ArmBase-1 ,  SW ref.type:2 (2)

link_20 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.02067035795504,1.94456417249918,0.727403113437383)
cB = chrono.ChVectorD(-1.50067035795504,1.94456417249918,0.377403113437383)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
dB = chrono.ChVectorD(6.21947280249299e-17,-1,3.55871276754624e-15)
link_20.Initialize(body_1,body_41,False,cA,cB,dB)
link_20.SetDistance(0)
link_20.SetName("Coincident14")
exported_items.append(link_20)

link_21 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.02067035795504,1.94456417249918,0.727403113437383)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
cB = chrono.ChVectorD(-1.50067035795504,1.94456417249918,0.377403113437383)
dB = chrono.ChVectorD(6.21947280249299e-17,-1,3.55871276754624e-15)
link_21.SetFlipped(True)
link_21.Initialize(body_1,body_41,False,cA,cB,dA,dB)
link_21.SetName("Coincident14")
exported_items.append(link_21)


# Mate constraint: Coincident16 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_1 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_41 , SW name: M-410iB-300 -9/ArmBase-1 ,  SW ref.type:2 (2)

link_22 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.82067035795504,1.69456417249918,0.727403113437384)
cB = chrono.ChVectorD(-1.82067035795504,1.94456417249918,0.697403113437383)
dA = chrono.ChVectorD(-1,-3.01405864546147e-31,-8.63260705973055e-17)
dB = chrono.ChVectorD(-1,-6.21947280249306e-17,-2.22044604925031e-16)
link_22.Initialize(body_1,body_41,False,cA,cB,dB)
link_22.SetDistance(0)
link_22.SetName("Coincident16")
exported_items.append(link_22)

link_23 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.82067035795504,1.69456417249918,0.727403113437384)
dA = chrono.ChVectorD(-1,-3.01405864546147e-31,-8.63260705973055e-17)
cB = chrono.ChVectorD(-1.82067035795504,1.94456417249918,0.697403113437383)
dB = chrono.ChVectorD(-1,-6.21947280249306e-17,-2.22044604925031e-16)
link_23.Initialize(body_1,body_41,False,cA,cB,dA,dB)
link_23.SetName("Coincident16")
exported_items.append(link_23)


# Mate constraint: Coincident17 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_1 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_61 , SW name: M-410iB-300 -7/ArmBase-1 ,  SW ref.type:2 (2)

link_24 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.02067035795504,1.94456417249917,-2.17259688656262)
cB = chrono.ChVectorD(-1.50067035795504,1.94456417249917,-2.52259688656262)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
dB = chrono.ChVectorD(6.42083927456682e-17,-1,3.44169137633798e-15)
link_24.Initialize(body_1,body_61,False,cA,cB,dB)
link_24.SetDistance(0)
link_24.SetName("Coincident17")
exported_items.append(link_24)

link_25 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.02067035795504,1.94456417249917,-2.17259688656262)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
cB = chrono.ChVectorD(-1.50067035795504,1.94456417249917,-2.52259688656262)
dB = chrono.ChVectorD(6.42083927456682e-17,-1,3.44169137633798e-15)
link_25.SetFlipped(True)
link_25.Initialize(body_1,body_61,False,cA,cB,dA,dB)
link_25.SetName("Coincident17")
exported_items.append(link_25)


# Mate constraint: Coincident18 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_1 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_35 , SW name: M-410iB-300 -8/ArmBase-1 ,  SW ref.type:2 (2)

link_26 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.82067035795504,1.69456417249918,-0.722596886562616)
cB = chrono.ChVectorD(-1.82067035795504,1.94456417249918,-0.752596886562616)
dA = chrono.ChVectorD(-1,-3.01405864546147e-31,-8.63260705973055e-17)
dB = chrono.ChVectorD(-1,3.54053086910991e-17,-1.2490009027033e-16)
link_26.Initialize(body_1,body_35,False,cA,cB,dB)
link_26.SetDistance(0)
link_26.SetName("Coincident18")
exported_items.append(link_26)

link_27 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.82067035795504,1.69456417249918,-0.722596886562616)
dA = chrono.ChVectorD(-1,-3.01405864546147e-31,-8.63260705973055e-17)
cB = chrono.ChVectorD(-1.82067035795504,1.94456417249918,-0.752596886562616)
dB = chrono.ChVectorD(-1,3.54053086910991e-17,-1.2490009027033e-16)
link_27.Initialize(body_1,body_35,False,cA,cB,dA,dB)
link_27.SetName("Coincident18")
exported_items.append(link_27)


# Mate constraint: Distance4 [MateDistanceDim] type:5 align:0 flip:True
#   Entity 0: C::E name: body_1 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_61 , SW name: M-410iB-300 -7/ArmBase-1 ,  SW ref.type:2 (2)

link_28 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.02067035795504,1.69456417249917,-2.87259688656262)
cB = chrono.ChVectorD(-1.18067035795504,1.94456417249917,-2.84259688656262)
dA = chrono.ChVectorD(2.44929359829471e-16,-3.49148133884313e-15,-1)
dB = chrono.ChVectorD(2.17109494630873e-16,-3.44169137633798e-15,-1)
link_28.Initialize(body_1,body_61,False,cA,cB,dB)
link_28.SetDistance(0.0300000000000003)
link_28.SetName("Distance4")
exported_items.append(link_28)

link_29 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.02067035795504,1.69456417249917,-2.87259688656262)
dA = chrono.ChVectorD(2.44929359829471e-16,-3.49148133884313e-15,-1)
cB = chrono.ChVectorD(-1.18067035795504,1.94456417249917,-2.84259688656262)
dB = chrono.ChVectorD(2.17109494630873e-16,-3.44169137633798e-15,-1)
link_29.Initialize(body_1,body_61,False,cA,cB,dA,dB)
link_29.SetName("Distance4")
exported_items.append(link_29)


# Mate constraint: Distance5 [MateDistanceDim] type:5 align:0 flip:True
#   Entity 0: C::E name: body_1 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_35 , SW name: M-410iB-300 -8/ArmBase-1 ,  SW ref.type:2 (2)

link_30 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.02067035795504,1.69456417249917,-1.42259688656262)
cB = chrono.ChVectorD(-1.18067035795504,1.94456417249917,-1.39259688656262)
dA = chrono.ChVectorD(2.44929359829471e-16,-3.49148133884313e-15,-1)
dB = chrono.ChVectorD(2.77555756156289e-16,-3.70712266049311e-15,-1)
link_30.Initialize(body_1,body_35,False,cA,cB,dB)
link_30.SetDistance(0.03)
link_30.SetName("Distance5")
exported_items.append(link_30)

link_31 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.02067035795504,1.69456417249917,-1.42259688656262)
dA = chrono.ChVectorD(2.44929359829471e-16,-3.49148133884313e-15,-1)
cB = chrono.ChVectorD(-1.18067035795504,1.94456417249917,-1.39259688656262)
dB = chrono.ChVectorD(2.77555756156289e-16,-3.70712266049311e-15,-1)
link_31.Initialize(body_1,body_35,False,cA,cB,dA,dB)
link_31.SetName("Distance5")
exported_items.append(link_31)


# Mate constraint: Distance6 [MateDistanceDim] type:5 align:0 flip:True
#   Entity 0: C::E name: body_1 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_41 , SW name: M-410iB-300 -9/ArmBase-1 ,  SW ref.type:2 (2)

link_32 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.02067035795504,1.69456417249918,0.0274031134373841)
cB = chrono.ChVectorD(-1.18067035795504,1.94456417249918,0.0574031134373831)
dA = chrono.ChVectorD(2.44929359829471e-16,-3.49148133884313e-15,-1)
dB = chrono.ChVectorD(2.22044604925031e-16,-3.55871276754624e-15,-1)
link_32.Initialize(body_1,body_41,False,cA,cB,dB)
link_32.SetDistance(0.03)
link_32.SetName("Distance6")
exported_items.append(link_32)

link_33 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.02067035795504,1.69456417249918,0.0274031134373841)
dA = chrono.ChVectorD(2.44929359829471e-16,-3.49148133884313e-15,-1)
cB = chrono.ChVectorD(-1.18067035795504,1.94456417249918,0.0574031134373831)
dB = chrono.ChVectorD(2.22044604925031e-16,-3.55871276754624e-15,-1)
link_33.Initialize(body_1,body_41,False,cA,cB,dA,dB)
link_33.SetName("Distance6")
exported_items.append(link_33)


# Mate constraint: Coincident6 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_5 , SW name: M-410iB-300 -2/M-410iB-300-03-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_6 , SW name: M-410iB-300 -2/M-410iB-300-06-1 ,  SW ref.type:5 (5)

link_1 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.44642035239278,2.75811166842827,-1.22089075026679)
dA = chrono.ChVectorD(0.00938040695038913,-3.44096786457492e-15,-0.999956003014855)
cB = chrono.ChVectorD(1.44625229513245,2.75811166842827,-1.20297576350691)
dB = chrono.ChVectorD(-0.00938040695038912,3.18710021780773e-15,0.999956003014855)
link_1.SetFlipped(True)
link_1.Initialize(body_5,body_6,False,cA,cB,dA,dB)
link_1.SetName("Coincident6")
exported_items.append(link_1)

link_2 = chrono.ChLinkMateGeneric()
link_2.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.44642035239278,2.75811166842827,-1.22089075026679)
cB = chrono.ChVectorD(1.44625229513245,2.75811166842827,-1.20297576350691)
dA = chrono.ChVectorD(0.00938040695038913,-3.44096786457492e-15,-0.999956003014855)
dB = chrono.ChVectorD(-0.00938040695038912,3.18710021780773e-15,0.999956003014855)
link_2.Initialize(body_5,body_6,False,cA,cB,dA,dB)
link_2.SetName("Coincident6")
exported_items.append(link_2)


# Mate constraint: Coincident7 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_9 , SW name: M-410iB-300 -2/M-410iB-300-02-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_13 , SW name: M-410iB-300 -2/M-410iB-300-07-1 ,  SW ref.type:5 (5)

link_3 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.247461054361358,2.51550127212878,-0.8719472279884)
dA = chrono.ChVectorD(0.00938040694385735,-3.43846829803131e-15,-0.999956003014916)
cB = chrono.ChVectorD(0.250352346033168,2.51550127212935,-1.18016034499013)
dB = chrono.ChVectorD(-0.00938040695038904,3.45339423891956e-15,0.999956003014855)
link_3.SetFlipped(True)
link_3.Initialize(body_9,body_13,False,cA,cB,dA,dB)
link_3.SetName("Coincident7")
exported_items.append(link_3)

link_4 = chrono.ChLinkMateGeneric()
link_4.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.247461054361358,2.51550127212878,-0.8719472279884)
cB = chrono.ChVectorD(0.250352346033168,2.51550127212935,-1.18016034499013)
dA = chrono.ChVectorD(0.00938040694385735,-3.43846829803131e-15,-0.999956003014916)
dB = chrono.ChVectorD(-0.00938040695038904,3.45339423891956e-15,0.999956003014855)
link_4.Initialize(body_9,body_13,False,cA,cB,dA,dB)
link_4.SetName("Coincident7")
exported_items.append(link_4)


# Mate constraint: Coincident8 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_6 , SW name: M-410iB-300 -2/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_13 , SW name: M-410iB-300 -2/M-410iB-300-07-1 ,  SW ref.type:2 (2)

link_5 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.971968422271693,3.10515332886759,-1.09742009511318)
cB = chrono.ChVectorD(-0.0709700781787254,3.00995602354386,-1.10720371312133)
dA = chrono.ChVectorD(0.00938040695038912,-3.18710021780773e-15,-0.999956003014855)
dB = chrono.ChVectorD(0.00938040695038904,-3.45339423891956e-15,-0.999956003014855)
link_5.Initialize(body_6,body_13,False,cA,cB,dB)
link_5.SetDistance(0)
link_5.SetName("Coincident8")
exported_items.append(link_5)

link_6 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.971968422271693,3.10515332886759,-1.09742009511318)
dA = chrono.ChVectorD(0.00938040695038912,-3.18710021780773e-15,-0.999956003014855)
cB = chrono.ChVectorD(-0.0709700781787254,3.00995602354386,-1.10720371312133)
dB = chrono.ChVectorD(0.00938040695038904,-3.45339423891956e-15,-0.999956003014855)
link_6.Initialize(body_6,body_13,False,cA,cB,dA,dB)
link_6.SetName("Coincident8")
exported_items.append(link_6)


# Mate constraint: Coincident9 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_6 , SW name: M-410iB-300 -2/M-410iB-300-06-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_2 , SW name: M-410iB-300 -2/M-410iB-300-08-1 ,  SW ref.type:5 (5)

link_7 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.12788975943069,3.25502265003477,-1.09595742516531)
dA = chrono.ChVectorD(0.00938040695038912,-3.18710021780773e-15,-0.999956003014855)
cB = chrono.ChVectorD(1.1281695394484,3.25502265003477,-1.12578211291123)
dB = chrono.ChVectorD(0.00938040695038899,-3.2131555071315e-15,-0.999956003014855)
link_7.Initialize(body_6,body_2,False,cA,cB,dA,dB)
link_7.SetName("Coincident9")
exported_items.append(link_7)

link_8 = chrono.ChLinkMateGeneric()
link_8.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.12788975943069,3.25502265003477,-1.09595742516531)
cB = chrono.ChVectorD(1.1281695394484,3.25502265003477,-1.12578211291123)
dA = chrono.ChVectorD(0.00938040695038912,-3.18710021780773e-15,-0.999956003014855)
dB = chrono.ChVectorD(0.00938040695038899,-3.2131555071315e-15,-0.999956003014855)
link_8.Initialize(body_6,body_2,False,cA,cB,dA,dB)
link_8.SetName("Coincident9")
exported_items.append(link_8)


# Mate constraint: Coincident11 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_9 , SW name: M-410iB-300 -2/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_3 , SW name: M-410iB-300 -2/M-410iB-300-09-1 ,  SW ref.type:2 (2)

link_9 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.101107320965351,2.72491052060124,-1.36534677032412)
cB = chrono.ChVectorD(1.44690313043654,3.21365418351145,-1.35082516342971)
dA = chrono.ChVectorD(0.00938040694385735,-3.43846829803131e-15,-0.999956003014916)
dB = chrono.ChVectorD(0.0093804069438573,-3.19013824727569e-15,-0.999956003014916)
link_9.Initialize(body_9,body_3,False,cA,cB,dB)
link_9.SetDistance(0)
link_9.SetName("Coincident11")
exported_items.append(link_9)

link_10 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.101107320965351,2.72491052060124,-1.36534677032412)
dA = chrono.ChVectorD(0.00938040694385735,-3.43846829803131e-15,-0.999956003014916)
cB = chrono.ChVectorD(1.44690313043654,3.21365418351145,-1.35082516342971)
dB = chrono.ChVectorD(0.0093804069438573,-3.19013824727569e-15,-0.999956003014916)
link_10.Initialize(body_9,body_3,False,cA,cB,dA,dB)
link_10.SetName("Coincident11")
exported_items.append(link_10)


# Mate constraint: Coincident22 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_3 , SW name: M-410iB-300 -2/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_7 , SW name: M-410iB-300 -2/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_11 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.44690313043654,3.21365418351145,-1.35082516342971)
cB = chrono.ChVectorD(0.946663014906017,3.03011496694616,-1.35551782574482)
dA = chrono.ChVectorD(0.0093804069438573,-3.19013824727569e-15,-0.999956003014916)
dB = chrono.ChVectorD(-0.00938040694385735,3.17080741621101e-15,0.999956003014916)
link_11.Initialize(body_3,body_7,False,cA,cB,dB)
link_11.SetDistance(0)
link_11.SetName("Coincident22")
exported_items.append(link_11)

link_12 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.44690313043654,3.21365418351145,-1.35082516342971)
dA = chrono.ChVectorD(0.0093804069438573,-3.19013824727569e-15,-0.999956003014916)
cB = chrono.ChVectorD(0.946663014906017,3.03011496694616,-1.35551782574482)
dB = chrono.ChVectorD(-0.00938040694385735,3.17080741621101e-15,0.999956003014916)
link_12.SetFlipped(True)
link_12.Initialize(body_3,body_7,False,cA,cB,dA,dB)
link_12.SetName("Coincident22")
exported_items.append(link_12)


# Mate constraint: Coincident15 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_6 , SW name: M-410iB-300 -2/M-410iB-300-06-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_8 , SW name: M-410iB-300 -2/M-410iB-300-12-1 ,  SW ref.type:5 (5)

link_13 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(2.19247325036146,1.69376904051732,-1.17597471924404)
dA = chrono.ChVectorD(-0.00938040695038912,3.18710021780773e-15,0.999956003014855)
cB = chrono.ChVectorD(2.19259126526271,1.69376904051016,-1.18855516569124)
dB = chrono.ChVectorD(0.00938040660311615,-1.01136206360542e-15,-0.999956003018113)
link_13.SetFlipped(True)
link_13.Initialize(body_6,body_8,False,cA,cB,dA,dB)
link_13.SetName("Coincident15")
exported_items.append(link_13)

link_14 = chrono.ChLinkMateGeneric()
link_14.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(2.19247325036146,1.69376904051732,-1.17597471924404)
cB = chrono.ChVectorD(2.19259126526271,1.69376904051016,-1.18855516569124)
dA = chrono.ChVectorD(-0.00938040695038912,3.18710021780773e-15,0.999956003014855)
dB = chrono.ChVectorD(0.00938040660311615,-1.01136206360542e-15,-0.999956003018113)
link_14.Initialize(body_6,body_8,False,cA,cB,dA,dB)
link_14.SetName("Coincident15")
exported_items.append(link_14)


# Mate constraint: Coincident17 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_13 , SW name: M-410iB-300 -2/M-410iB-300-07-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_2 , SW name: M-410iB-300 -2/M-410iB-300-08-1 ,  SW ref.type:5 (5)

link_15 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.0701388521776306,3.00995602354386,-1.19581281441648)
dA = chrono.ChVectorD(-0.00938040695038904,3.45339423891956e-15,0.999956003014855)
cB = chrono.ChVectorD(-0.0706902981610227,3.00995602354386,-1.13702840086725)
dB = chrono.ChVectorD(0.00938040695038899,-3.2131555071315e-15,-0.999956003014855)
link_15.SetFlipped(True)
link_15.Initialize(body_13,body_2,False,cA,cB,dA,dB)
link_15.SetName("Coincident17")
exported_items.append(link_15)

link_16 = chrono.ChLinkMateGeneric()
link_16.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-0.0701388521776306,3.00995602354386,-1.19581281441648)
cB = chrono.ChVectorD(-0.0706902981610227,3.00995602354386,-1.13702840086725)
dA = chrono.ChVectorD(-0.00938040695038904,3.45339423891956e-15,0.999956003014855)
dB = chrono.ChVectorD(0.00938040695038899,-3.2131555071315e-15,-0.999956003014855)
link_16.Initialize(body_13,body_2,False,cA,cB,dA,dB)
link_16.SetName("Coincident17")
exported_items.append(link_16)


# Mate constraint: Coincident18 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_9 , SW name: M-410iB-300 -2/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_4 , SW name: M-410iB-300 -2/ArmBase-1 ,  SW ref.type:2 (2)

link_17 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.140670357955083,2.04602671615605,-1.07259688656366)
cB = chrono.ChVectorD(-0.382669423498732,2.04602671615662,-1.07259688656261)
dA = chrono.ChVectorD(4.46713976325465e-17,-1,3.43903864125165e-15)
dB = chrono.ChVectorD(0,1,0)
link_17.Initialize(body_9,body_4,False,cA,cB,dB)
link_17.SetDistance(0)
link_17.SetName("Coincident18")
exported_items.append(link_17)

link_18 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.140670357955083,2.04602671615605,-1.07259688656366)
dA = chrono.ChVectorD(4.46713976325465e-17,-1,3.43903864125165e-15)
cB = chrono.ChVectorD(-0.382669423498732,2.04602671615662,-1.07259688656261)
dB = chrono.ChVectorD(0,1,0)
link_18.SetFlipped(True)
link_18.Initialize(body_9,body_4,False,cA,cB,dA,dB)
link_18.SetName("Coincident18")
exported_items.append(link_18)


# Mate constraint: Concentric1 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_9 , SW name: M-410iB-300 -2/M-410iB-300-02-1 ,  SW ref.type:1 (1)
#   Entity 1: C::E name: body_4 , SW name: M-410iB-300 -2/ArmBase-1 ,  SW ref.type:1 (1)

link_19 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.140670357955083,2.04755071615605,-1.07259688656366)
dA = chrono.ChVectorD(-4.46713976325465e-17,1,-3.43903864125165e-15)
cB = chrono.ChVectorD(-0.140670357955037,2.04602671615662,-1.07259688656261)
dB = chrono.ChVectorD(0,1,0)
link_19.Initialize(body_9,body_4,False,cA,cB,dA,dB)
link_19.SetName("Concentric1")
exported_items.append(link_19)

link_20 = chrono.ChLinkMateGeneric()
link_20.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-0.140670357955083,2.04755071615605,-1.07259688656366)
cB = chrono.ChVectorD(-0.140670357955037,2.04602671615662,-1.07259688656261)
dA = chrono.ChVectorD(-4.46713976325465e-17,1,-3.43903864125165e-15)
dB = chrono.ChVectorD(0,1,0)
link_20.Initialize(body_9,body_4,False,cA,cB,dA,dB)
link_20.SetName("Concentric1")
exported_items.append(link_20)


# Mate constraint: Coincident21 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_6 , SW name: M-410iB-300 -2/M-410iB-300-06-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_8 , SW name: M-410iB-300 -2/M-410iB-300-12-1 ,  SW ref.type:4 (4)

link_21 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.44540805848834,2.75811166842827,-1.11297972125524)
cB = chrono.ChVectorD(2.44680435257568,1.53476735988757,-1.10358580510787)
dA = chrono.ChVectorD(-0.00938040695038912,3.18710021780773e-15,0.999956003014855)
dB = chrono.ChVectorD(0.00938040677675265,-2.15929082365359e-15,-0.999956003016484)
link_21.Initialize(body_6,body_8,False,cA,cB,dB)
link_21.SetDistance(0)
link_21.SetName("Coincident21")
exported_items.append(link_21)

link_22 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.44540805848834,2.75811166842827,-1.11297972125524)
dA = chrono.ChVectorD(-0.00938040695038912,3.18710021780773e-15,0.999956003014855)
cB = chrono.ChVectorD(2.44680435257568,1.53476735988757,-1.10358580510787)
dB = chrono.ChVectorD(0.00938040677675265,-2.15929082365359e-15,-0.999956003016484)
link_22.SetFlipped(True)
link_22.Initialize(body_6,body_8,False,cA,cB,dA,dB)
link_22.SetName("Coincident21")
exported_items.append(link_22)


# Mate constraint: Coincident25 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_5 , SW name: M-410iB-300 -2/M-410iB-300-03-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_11 , SW name: M-410iB-300 -2/M-410iB-300-05-1 ,  SW ref.type:2 (2)

link_23 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.44373065802892,2.75811166842827,-0.934168005758202)
cB = chrono.ChVectorD(1.44373065802892,2.75811166842827,-0.934168005758202)
dA = chrono.ChVectorD(-0.00938040695038913,3.44096786457492e-15,0.999956003014855)
dB = chrono.ChVectorD(0.00938040695038913,-3.44096786457491e-15,-0.999956003014855)
link_23.Initialize(body_5,body_11,False,cA,cB,dB)
link_23.SetDistance(0)
link_23.SetName("Coincident25")
exported_items.append(link_23)

link_24 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.44373065802892,2.75811166842827,-0.934168005758202)
dA = chrono.ChVectorD(-0.00938040695038913,3.44096786457492e-15,0.999956003014855)
cB = chrono.ChVectorD(1.44373065802892,2.75811166842827,-0.934168005758202)
dB = chrono.ChVectorD(0.00938040695038913,-3.44096786457491e-15,-0.999956003014855)
link_24.SetFlipped(True)
link_24.Initialize(body_5,body_11,False,cA,cB,dA,dB)
link_24.SetName("Coincident25")
exported_items.append(link_24)


# Mate constraint: Concentric2 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_6 , SW name: M-410iB-300 -2/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_3 , SW name: M-410iB-300 -2/M-410iB-300-09-1 ,  SW ref.type:2 (2)

link_25 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.44711998277536,2.75811166842827,-1.29547169378578)
dA = chrono.ChVectorD(-0.00938040695038912,3.18710021780773e-15,0.999956003014855)
cB = chrono.ChVectorD(1.44769874450682,2.75811166841875,-1.35716797931073)
dB = chrono.ChVectorD(-0.0093804069438573,3.19013824727569e-15,0.999956003014916)
link_25.Initialize(body_6,body_3,False,cA,cB,dA,dB)
link_25.SetName("Concentric2")
exported_items.append(link_25)

link_26 = chrono.ChLinkMateGeneric()
link_26.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.44711998277536,2.75811166842827,-1.29547169378578)
cB = chrono.ChVectorD(1.44769874450682,2.75811166841875,-1.35716797931073)
dA = chrono.ChVectorD(-0.00938040695038912,3.18710021780773e-15,0.999956003014855)
dB = chrono.ChVectorD(-0.0093804069438573,3.19013824727569e-15,0.999956003014916)
link_26.Initialize(body_6,body_3,False,cA,cB,dA,dB)
link_26.SetName("Concentric2")
exported_items.append(link_26)


# Mate constraint: Concentric3 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_3 , SW name: M-410iB-300 -2/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_7 , SW name: M-410iB-300 -2/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_27 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.946666372754692,3.03011496694511,-1.35587577284388)
dA = chrono.ChVectorD(-0.0093804069438573,3.19013824727569e-15,0.999956003014916)
cB = chrono.ChVectorD(0.947065209234142,3.03011496694616,-1.39839193933009)
dB = chrono.ChVectorD(-0.00938040694385735,3.17080741621101e-15,0.999956003014916)
link_27.Initialize(body_3,body_7,False,cA,cB,dA,dB)
link_27.SetName("Concentric3")
exported_items.append(link_27)

link_28 = chrono.ChLinkMateGeneric()
link_28.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.946666372754692,3.03011496694511,-1.35587577284388)
cB = chrono.ChVectorD(0.947065209234142,3.03011496694616,-1.39839193933009)
dA = chrono.ChVectorD(-0.0093804069438573,3.19013824727569e-15,0.999956003014916)
dB = chrono.ChVectorD(-0.00938040694385735,3.17080741621101e-15,0.999956003014916)
link_28.Initialize(body_3,body_7,False,cA,cB,dA,dB)
link_28.SetName("Concentric3")
exported_items.append(link_28)


# Mate constraint: Concentric4 [MateConcentric] type:1 align:1 flip:False
#   Entity 0: C::E name: body_3 , SW name: M-410iB-300 -2/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_12 , SW name: M-410iB-300 -2/M-410iB-300-11-1 ,  SW ref.type:2 (2)

link_29 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.9476223185657,3.02810836636642,-1.34648598561697)
dA = chrono.ChVectorD(-0.0093804069438573,3.19013824727569e-15,0.999956003014916)
cB = chrono.ChVectorD(1.94668020711999,3.0281083663764,-1.24605644154664)
dB = chrono.ChVectorD(0.00938040695038915,-3.30721958370176e-15,-0.999956003014855)
link_29.SetFlipped(True)
link_29.Initialize(body_3,body_12,False,cA,cB,dA,dB)
link_29.SetName("Concentric4")
exported_items.append(link_29)

link_30 = chrono.ChLinkMateGeneric()
link_30.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.9476223185657,3.02810836636642,-1.34648598561697)
cB = chrono.ChVectorD(1.94668020711999,3.0281083663764,-1.24605644154664)
dA = chrono.ChVectorD(-0.0093804069438573,3.19013824727569e-15,0.999956003014916)
dB = chrono.ChVectorD(0.00938040695038915,-3.30721958370176e-15,-0.999956003014855)
link_30.Initialize(body_3,body_12,False,cA,cB,dA,dB)
link_30.SetName("Concentric4")
exported_items.append(link_30)


# Mate constraint: Concentric6 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_5 , SW name: M-410iB-300 -2/M-410iB-300-03-1 ,  SW ref.type:1 (1)
#   Entity 1: C::E name: body_11 , SW name: M-410iB-300 -2/M-410iB-300-05-1 ,  SW ref.type:2 (2)

link_31 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.44373065802892,2.75811166842827,-0.934168005758202)
dA = chrono.ChVectorD(-0.00938040695038913,3.44096786457492e-15,0.999956003014855)
cB = chrono.ChVectorD(1.44373065802892,2.75811166842827,-0.934168005758202)
dB = chrono.ChVectorD(-0.00938040695038913,3.44096786457491e-15,0.999956003014855)
link_31.Initialize(body_5,body_11,False,cA,cB,dA,dB)
link_31.SetName("Concentric6")
exported_items.append(link_31)

link_32 = chrono.ChLinkMateGeneric()
link_32.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.44373065802892,2.75811166842827,-0.934168005758202)
cB = chrono.ChVectorD(1.44373065802892,2.75811166842827,-0.934168005758202)
dA = chrono.ChVectorD(-0.00938040695038913,3.44096786457492e-15,0.999956003014855)
dB = chrono.ChVectorD(-0.00938040695038913,3.44096786457491e-15,0.999956003014855)
link_32.Initialize(body_5,body_11,False,cA,cB,dA,dB)
link_32.SetName("Concentric6")
exported_items.append(link_32)


# Mate constraint: Concentric7 [MateConcentric] type:1 align:1 flip:False
#   Entity 0: C::E name: body_9 , SW name: M-410iB-300 -2/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_10 , SW name: M-410iB-300 -2/M-410iB-300-04-1 ,  SW ref.type:2 (2)

link_33 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.247417266889247,2.780496916778,-0.866907410604894)
dA = chrono.ChVectorD(0.00938040694385735,-3.43846829803131e-15,-0.999956003014916)
cB = chrono.ChVectorD(0.247628772011308,2.78049691677857,-0.889453960968417)
dB = chrono.ChVectorD(-0.0093804069503892,3.55554963445705e-15,0.999956003014855)
link_33.SetFlipped(True)
link_33.Initialize(body_9,body_10,False,cA,cB,dA,dB)
link_33.SetName("Concentric7")
exported_items.append(link_33)

link_34 = chrono.ChLinkMateGeneric()
link_34.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.247417266889247,2.780496916778,-0.866907410604894)
cB = chrono.ChVectorD(0.247628772011308,2.78049691677857,-0.889453960968417)
dA = chrono.ChVectorD(0.00938040694385735,-3.43846829803131e-15,-0.999956003014916)
dB = chrono.ChVectorD(-0.0093804069503892,3.55554963445705e-15,0.999956003014855)
link_34.Initialize(body_9,body_10,False,cA,cB,dA,dB)
link_34.SetName("Concentric7")
exported_items.append(link_34)


# Mate constraint: Concentric8 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_12 , SW name: M-410iB-300 -2/M-410iB-300-11-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_8 , SW name: M-410iB-300 -2/M-410iB-300-12-1 ,  SW ref.type:2 (2)

link_35 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(2.69308878832477,1.96376575097482,-1.23905451724012)
dA = chrono.ChVectorD(0.00938040695038915,-3.30721958370176e-15,-0.999956003014855)
cB = chrono.ChVectorD(2.69251149931837,1.96376575097482,-1.17751522470428)
dB = chrono.ChVectorD(0.00938040695038915,-3.30721958370177e-15,-0.999956003014855)
link_35.Initialize(body_12,body_8,False,cA,cB,dA,dB)
link_35.SetName("Concentric8")
exported_items.append(link_35)

link_36 = chrono.ChLinkMateGeneric()
link_36.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(2.69308878832477,1.96376575097482,-1.23905451724012)
cB = chrono.ChVectorD(2.69251149931837,1.96376575097482,-1.17751522470428)
dA = chrono.ChVectorD(0.00938040695038915,-3.30721958370176e-15,-0.999956003014855)
dB = chrono.ChVectorD(0.00938040695038915,-3.30721958370177e-15,-0.999956003014855)
link_36.Initialize(body_12,body_8,False,cA,cB,dA,dB)
link_36.SetName("Concentric8")
exported_items.append(link_36)


# Mate constraint: Concentric9 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_5 , SW name: M-410iB-300 -2/M-410iB-300-03-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_13 , SW name: M-410iB-300 -2/M-410iB-300-07-1 ,  SW ref.type:2 (2)

link_37 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.248209512677702,2.51550127212935,-0.951733253437332)
dA = chrono.ChVectorD(0.00938040695038913,-3.44096786457492e-15,-0.999956003014855)
cB = chrono.ChVectorD(0.248719524400965,2.51550127212935,-1.00610075444047)
dB = chrono.ChVectorD(0.00938040695038904,-3.45339423891956e-15,-0.999956003014855)
link_37.Initialize(body_5,body_13,False,cA,cB,dA,dB)
link_37.SetName("Concentric9")
exported_items.append(link_37)

link_38 = chrono.ChLinkMateGeneric()
link_38.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.248209512677702,2.51550127212935,-0.951733253437332)
cB = chrono.ChVectorD(0.248719524400965,2.51550127212935,-1.00610075444047)
dA = chrono.ChVectorD(0.00938040695038913,-3.44096786457492e-15,-0.999956003014855)
dB = chrono.ChVectorD(0.00938040695038904,-3.45339423891956e-15,-0.999956003014855)
link_38.Initialize(body_5,body_13,False,cA,cB,dA,dB)
link_38.SetName("Concentric9")
exported_items.append(link_38)


# Mate constraint: Coincident33 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_10 , SW name: M-410iB-300 -2/M-410iB-300-04-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_11 , SW name: M-410iB-300 -2/M-410iB-300-05-1 ,  SW ref.type:4 (4)

link_39 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.246790088586688,2.78049691677857,-0.800049894650865)
cB = chrono.ChVectorD(0.573557803429006,2.77437872021165,-0.79698454564128)
dA = chrono.ChVectorD(-0.0187184534892299,-0.99982477898158,-0.000175594436833183)
dB = chrono.ChVectorD(-0.0187184534892299,-0.99982477898158,-0.000175594436833296)
link_39.Initialize(body_10,body_11,False,cA,cB,dB)
link_39.SetDistance(0)
link_39.SetName("Coincident33")
exported_items.append(link_39)

link_40 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.246790088586688,2.78049691677857,-0.800049894650865)
dA = chrono.ChVectorD(-0.0187184534892299,-0.99982477898158,-0.000175594436833183)
cB = chrono.ChVectorD(0.573557803429006,2.77437872021165,-0.79698454564128)
dB = chrono.ChVectorD(-0.0187184534892299,-0.99982477898158,-0.000175594436833296)
link_40.Initialize(body_10,body_11,False,cA,cB,dA,dB)
link_40.SetName("Coincident33")
exported_items.append(link_40)


# Mate constraint: Coincident34 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_10 , SW name: M-410iB-300 -2/M-410iB-300-04-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_11 , SW name: M-410iB-300 -2/M-410iB-300-05-1 ,  SW ref.type:4 (4)

link_41 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.246790088586688,2.78049691677857,-0.800049894650865)
cB = chrono.ChVectorD(0.573557803429006,2.77437872021165,-0.79698454564128)
dA = chrono.ChVectorD(0.0093804069503892,-3.55554963445705e-15,-0.999956003014855)
dB = chrono.ChVectorD(-0.00938040695038913,3.44096786457491e-15,0.999956003014855)
link_41.Initialize(body_10,body_11,False,cA,cB,dB)
link_41.SetDistance(0)
link_41.SetName("Coincident34")
exported_items.append(link_41)

link_42 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.246790088586688,2.78049691677857,-0.800049894650865)
dA = chrono.ChVectorD(0.0093804069503892,-3.55554963445705e-15,-0.999956003014855)
cB = chrono.ChVectorD(0.573557803429006,2.77437872021165,-0.79698454564128)
dB = chrono.ChVectorD(-0.00938040695038913,3.44096786457491e-15,0.999956003014855)
link_42.SetFlipped(True)
link_42.Initialize(body_10,body_11,False,cA,cB,dA,dB)
link_42.SetName("Coincident34")
exported_items.append(link_42)


# Mate constraint: Concentric10 [MateConcentric] type:1 align:1 flip:False
#   Entity 0: C::E name: body_9 , SW name: M-410iB-300 -2/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_7 , SW name: M-410iB-300 -2/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_43 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.248915995022458,2.78749692402044,-1.36673333684136)
dA = chrono.ChVectorD(-0.00938040694385735,3.43846829803131e-15,0.999956003014916)
cB = chrono.ChVectorD(-0.248915995031104,2.78749692402065,-1.36673333684024)
dB = chrono.ChVectorD(0.00938040694385735,-3.17080741621101e-15,-0.999956003014916)
link_43.SetFlipped(True)
link_43.Initialize(body_9,body_7,False,cA,cB,dA,dB)
link_43.SetName("Concentric10")
exported_items.append(link_43)

link_44 = chrono.ChLinkMateGeneric()
link_44.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-0.248915995022458,2.78749692402044,-1.36673333684136)
cB = chrono.ChVectorD(-0.248915995031104,2.78749692402065,-1.36673333684024)
dA = chrono.ChVectorD(-0.00938040694385735,3.43846829803131e-15,0.999956003014916)
dB = chrono.ChVectorD(0.00938040694385735,-3.17080741621101e-15,-0.999956003014916)
link_44.Initialize(body_9,body_7,False,cA,cB,dA,dB)
link_44.SetName("Concentric10")
exported_items.append(link_44)


# Mate constraint: Coincident35 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_12 , SW name: M-410iB-300 -2/M-410iB-300-11-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_8 , SW name: M-410iB-300 -2/M-410iB-300-12-1 ,  SW ref.type:2 (2)

link_45 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(2.69297442240323,1.96376575097482,-1.22686305365136)
cB = chrono.ChVectorD(2.5541917685027,2.16238744711919,-1.22816494865386)
dA = chrono.ChVectorD(-0.00938040695038915,3.30721958370176e-15,0.999956003014855)
dB = chrono.ChVectorD(0.00938040660311615,-1.01136206360542e-15,-0.999956003018113)
link_45.Initialize(body_12,body_8,False,cA,cB,dB)
link_45.SetDistance(0)
link_45.SetName("Coincident35")
exported_items.append(link_45)

link_46 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(2.69297442240323,1.96376575097482,-1.22686305365136)
dA = chrono.ChVectorD(-0.00938040695038915,3.30721958370176e-15,0.999956003014855)
cB = chrono.ChVectorD(2.5541917685027,2.16238744711919,-1.22816494865386)
dB = chrono.ChVectorD(0.00938040660311615,-1.01136206360542e-15,-0.999956003018113)
link_46.SetFlipped(True)
link_46.Initialize(body_12,body_8,False,cA,cB,dA,dB)
link_46.SetName("Coincident35")
exported_items.append(link_46)


# Mate constraint: Coincident36 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_6 , SW name: M-410iB-300 -2/M-410iB-300-06-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_2 , SW name: M-410iB-300 -2/M-410iB-300-08-1 ,  SW ref.type:4 (4)

link_47 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.44568947071543,2.75811166842827,-1.14297840332602)
cB = chrono.ChVectorD(-0.0705010578312056,3.00995602354386,-1.15720151327207)
dA = chrono.ChVectorD(-0.00938040695038912,3.18710021780773e-15,0.999956003014855)
dB = chrono.ChVectorD(-0.00938040695038899,3.2131555071315e-15,0.999956003014855)
link_47.Initialize(body_6,body_2,False,cA,cB,dB)
link_47.SetDistance(0)
link_47.SetName("Coincident36")
exported_items.append(link_47)

link_48 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.44568947071543,2.75811166842827,-1.14297840332602)
dA = chrono.ChVectorD(-0.00938040695038912,3.18710021780773e-15,0.999956003014855)
cB = chrono.ChVectorD(-0.0705010578312056,3.00995602354386,-1.15720151327207)
dB = chrono.ChVectorD(-0.00938040695038899,3.2131555071315e-15,0.999956003014855)
link_48.Initialize(body_6,body_2,False,cA,cB,dA,dB)
link_48.SetName("Coincident36")
exported_items.append(link_48)


# Mate constraint: Coincident37 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_3 , SW name: M-410iB-300 -2/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_12 , SW name: M-410iB-300 -2/M-410iB-300-11-1 ,  SW ref.type:2 (2)

link_49 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.4464528146208,3.21365418351145,-1.30282127554898)
cB = chrono.ChVectorD(1.9471686449099,3.0281083663764,-1.29812415062363)
dA = chrono.ChVectorD(-0.0093804069438573,3.19013824727569e-15,0.999956003014916)
dB = chrono.ChVectorD(0.00938040695038915,-3.30721958370176e-15,-0.999956003014855)
link_49.Initialize(body_3,body_12,False,cA,cB,dB)
link_49.SetDistance(0)
link_49.SetName("Coincident37")
exported_items.append(link_49)

link_50 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.4464528146208,3.21365418351145,-1.30282127554898)
dA = chrono.ChVectorD(-0.0093804069438573,3.19013824727569e-15,0.999956003014916)
cB = chrono.ChVectorD(1.9471686449099,3.0281083663764,-1.29812415062363)
dB = chrono.ChVectorD(0.00938040695038915,-3.30721958370176e-15,-0.999956003014855)
link_50.SetFlipped(True)
link_50.Initialize(body_3,body_12,False,cA,cB,dA,dB)
link_50.SetName("Coincident37")
exported_items.append(link_50)


# Mate constraint: Coincident38 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_5 , SW name: M-410iB-300 -2/M-410iB-300-03-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_6 , SW name: M-410iB-300 -2/M-410iB-300-06-1 ,  SW ref.type:4 (4)

link_51 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.249827347571566,2.51550127212935,-1.12419525029556)
cB = chrono.ChVectorD(1.44540805850692,2.75811166842827,-1.11297972323557)
dA = chrono.ChVectorD(-0.00938040695038913,3.44096786457492e-15,0.999956003014855)
dB = chrono.ChVectorD(0.00938040695038912,-3.18710021780773e-15,-0.999956003014855)
link_51.Initialize(body_5,body_6,False,cA,cB,dB)
link_51.SetDistance(0)
link_51.SetName("Coincident38")
exported_items.append(link_51)

link_52 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.249827347571566,2.51550127212935,-1.12419525029556)
dA = chrono.ChVectorD(-0.00938040695038913,3.44096786457492e-15,0.999956003014855)
cB = chrono.ChVectorD(1.44540805850692,2.75811166842827,-1.11297972323557)
dB = chrono.ChVectorD(0.00938040695038912,-3.18710021780773e-15,-0.999956003014855)
link_52.SetFlipped(True)
link_52.Initialize(body_5,body_6,False,cA,cB,dA,dB)
link_52.SetName("Coincident38")
exported_items.append(link_52)


# Mate constraint: Coincident6 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_25 , SW name: M-410iB-300 -3/M-410iB-300-03-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_19 , SW name: M-410iB-300 -3/M-410iB-300-06-1 ,  SW ref.type:5 (5)

link_1 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.43311921029243,2.75811166840772,-2.77564705505362)
dA = chrono.ChVectorD(-0.0568475351847499,-3.30117877478376e-15,-0.998382871319124)
cB = chrono.ChVectorD(1.43413767782952,2.75811166840772,-2.75776025414447)
dB = chrono.ChVectorD(0.0568475351847497,3.33805351970177e-15,0.998382871319124)
link_1.SetFlipped(True)
link_1.Initialize(body_25,body_19,False,cA,cB,dA,dB)
link_1.SetName("Coincident6")
exported_items.append(link_1)

link_2 = chrono.ChLinkMateGeneric()
link_2.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.43311921029243,2.75811166840772,-2.77564705505362)
cB = chrono.ChVectorD(1.43413767782952,2.75811166840772,-2.75776025414447)
dA = chrono.ChVectorD(-0.0568475351847499,-3.30117877478376e-15,-0.998382871319124)
dB = chrono.ChVectorD(0.0568475351847497,3.33805351970177e-15,0.998382871319124)
link_2.Initialize(body_25,body_19,False,cA,cB,dA,dB)
link_2.SetName("Coincident6")
exported_items.append(link_2)


# Mate constraint: Coincident7 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_24 , SW name: M-410iB-300 -3/M-410iB-300-02-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_15 , SW name: M-410iB-300 -3/M-410iB-300-07-1 ,  SW ref.type:5 (5)

link_3 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.259894443087786,2.51550127212934,-2.34808580130256)
dA = chrono.ChVectorD(-0.0568475351847498,-3.54706750418873e-15,-0.998382871319124)
cB = chrono.ChVectorD(0.242372516049893,2.51550127212934,-2.65581403912838)
dB = chrono.ChVectorD(0.0568475351847497,3.62210261783957e-15,0.998382871319124)
link_3.SetFlipped(True)
link_3.Initialize(body_24,body_15,False,cA,cB,dA,dB)
link_3.SetName("Coincident7")
exported_items.append(link_3)

link_4 = chrono.ChLinkMateGeneric()
link_4.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.259894443087786,2.51550127212934,-2.34808580130256)
cB = chrono.ChVectorD(0.242372516049893,2.51550127212934,-2.65581403912838)
dA = chrono.ChVectorD(-0.0568475351847498,-3.54706750418873e-15,-0.998382871319124)
dB = chrono.ChVectorD(0.0568475351847497,3.62210261783957e-15,0.998382871319124)
link_4.Initialize(body_24,body_15,False,cA,cB,dA,dB)
link_4.SetName("Coincident7")
exported_items.append(link_4)


# Mate constraint: Coincident8 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_19 , SW name: M-410iB-300 -3/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_15 , SW name: M-410iB-300 -3/M-410iB-300-07-1 ,  SW ref.type:2 (2)

link_5 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.967642991335604,3.1048247061665,-2.6210200545419)
cB = chrono.ChVectorD(-0.0737580540609007,3.0097326206868,-2.5617230811359)
dA = chrono.ChVectorD(-0.0568475351847497,-3.33805351970177e-15,-0.998382871319124)
dB = chrono.ChVectorD(-0.0568475351847497,-3.62210261783957e-15,-0.998382871319124)
link_5.Initialize(body_19,body_15,False,cA,cB,dB)
link_5.SetDistance(0)
link_5.SetName("Coincident8")
exported_items.append(link_5)

link_6 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.967642991335604,3.1048247061665,-2.6210200545419)
dA = chrono.ChVectorD(-0.0568475351847497,-3.33805351970177e-15,-0.998382871319124)
cB = chrono.ChVectorD(-0.0737580540609007,3.0097326206868,-2.5617230811359)
dB = chrono.ChVectorD(-0.0568475351847497,-3.62210261783957e-15,-0.998382871319124)
link_6.Initialize(body_19,body_15,False,cA,cB,dA,dB)
link_6.SetName("Coincident8")
exported_items.append(link_6)


# Mate constraint: Coincident9 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_19 , SW name: M-410iB-300 -3/M-410iB-300-06-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_17 , SW name: M-410iB-300 -3/M-410iB-300-08-1 ,  SW ref.type:5 (5)

link_7 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.1232151265549,3.25480223428779,-2.62987827184982)
dA = chrono.ChVectorD(-0.0568475351847497,-3.33805351970177e-15,-0.998382871319124)
cB = chrono.ChVectorD(1.12151959197048,3.25480223428779,-2.65965603936978)
dB = chrono.ChVectorD(-0.05684753518475,-3.60995955350763e-15,-0.998382871319124)
link_7.Initialize(body_19,body_17,False,cA,cB,dA,dB)
link_7.SetName("Coincident9")
exported_items.append(link_7)

link_8 = chrono.ChLinkMateGeneric()
link_8.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.1232151265549,3.25480223428779,-2.62987827184982)
cB = chrono.ChVectorD(1.12151959197048,3.25480223428779,-2.65965603936978)
dA = chrono.ChVectorD(-0.0568475351847497,-3.33805351970177e-15,-0.998382871319124)
dB = chrono.ChVectorD(-0.05684753518475,-3.60995955350763e-15,-0.998382871319124)
link_8.Initialize(body_19,body_17,False,cA,cB,dA,dB)
link_8.SetName("Coincident9")
exported_items.append(link_8)


# Mate constraint: Coincident11 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_24 , SW name: M-410iB-300 -3/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_23 , SW name: M-410iB-300 -3/M-410iB-300-09-1 ,  SW ref.type:2 (2)

link_9 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.120577183774373,2.72491052060181,-2.81732386647616)
cB = chrono.ChVectorD(1.42499793617119,3.21365418351156,-2.90532831700895)
dA = chrono.ChVectorD(-0.0568475351847498,-3.54706750418873e-15,-0.998382871319124)
dB = chrono.ChVectorD(-0.0568475351847499,-3.30313377976569e-15,-0.998382871319124)
link_9.Initialize(body_24,body_23,False,cA,cB,dB)
link_9.SetDistance(0)
link_9.SetName("Coincident11")
exported_items.append(link_9)

link_10 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.120577183774373,2.72491052060181,-2.81732386647616)
dA = chrono.ChVectorD(-0.0568475351847498,-3.54706750418873e-15,-0.998382871319124)
cB = chrono.ChVectorD(1.42499793617119,3.21365418351156,-2.90532831700895)
dB = chrono.ChVectorD(-0.0568475351847499,-3.30313377976569e-15,-0.998382871319124)
link_10.Initialize(body_24,body_23,False,cA,cB,dA,dB)
link_10.SetName("Coincident11")
exported_items.append(link_10)


# Mate constraint: Coincident22 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_23 , SW name: M-410iB-300 -3/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_20 , SW name: M-410iB-300 -3/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_11 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.42499793617119,3.21365418351156,-2.90532831700895)
cB = chrono.ChVectorD(0.925544798858272,3.03011496694474,-2.87688964822548)
dA = chrono.ChVectorD(-0.0568475351847499,-3.30313377976569e-15,-0.998382871319124)
dB = chrono.ChVectorD(0.0568475351847499,3.3137673910381e-15,0.998382871319124)
link_11.Initialize(body_23,body_20,False,cA,cB,dB)
link_11.SetDistance(0)
link_11.SetName("Coincident22")
exported_items.append(link_11)

link_12 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.42499793617119,3.21365418351156,-2.90532831700895)
dA = chrono.ChVectorD(-0.0568475351847499,-3.30313377976569e-15,-0.998382871319124)
cB = chrono.ChVectorD(0.925544798858272,3.03011496694474,-2.87688964822548)
dB = chrono.ChVectorD(0.0568475351847499,3.3137673910381e-15,0.998382871319124)
link_12.SetFlipped(True)
link_12.Initialize(body_23,body_20,False,cA,cB,dA,dB)
link_12.SetName("Coincident22")
exported_items.append(link_12)


# Mate constraint: Coincident15 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_19 , SW name: M-410iB-300 -3/M-410iB-300-06-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_14 , SW name: M-410iB-300 -3/M-410iB-300-12-1 ,  SW ref.type:5 (5)

link_13 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(2.18124641791443,1.69428746560667,-2.78026794229797)
dA = chrono.ChVectorD(0.0568475351847497,3.33805351970177e-15,0.998382871319124)
cB = chrono.ChVectorD(2.18053121919003,1.69428746559951,-2.79282859519823)
dB = chrono.ChVectorD(-0.0568475355314765,-1.00728311824644e-15,-0.998382871299382)
link_13.SetFlipped(True)
link_13.Initialize(body_19,body_14,False,cA,cB,dA,dB)
link_13.SetName("Coincident15")
exported_items.append(link_13)

link_14 = chrono.ChLinkMateGeneric()
link_14.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(2.18124641791443,1.69428746560667,-2.78026794229797)
cB = chrono.ChVectorD(2.18053121919003,1.69428746559951,-2.79282859519823)
dA = chrono.ChVectorD(0.0568475351847497,3.33805351970177e-15,0.998382871319124)
dB = chrono.ChVectorD(-0.0568475355314765,-1.00728311824644e-15,-0.998382871299382)
link_14.Initialize(body_19,body_14,False,cA,cB,dA,dB)
link_14.SetName("Coincident15")
exported_items.append(link_14)


# Mate constraint: Coincident17 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_15 , SW name: M-410iB-300 -3/M-410iB-300-07-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_17 , SW name: M-410iB-300 -3/M-410iB-300-08-1 ,  SW ref.type:5 (5)

link_15 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.0787954846962269,3.0097326206868,-2.6501927825121)
dA = chrono.ChVectorD(0.0568475351847497,3.62210261783957e-15,0.998382871319124)
cB = chrono.ChVectorD(-0.0754535886453212,3.0097326206868,-2.59150084865587)
dB = chrono.ChVectorD(-0.05684753518475,-3.60995955350763e-15,-0.998382871319124)
link_15.SetFlipped(True)
link_15.Initialize(body_15,body_17,False,cA,cB,dA,dB)
link_15.SetName("Coincident17")
exported_items.append(link_15)

link_16 = chrono.ChLinkMateGeneric()
link_16.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-0.0787954846962269,3.0097326206868,-2.6501927825121)
cB = chrono.ChVectorD(-0.0754535886453212,3.0097326206868,-2.59150084865587)
dA = chrono.ChVectorD(0.0568475351847497,3.62210261783957e-15,0.998382871319124)
dB = chrono.ChVectorD(-0.05684753518475,-3.60995955350763e-15,-0.998382871319124)
link_16.Initialize(body_15,body_17,False,cA,cB,dA,dB)
link_16.SetName("Coincident17")
exported_items.append(link_16)


# Mate constraint: Coincident18 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_24 , SW name: M-410iB-300 -3/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_18 , SW name: M-410iB-300 -3/ArmBase-1 ,  SW ref.type:2 (2)

link_17 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.140670357955045,2.04602671615661,-2.52259688656262)
cB = chrono.ChVectorD(-0.382669423498731,2.04602671615662,-2.52259688656261)
dA = chrono.ChVectorD(1.2948601181558e-17,-1,3.55207557141063e-15)
dB = chrono.ChVectorD(0,1,0)
link_17.Initialize(body_24,body_18,False,cA,cB,dB)
link_17.SetDistance(0)
link_17.SetName("Coincident18")
exported_items.append(link_17)

link_18 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.140670357955045,2.04602671615661,-2.52259688656262)
dA = chrono.ChVectorD(1.2948601181558e-17,-1,3.55207557141063e-15)
cB = chrono.ChVectorD(-0.382669423498731,2.04602671615662,-2.52259688656261)
dB = chrono.ChVectorD(0,1,0)
link_18.SetFlipped(True)
link_18.Initialize(body_24,body_18,False,cA,cB,dA,dB)
link_18.SetName("Coincident18")
exported_items.append(link_18)


# Mate constraint: Concentric1 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_24 , SW name: M-410iB-300 -3/M-410iB-300-02-1 ,  SW ref.type:1 (1)
#   Entity 1: C::E name: body_18 , SW name: M-410iB-300 -3/ArmBase-1 ,  SW ref.type:1 (1)

link_19 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.140670357955045,2.04755071615661,-2.52259688656262)
dA = chrono.ChVectorD(-1.2948601181558e-17,1,-3.55207557141063e-15)
cB = chrono.ChVectorD(-0.140670357955037,2.04602671615662,-2.52259688656261)
dB = chrono.ChVectorD(0,1,0)
link_19.Initialize(body_24,body_18,False,cA,cB,dA,dB)
link_19.SetName("Concentric1")
exported_items.append(link_19)

link_20 = chrono.ChLinkMateGeneric()
link_20.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-0.140670357955045,2.04755071615661,-2.52259688656262)
cB = chrono.ChVectorD(-0.140670357955037,2.04602671615662,-2.52259688656261)
dA = chrono.ChVectorD(-1.2948601181558e-17,1,-3.55207557141063e-15)
dB = chrono.ChVectorD(0,1,0)
link_20.Initialize(body_24,body_18,False,cA,cB,dA,dB)
link_20.SetName("Concentric1")
exported_items.append(link_20)


# Mate constraint: Coincident21 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_19 , SW name: M-410iB-300 -3/M-410iB-300-06-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_14 , SW name: M-410iB-300 -3/M-410iB-300-12-1 ,  SW ref.type:4 (4)

link_21 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.43925395610873,2.75811166840772,-2.66790579374853)
cB = chrono.ChVectorD(2.43981232926472,1.53528578498375,-2.72487720110108)
dA = chrono.ChVectorD(0.0568475351847497,3.33805351970177e-15,0.998382871319124)
dB = chrono.ChVectorD(-0.0568475353581131,-2.15520722562002e-15,-0.998382871309253)
link_21.Initialize(body_19,body_14,False,cA,cB,dB)
link_21.SetDistance(0)
link_21.SetName("Coincident21")
exported_items.append(link_21)

link_22 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.43925395610873,2.75811166840772,-2.66790579374853)
dA = chrono.ChVectorD(0.0568475351847497,3.33805351970177e-15,0.998382871319124)
cB = chrono.ChVectorD(2.43981232926472,1.53528578498375,-2.72487720110108)
dB = chrono.ChVectorD(-0.0568475353581131,-2.15520722562002e-15,-0.998382871309253)
link_22.SetFlipped(True)
link_22.Initialize(body_19,body_14,False,cA,cB,dA,dB)
link_22.SetName("Coincident21")
exported_items.append(link_22)


# Mate constraint: Coincident25 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_25 , SW name: M-410iB-300 -3/M-410iB-300-03-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_22 , SW name: M-410iB-300 -3/M-410iB-300-05-1 ,  SW ref.type:2 (2)

link_23 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.44941940875874,2.75811166840772,-2.48937538302814)
cB = chrono.ChVectorD(1.44941940875874,2.75811166840772,-2.48937538302814)
dA = chrono.ChVectorD(0.0568475351847499,3.30117877478376e-15,0.998382871319124)
dB = chrono.ChVectorD(-0.0568475351847498,-3.3020580075752e-15,-0.998382871319124)
link_23.Initialize(body_25,body_22,False,cA,cB,dB)
link_23.SetDistance(0)
link_23.SetName("Coincident25")
exported_items.append(link_23)

link_24 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.44941940875874,2.75811166840772,-2.48937538302814)
dA = chrono.ChVectorD(0.0568475351847499,3.30117877478376e-15,0.998382871319124)
cB = chrono.ChVectorD(1.44941940875874,2.75811166840772,-2.48937538302814)
dB = chrono.ChVectorD(-0.0568475351847498,-3.3020580075752e-15,-0.998382871319124)
link_24.SetFlipped(True)
link_24.Initialize(body_25,body_22,False,cA,cB,dA,dB)
link_24.SetName("Coincident25")
exported_items.append(link_24)


# Mate constraint: Concentric2 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_19 , SW name: M-410iB-300 -3/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_23 , SW name: M-410iB-300 -3/M-410iB-300-09-1 ,  SW ref.type:2 (2)

link_25 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.42887928082493,2.75811166840772,-2.85011066974149)
dA = chrono.ChVectorD(0.0568475351847497,3.33805351970177e-15,0.998382871319124)
cB = chrono.ChVectorD(1.42537184485721,2.75811166841886,-2.91170989262509)
dB = chrono.ChVectorD(0.0568475351847499,3.30313377976569e-15,0.998382871319124)
link_25.Initialize(body_19,body_23,False,cA,cB,dA,dB)
link_25.SetName("Concentric2")
exported_items.append(link_25)

link_26 = chrono.ChLinkMateGeneric()
link_26.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.42887928082493,2.75811166840772,-2.85011066974149)
cB = chrono.ChVectorD(1.42537184485721,2.75811166841886,-2.91170989262509)
dA = chrono.ChVectorD(0.0568475351847497,3.33805351970177e-15,0.998382871319124)
dB = chrono.ChVectorD(0.0568475351847499,3.30313377976569e-15,0.998382871319124)
link_26.Initialize(body_19,body_23,False,cA,cB,dA,dB)
link_26.SetName("Concentric2")
exported_items.append(link_26)


# Mate constraint: Concentric3 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_23 , SW name: M-410iB-300 -3/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_20 , SW name: M-410iB-300 -3/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_27 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.925524449552671,3.03011496694476,-2.87724703220075)
dA = chrono.ChVectorD(0.0568475351847499,3.30313377976569e-15,0.998382871319124)
cB = chrono.ChVectorD(0.92310740393969,3.03011496694474,-2.91969631221616)
dB = chrono.ChVectorD(0.0568475351847499,3.3137673910381e-15,0.998382871319124)
link_27.Initialize(body_23,body_20,False,cA,cB,dA,dB)
link_27.SetName("Concentric3")
exported_items.append(link_27)

link_28 = chrono.ChLinkMateGeneric()
link_28.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.925524449552671,3.03011496694476,-2.87724703220075)
cB = chrono.ChVectorD(0.92310740393969,3.03011496694474,-2.91969631221616)
dA = chrono.ChVectorD(0.0568475351847499,3.30313377976569e-15,0.998382871319124)
dB = chrono.ChVectorD(0.0568475351847499,3.3137673910381e-15,0.998382871319124)
link_28.Initialize(body_23,body_20,False,cA,cB,dA,dB)
link_28.SetName("Concentric3")
exported_items.append(link_28)


# Mate constraint: Concentric4 [MateConcentric] type:1 align:1 flip:False
#   Entity 0: C::E name: body_23 , SW name: M-410iB-300 -3/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_16 , SW name: M-410iB-300 -3/M-410iB-300-11-1 ,  SW ref.type:2 (2)

link_29 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.92490569055697,3.02810836636698,-2.93415141416987)
dA = chrono.ChVectorD(0.0568475351847499,3.30313377976569e-15,0.998382871319124)
cB = chrono.ChVectorD(1.93061511379586,3.02810836635585,-2.83387986596459)
dB = chrono.ChVectorD(-0.0568475351847497,-3.25478679285488e-15,-0.998382871319124)
link_29.SetFlipped(True)
link_29.Initialize(body_23,body_16,False,cA,cB,dA,dB)
link_29.SetName("Concentric4")
exported_items.append(link_29)

link_30 = chrono.ChLinkMateGeneric()
link_30.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.92490569055697,3.02810836636698,-2.93415141416987)
cB = chrono.ChVectorD(1.93061511379586,3.02810836635585,-2.83387986596459)
dA = chrono.ChVectorD(0.0568475351847499,3.30313377976569e-15,0.998382871319124)
dB = chrono.ChVectorD(-0.0568475351847497,-3.25478679285488e-15,-0.998382871319124)
link_30.Initialize(body_23,body_16,False,cA,cB,dA,dB)
link_30.SetName("Concentric4")
exported_items.append(link_30)


# Mate constraint: Concentric6 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_25 , SW name: M-410iB-300 -3/M-410iB-300-03-1 ,  SW ref.type:1 (1)
#   Entity 1: C::E name: body_22 , SW name: M-410iB-300 -3/M-410iB-300-05-1 ,  SW ref.type:2 (2)

link_31 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.44941940875874,2.75811166840772,-2.48937538302814)
dA = chrono.ChVectorD(0.0568475351847499,3.30117877478376e-15,0.998382871319124)
cB = chrono.ChVectorD(1.44941940875874,2.75811166840772,-2.48937538302814)
dB = chrono.ChVectorD(0.0568475351847498,3.3020580075752e-15,0.998382871319124)
link_31.Initialize(body_25,body_22,False,cA,cB,dA,dB)
link_31.SetName("Concentric6")
exported_items.append(link_31)

link_32 = chrono.ChLinkMateGeneric()
link_32.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.44941940875874,2.75811166840772,-2.48937538302814)
cB = chrono.ChVectorD(1.44941940875874,2.75811166840772,-2.48937538302814)
dA = chrono.ChVectorD(0.0568475351847499,3.30117877478376e-15,0.998382871319124)
dB = chrono.ChVectorD(0.0568475351847498,3.3020580075752e-15,0.998382871319124)
link_32.Initialize(body_25,body_22,False,cA,cB,dA,dB)
link_32.SetName("Concentric6")
exported_items.append(link_32)


# Mate constraint: Concentric7 [MateConcentric] type:1 align:1 flip:False
#   Entity 0: C::E name: body_24 , SW name: M-410iB-300 -3/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_21 , SW name: M-410iB-300 -3/M-410iB-300-04-1 ,  SW ref.type:2 (2)

link_33 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.260184439377051,2.78049691677856,-2.34305414364787)
dA = chrono.ChVectorD(-0.0568475351847498,-3.54706750418873e-15,-0.998382871319124)
cB = chrono.ChVectorD(0.258902667167658,2.78049691677856,-2.36556522376138)
dB = chrono.ChVectorD(0.0568475351847498,3.5470675041887e-15,0.998382871319124)
link_33.SetFlipped(True)
link_33.Initialize(body_24,body_21,False,cA,cB,dA,dB)
link_33.SetName("Concentric7")
exported_items.append(link_33)

link_34 = chrono.ChLinkMateGeneric()
link_34.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.260184439377051,2.78049691677856,-2.34305414364787)
cB = chrono.ChVectorD(0.258902667167658,2.78049691677856,-2.36556522376138)
dA = chrono.ChVectorD(-0.0568475351847498,-3.54706750418873e-15,-0.998382871319124)
dB = chrono.ChVectorD(0.0568475351847498,3.5470675041887e-15,0.998382871319124)
link_34.Initialize(body_24,body_21,False,cA,cB,dA,dB)
link_34.SetName("Concentric7")
exported_items.append(link_34)


# Mate constraint: Concentric8 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_16 , SW name: M-410iB-300 -3/M-410iB-300-11-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_14 , SW name: M-410iB-300 -3/M-410iB-300-12-1 ,  SW ref.type:2 (2)

link_35 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(2.67658692097436,1.96428417607757,-2.87635521262131)
dA = chrono.ChVectorD(-0.0568475351847497,-3.25478679285488e-15,-0.998382871319124)
cB = chrono.ChVectorD(2.68008543199597,1.96428417607757,-2.8149127337566)
dB = chrono.ChVectorD(-0.0568475351847498,-3.3031313329936e-15,-0.998382871319124)
link_35.Initialize(body_16,body_14,False,cA,cB,dA,dB)
link_35.SetName("Concentric8")
exported_items.append(link_35)

link_36 = chrono.ChLinkMateGeneric()
link_36.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(2.67658692097436,1.96428417607757,-2.87635521262131)
cB = chrono.ChVectorD(2.68008543199597,1.96428417607757,-2.8149127337566)
dA = chrono.ChVectorD(-0.0568475351847497,-3.25478679285488e-15,-0.998382871319124)
dB = chrono.ChVectorD(-0.0568475351847498,-3.3031313329936e-15,-0.998382871319124)
link_36.Initialize(body_16,body_14,False,cA,cB,dA,dB)
link_36.SetName("Concentric8")
exported_items.append(link_36)


# Mate constraint: Concentric9 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_25 , SW name: M-410iB-300 -3/M-410iB-300-03-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_15 , SW name: M-410iB-300 -3/M-410iB-300-07-1 ,  SW ref.type:2 (2)

link_37 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.255358604635414,2.51550127212934,-2.42774630730708)
dA = chrono.ChVectorD(-0.0568475351847499,-3.30117877478376e-15,-0.998382871319124)
cB = chrono.ChVectorD(0.252267810111013,2.51550127212934,-2.48202827928529)
dB = chrono.ChVectorD(-0.0568475351847497,-3.62210261783957e-15,-0.998382871319124)
link_37.Initialize(body_25,body_15,False,cA,cB,dA,dB)
link_37.SetName("Concentric9")
exported_items.append(link_37)

link_38 = chrono.ChLinkMateGeneric()
link_38.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.255358604635414,2.51550127212934,-2.42774630730708)
cB = chrono.ChVectorD(0.252267810111013,2.51550127212934,-2.48202827928529)
dA = chrono.ChVectorD(-0.0568475351847499,-3.30117877478376e-15,-0.998382871319124)
dB = chrono.ChVectorD(-0.0568475351847497,-3.62210261783957e-15,-0.998382871319124)
link_38.Initialize(body_25,body_15,False,cA,cB,dA,dB)
link_38.SetName("Concentric9")
exported_items.append(link_38)


# Mate constraint: Coincident33 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_21 , SW name: M-410iB-300 -3/M-410iB-300-04-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_22 , SW name: M-410iB-300 -3/M-410iB-300-05-1 ,  SW ref.type:4 (4)

link_39 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.263985291593456,2.78049691677856,-2.27630180800248)
cB = chrono.ChVectorD(0.590238935173268,2.77437872020596,-2.29487856449075)
dA = chrono.ChVectorD(-0.018689005618213,-0.99982477898126,0.00106414476347051)
dB = chrono.ChVectorD(-0.018689005618213,-0.99982477898126,0.00106414476347026)
link_39.Initialize(body_21,body_22,False,cA,cB,dB)
link_39.SetDistance(0)
link_39.SetName("Coincident33")
exported_items.append(link_39)

link_40 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.263985291593456,2.78049691677856,-2.27630180800248)
dA = chrono.ChVectorD(-0.018689005618213,-0.99982477898126,0.00106414476347051)
cB = chrono.ChVectorD(0.590238935173268,2.77437872020596,-2.29487856449075)
dB = chrono.ChVectorD(-0.018689005618213,-0.99982477898126,0.00106414476347026)
link_40.Initialize(body_21,body_22,False,cA,cB,dA,dB)
link_40.SetName("Coincident33")
exported_items.append(link_40)


# Mate constraint: Coincident34 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_21 , SW name: M-410iB-300 -3/M-410iB-300-04-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_22 , SW name: M-410iB-300 -3/M-410iB-300-05-1 ,  SW ref.type:4 (4)

link_41 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.263985291593456,2.78049691677856,-2.27630180800248)
cB = chrono.ChVectorD(0.590238935173268,2.77437872020596,-2.29487856449075)
dA = chrono.ChVectorD(-0.0568475351847498,-3.5470675041887e-15,-0.998382871319124)
dB = chrono.ChVectorD(0.0568475351847498,3.3020580075752e-15,0.998382871319124)
link_41.Initialize(body_21,body_22,False,cA,cB,dB)
link_41.SetDistance(0)
link_41.SetName("Coincident34")
exported_items.append(link_41)

link_42 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.263985291593456,2.78049691677856,-2.27630180800248)
dA = chrono.ChVectorD(-0.0568475351847498,-3.5470675041887e-15,-0.998382871319124)
cB = chrono.ChVectorD(0.590238935173268,2.77437872020596,-2.29487856449075)
dB = chrono.ChVectorD(0.0568475351847498,3.3020580075752e-15,0.998382871319124)
link_42.SetFlipped(True)
link_42.Initialize(body_21,body_22,False,cA,cB,dA,dB)
link_42.SetName("Coincident34")
exported_items.append(link_42)


# Mate constraint: Concentric10 [MateConcentric] type:1 align:1 flip:False
#   Entity 0: C::E name: body_24 , SW name: M-410iB-300 -3/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_20 , SW name: M-410iB-300 -3/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_43 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.268153325090669,2.787496924021,-2.80892093797357)
dA = chrono.ChVectorD(0.0568475351847498,3.54706750418873e-15,0.998382871319124)
cB = chrono.ChVectorD(-0.268153325090537,2.78749692402099,-2.80892093797358)
dB = chrono.ChVectorD(-0.0568475351847499,-3.3137673910381e-15,-0.998382871319124)
link_43.SetFlipped(True)
link_43.Initialize(body_24,body_20,False,cA,cB,dA,dB)
link_43.SetName("Concentric10")
exported_items.append(link_43)

link_44 = chrono.ChLinkMateGeneric()
link_44.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-0.268153325090669,2.787496924021,-2.80892093797357)
cB = chrono.ChVectorD(-0.268153325090537,2.78749692402099,-2.80892093797358)
dA = chrono.ChVectorD(0.0568475351847498,3.54706750418873e-15,0.998382871319124)
dB = chrono.ChVectorD(-0.0568475351847499,-3.3137673910381e-15,-0.998382871319124)
link_44.Initialize(body_24,body_20,False,cA,cB,dA,dB)
link_44.SetName("Concentric10")
exported_items.append(link_44)


# Mate constraint: Coincident35 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_16 , SW name: M-410iB-300 -3/M-410iB-300-11-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_14 , SW name: M-410iB-300 -3/M-410iB-300-12-1 ,  SW ref.type:2 (2)

link_45 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(2.67728000612333,1.96428417607757,-2.86418292865418)
cB = chrono.ChVectorD(2.53871568521833,2.16290587221822,-2.85629312967777)
dA = chrono.ChVectorD(0.0568475351847497,3.25478679285488e-15,0.998382871319124)
dB = chrono.ChVectorD(-0.0568475355314765,-1.00728311824644e-15,-0.998382871299382)
link_45.Initialize(body_16,body_14,False,cA,cB,dB)
link_45.SetDistance(0)
link_45.SetName("Coincident35")
exported_items.append(link_45)

link_46 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(2.67728000612333,1.96428417607757,-2.86418292865418)
dA = chrono.ChVectorD(0.0568475351847497,3.25478679285488e-15,0.998382871319124)
cB = chrono.ChVectorD(2.53871568521833,2.16290587221822,-2.85629312967777)
dB = chrono.ChVectorD(-0.0568475355314765,-1.00728311824644e-15,-0.998382871299382)
link_46.SetFlipped(True)
link_46.Initialize(body_16,body_14,False,cA,cB,dA,dB)
link_46.SetName("Coincident35")
exported_items.append(link_46)


# Mate constraint: Coincident36 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_19 , SW name: M-410iB-300 -3/M-410iB-300-06-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_17 , SW name: M-410iB-300 -3/M-410iB-300-08-1 ,  SW ref.type:4 (4)

link_47 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.43754852994061,2.75811166840772,-2.69785728186532)
cB = chrono.ChVectorD(-0.0766004308201383,3.0097326206868,-2.61164222470186)
dA = chrono.ChVectorD(0.0568475351847497,3.33805351970177e-15,0.998382871319124)
dB = chrono.ChVectorD(0.05684753518475,3.60995955350763e-15,0.998382871319124)
link_47.Initialize(body_19,body_17,False,cA,cB,dB)
link_47.SetDistance(0)
link_47.SetName("Coincident36")
exported_items.append(link_47)

link_48 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.43754852994061,2.75811166840772,-2.69785728186532)
dA = chrono.ChVectorD(0.0568475351847497,3.33805351970177e-15,0.998382871319124)
cB = chrono.ChVectorD(-0.0766004308201383,3.0097326206868,-2.61164222470186)
dB = chrono.ChVectorD(0.05684753518475,3.60995955350763e-15,0.998382871319124)
link_48.Initialize(body_19,body_17,False,cA,cB,dA,dB)
link_48.SetName("Coincident36")
exported_items.append(link_48)


# Mate constraint: Coincident37 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_23 , SW name: M-410iB-300 -3/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_16 , SW name: M-410iB-300 -3/M-410iB-300-11-1 ,  SW ref.type:2 (2)

link_49 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.42772695894527,3.21365418351156,-2.8573999488884)
cB = chrono.ChVectorD(1.92765506263879,3.02810836635585,-2.88586566207418)
dA = chrono.ChVectorD(0.0568475351847499,3.30313377976569e-15,0.998382871319124)
dB = chrono.ChVectorD(-0.0568475351847497,-3.25478679285488e-15,-0.998382871319124)
link_49.Initialize(body_23,body_16,False,cA,cB,dB)
link_49.SetDistance(0)
link_49.SetName("Coincident37")
exported_items.append(link_49)

link_50 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.42772695894527,3.21365418351156,-2.8573999488884)
dA = chrono.ChVectorD(0.0568475351847499,3.30313377976569e-15,0.998382871319124)
cB = chrono.ChVectorD(1.92765506263879,3.02810836635585,-2.88586566207418)
dB = chrono.ChVectorD(-0.0568475351847497,-3.25478679285488e-15,-0.998382871319124)
link_50.SetFlipped(True)
link_50.Initialize(body_23,body_16,False,cA,cB,dA,dB)
link_50.SetName("Coincident37")
exported_items.append(link_50)


# Mate constraint: Coincident38 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_25 , SW name: M-410iB-300 -3/M-410iB-300-03-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_19 , SW name: M-410iB-300 -3/M-410iB-300-06-1 ,  SW ref.type:4 (4)

link_51 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.245554133833828,2.51550127212934,-2.5999369867946)
cB = chrono.ChVectorD(1.43925395599615,2.75811166840772,-2.66790579572575)
dA = chrono.ChVectorD(0.0568475351847499,3.30117877478376e-15,0.998382871319124)
dB = chrono.ChVectorD(-0.0568475351847497,-3.33805351970177e-15,-0.998382871319124)
link_51.Initialize(body_25,body_19,False,cA,cB,dB)
link_51.SetDistance(0)
link_51.SetName("Coincident38")
exported_items.append(link_51)

link_52 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.245554133833828,2.51550127212934,-2.5999369867946)
dA = chrono.ChVectorD(0.0568475351847499,3.30117877478376e-15,0.998382871319124)
cB = chrono.ChVectorD(1.43925395599615,2.75811166840772,-2.66790579572575)
dB = chrono.ChVectorD(-0.0568475351847497,-3.33805351970177e-15,-0.998382871319124)
link_52.SetFlipped(True)
link_52.Initialize(body_25,body_19,False,cA,cB,dA,dB)
link_52.SetName("Coincident38")
exported_items.append(link_52)


# Mate constraint: Coincident6 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_26 , SW name: M-410iB-300 -8/M-410iB-300-03-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_28 , SW name: M-410iB-300 -8/M-410iB-300-06-1 ,  SW ref.type:5 (5)

link_1 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.07812670840691,2.7581116684078,-0.843512938362607)
dA = chrono.ChVectorD(0.0416558036603413,2.85068089004698e-15,0.99913202031634)
cB = chrono.ChVectorD(-3.07887300441273,2.7581116684078,-0.861413162833857)
dB = chrono.ChVectorD(-0.0416558036603408,-3.56949234828483e-15,-0.99913202031634)
link_1.SetFlipped(True)
link_1.Initialize(body_26,body_28,False,cA,cB,dA,dB)
link_1.SetName("Coincident6")
exported_items.append(link_1)

link_2 = chrono.ChLinkMateGeneric()
link_2.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.07812670840691,2.7581116684078,-0.843512938362607)
cB = chrono.ChVectorD(-3.07887300441273,2.7581116684078,-0.861413162833857)
dA = chrono.ChVectorD(0.0416558036603413,2.85068089004698e-15,0.99913202031634)
dB = chrono.ChVectorD(-0.0416558036603408,-3.56949234828483e-15,-0.99913202031634)
link_2.Initialize(body_26,body_28,False,cA,cB,dA,dB)
link_2.SetName("Coincident6")
exported_items.append(link_2)


# Mate constraint: Coincident7 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_27 , SW name: M-410iB-300 -8/M-410iB-300-02-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_36 , SW name: M-410iB-300 -8/M-410iB-300-07-1 ,  SW ref.type:5 (5)

link_3 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.89853455338281,2.51550127212935,-1.25318027646805)
dA = chrono.ChVectorD(0.041655803660341,2.95268223151123e-15,0.99913202031634)
cB = chrono.ChVectorD(-1.88569512339832,2.51550127212935,-0.945221132894247)
dB = chrono.ChVectorD(-0.041655803660342,-2.48436689812231e-15,-0.99913202031634)
link_3.SetFlipped(True)
link_3.Initialize(body_27,body_36,False,cA,cB,dA,dB)
link_3.SetName("Coincident7")
exported_items.append(link_3)

link_4 = chrono.ChLinkMateGeneric()
link_4.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.89853455338281,2.51550127212935,-1.25318027646805)
cB = chrono.ChVectorD(-1.88569512339832,2.51550127212935,-0.945221132894247)
dA = chrono.ChVectorD(0.041655803660341,2.95268223151123e-15,0.99913202031634)
dB = chrono.ChVectorD(-0.041655803660342,-2.48436689812231e-15,-0.99913202031634)
link_4.Initialize(body_27,body_36,False,cA,cB,dA,dB)
link_4.SetName("Coincident7")
exported_items.append(link_4)


# Mate constraint: Coincident8 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_28 , SW name: M-410iB-300 -8/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_36 , SW name: M-410iB-300 -8/M-410iB-300-07-1 ,  SW ref.type:2 (2)

link_5 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-2.61060954750147,3.1051757999597,-0.991031559591282)
cB = chrono.ChVectorD(-1.56853751602833,3.00997129509906,-1.03447761783015)
dA = chrono.ChVectorD(0.0416558036603408,3.56949234828483e-15,0.99913202031634)
dB = chrono.ChVectorD(0.041655803660342,2.48436689812231e-15,0.99913202031634)
link_5.Initialize(body_28,body_36,False,cA,cB,dB)
link_5.SetDistance(0)
link_5.SetName("Coincident8")
exported_items.append(link_5)

link_6 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.61060954750147,3.1051757999597,-0.991031559591282)
dA = chrono.ChVectorD(0.0416558036603408,3.56949234828483e-15,0.99913202031634)
cB = chrono.ChVectorD(-1.56853751602833,3.00997129509906,-1.03447761783015)
dB = chrono.ChVectorD(0.041655803660342,2.48436689812231e-15,0.99913202031634)
link_6.Initialize(body_28,body_36,False,cA,cB,dA,dB)
link_6.SetName("Coincident8")
exported_items.append(link_6)


# Mate constraint: Coincident9 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_28 , SW name: M-410iB-300 -8/M-410iB-300-06-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_29 , SW name: M-410iB-300 -8/M-410iB-300-08-1 ,  SW ref.type:5 (5)

link_7 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.76640951212787,3.25503771731949,-0.984535948796314)
dA = chrono.ChVectorD(0.0416558036603408,3.56949234828483e-15,0.99913202031634)
cB = chrono.ChVectorD(-2.7651670861279,3.25503771731949,-0.954735837158357)
dB = chrono.ChVectorD(0.0416558036603418,2.76863012562884e-15,0.99913202031634)
link_7.Initialize(body_28,body_29,False,cA,cB,dA,dB)
link_7.SetName("Coincident9")
exported_items.append(link_7)

link_8 = chrono.ChLinkMateGeneric()
link_8.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-2.76640951212787,3.25503771731949,-0.984535948796314)
cB = chrono.ChVectorD(-2.7651670861279,3.25503771731949,-0.954735837158357)
dA = chrono.ChVectorD(0.0416558036603408,3.56949234828483e-15,0.99913202031634)
dB = chrono.ChVectorD(0.0416558036603418,2.76863012562884e-15,0.99913202031634)
link_8.Initialize(body_28,body_29,False,cA,cB,dA,dB)
link_8.SetName("Coincident9")
exported_items.append(link_8)


# Mate constraint: Coincident11 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_27 , SW name: M-410iB-300 -8/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_30 , SW name: M-410iB-300 -8/M-410iB-300-09-1 ,  SW ref.type:2 (2)

link_9 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.52524393207574,2.72491052060182,-0.778209611374734)
cB = chrono.ChVectorD(-3.07197879352373,3.21365418351158,-0.71372315473742)
dA = chrono.ChVectorD(0.041655803660341,2.95268223151123e-15,0.99913202031634)
dB = chrono.ChVectorD(0.0416558036603411,2.77414641929916e-15,0.99913202031634)
link_9.Initialize(body_27,body_30,False,cA,cB,dB)
link_9.SetDistance(0)
link_9.SetName("Coincident11")
exported_items.append(link_9)

link_10 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.52524393207574,2.72491052060182,-0.778209611374734)
dA = chrono.ChVectorD(0.041655803660341,2.95268223151123e-15,0.99913202031634)
cB = chrono.ChVectorD(-3.07197879352373,3.21365418351158,-0.71372315473742)
dB = chrono.ChVectorD(0.0416558036603411,2.77414641929916e-15,0.99913202031634)
link_10.Initialize(body_27,body_30,False,cA,cB,dA,dB)
link_10.SetName("Coincident11")
exported_items.append(link_10)


# Mate constraint: Coincident22 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_30 , SW name: M-410iB-300 -8/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_34 , SW name: M-410iB-300 -8/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_11 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.07197879352373,3.21365418351158,-0.71372315473742)
cB = chrono.ChVectorD(-2.57215088534103,3.03011496694473,-0.734561975617793)
dA = chrono.ChVectorD(0.0416558036603411,2.77414641929916e-15,0.99913202031634)
dB = chrono.ChVectorD(-0.0416558036603407,-2.96522855540048e-15,-0.99913202031634)
link_11.Initialize(body_30,body_34,False,cA,cB,dB)
link_11.SetDistance(0)
link_11.SetName("Coincident22")
exported_items.append(link_11)

link_12 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.07197879352373,3.21365418351158,-0.71372315473742)
dA = chrono.ChVectorD(0.0416558036603411,2.77414641929916e-15,0.99913202031634)
cB = chrono.ChVectorD(-2.57215088534103,3.03011496694473,-0.734561975617793)
dB = chrono.ChVectorD(-0.0416558036603407,-2.96522855540048e-15,-0.99913202031634)
link_12.SetFlipped(True)
link_12.Initialize(body_30,body_34,False,cA,cB,dA,dB)
link_12.SetName("Coincident22")
exported_items.append(link_12)


# Mate constraint: Coincident15 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_28 , SW name: M-410iB-300 -8/M-410iB-300-06-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_32 , SW name: M-410iB-300 -8/M-410iB-300-12-1 ,  SW ref.type:5 (5)

link_13 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.82544913594577,1.6937335998562,-0.850304291870274)
dA = chrono.ChVectorD(-0.0416558036603408,-3.56949234828483e-15,-0.99913202031634)
cB = chrono.ChVectorD(-3.82492506427183,1.69373359986733,-0.837734211925638)
dB = chrono.ChVectorD(0.0416558040073285,5.28992084709618e-15,0.999132020301874)
link_13.SetFlipped(True)
link_13.Initialize(body_28,body_32,False,cA,cB,dA,dB)
link_13.SetName("Coincident15")
exported_items.append(link_13)

link_14 = chrono.ChLinkMateGeneric()
link_14.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.82544913594577,1.6937335998562,-0.850304291870274)
cB = chrono.ChVectorD(-3.82492506427183,1.69373359986733,-0.837734211925638)
dA = chrono.ChVectorD(-0.0416558036603408,-3.56949234828483e-15,-0.99913202031634)
dB = chrono.ChVectorD(0.0416558040073285,5.28992084709618e-15,0.999132020301874)
link_14.Initialize(body_28,body_32,False,cA,cB,dA,dB)
link_14.SetName("Coincident15")
exported_items.append(link_14)


# Mate constraint: Coincident17 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_36 , SW name: M-410iB-300 -8/M-410iB-300-07-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_29 , SW name: M-410iB-300 -8/M-410iB-300-08-1 ,  SW ref.type:5 (5)

link_15 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.56484627029858,3.00997129509906,-0.945941532113853)
dA = chrono.ChVectorD(-0.041655803660342,-2.48436689812231e-15,-0.99913202031634)
cB = chrono.ChVectorD(-1.56729509002836,3.00997129509906,-1.00467750619219)
dB = chrono.ChVectorD(0.0416558036603418,2.76863012562884e-15,0.99913202031634)
link_15.SetFlipped(True)
link_15.Initialize(body_36,body_29,False,cA,cB,dA,dB)
link_15.SetName("Coincident17")
exported_items.append(link_15)

link_16 = chrono.ChLinkMateGeneric()
link_16.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.56484627029858,3.00997129509906,-0.945941532113853)
cB = chrono.ChVectorD(-1.56729509002836,3.00997129509906,-1.00467750619219)
dA = chrono.ChVectorD(-0.041655803660342,-2.48436689812231e-15,-0.99913202031634)
dB = chrono.ChVectorD(0.0416558036603418,2.76863012562884e-15,0.99913202031634)
link_16.Initialize(body_36,body_29,False,cA,cB,dA,dB)
link_16.SetName("Coincident17")
exported_items.append(link_16)


# Mate constraint: Coincident18 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_27 , SW name: M-410iB-300 -8/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_35 , SW name: M-410iB-300 -8/ArmBase-1 ,  SW ref.type:2 (2)

link_17 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.50067035795504,2.04602671615662,-1.07259688656262)
cB = chrono.ChVectorD(-1.25867129241134,2.04602671615662,-1.07259688656262)
dA = chrono.ChVectorD(1.50390454972124e-16,-1,2.75960845633487e-15)
dB = chrono.ChVectorD(5.42136132923115e-17,1,-3.51853802391695e-15)
link_17.Initialize(body_27,body_35,False,cA,cB,dB)
link_17.SetDistance(0)
link_17.SetName("Coincident18")
exported_items.append(link_17)

link_18 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.50067035795504,2.04602671615662,-1.07259688656262)
dA = chrono.ChVectorD(1.50390454972124e-16,-1,2.75960845633487e-15)
cB = chrono.ChVectorD(-1.25867129241134,2.04602671615662,-1.07259688656262)
dB = chrono.ChVectorD(5.42136132923115e-17,1,-3.51853802391695e-15)
link_18.SetFlipped(True)
link_18.Initialize(body_27,body_35,False,cA,cB,dA,dB)
link_18.SetName("Coincident18")
exported_items.append(link_18)


# Mate constraint: Concentric1 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_27 , SW name: M-410iB-300 -8/M-410iB-300-02-1 ,  SW ref.type:1 (1)
#   Entity 1: C::E name: body_35 , SW name: M-410iB-300 -8/ArmBase-1 ,  SW ref.type:1 (1)

link_19 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.50067035795504,2.04755071615662,-1.07259688656262)
dA = chrono.ChVectorD(-1.50390454972124e-16,1,-2.75960845633487e-15)
cB = chrono.ChVectorD(-1.50067035795504,2.04602671615662,-1.07259688656262)
dB = chrono.ChVectorD(5.42136132923115e-17,1,-3.51853802391695e-15)
link_19.Initialize(body_27,body_35,False,cA,cB,dA,dB)
link_19.SetName("Concentric1")
exported_items.append(link_19)

link_20 = chrono.ChLinkMateGeneric()
link_20.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.50067035795504,2.04755071615662,-1.07259688656262)
cB = chrono.ChVectorD(-1.50067035795504,2.04602671615662,-1.07259688656262)
dA = chrono.ChVectorD(-1.50390454972124e-16,1,-2.75960845633487e-15)
dB = chrono.ChVectorD(5.42136132923115e-17,1,-3.51853802391695e-15)
link_20.Initialize(body_27,body_35,False,cA,cB,dA,dB)
link_20.SetName("Concentric1")
exported_items.append(link_20)


# Mate constraint: Coincident21 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_28 , SW name: M-410iB-300 -8/M-410iB-300-06-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_32 , SW name: M-410iB-300 -8/M-410iB-300-12-1 ,  SW ref.type:4 (4)

link_21 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.08262202682466,2.7581116684078,-0.95133504664103)
cB = chrono.ChVectorD(-4.08314265816311,1.53473191923498,-0.909621347082246)
dA = chrono.ChVectorD(-0.0416558036603408,-3.56949234828483e-15,-0.99913202031634)
dB = chrono.ChVectorD(0.0416558038338351,4.14198543914452e-15,0.999132020309107)
link_21.Initialize(body_28,body_32,False,cA,cB,dB)
link_21.SetDistance(0)
link_21.SetName("Coincident21")
exported_items.append(link_21)

link_22 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.08262202682466,2.7581116684078,-0.95133504664103)
dA = chrono.ChVectorD(-0.0416558036603408,-3.56949234828483e-15,-0.99913202031634)
cB = chrono.ChVectorD(-4.08314265816311,1.53473191923498,-0.909621347082246)
dB = chrono.ChVectorD(0.0416558038338351,4.14198543914452e-15,0.999132020309107)
link_22.SetFlipped(True)
link_22.Initialize(body_28,body_32,False,cA,cB,dA,dB)
link_22.SetName("Coincident21")
exported_items.append(link_22)


# Mate constraint: Coincident25 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_26 , SW name: M-410iB-300 -8/M-410iB-300-03-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_33 , SW name: M-410iB-300 -8/M-410iB-300-05-1 ,  SW ref.type:2 (2)

link_23 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.09007090026555,2.7581116684078,-1.1299994178955)
cB = chrono.ChVectorD(-3.09007090026555,2.7581116684078,-1.1299994178955)
dA = chrono.ChVectorD(-0.0416558036603413,-2.85068089004698e-15,-0.99913202031634)
dB = chrono.ChVectorD(0.0416558036603413,2.85608731879049e-15,0.99913202031634)
link_23.Initialize(body_26,body_33,False,cA,cB,dB)
link_23.SetDistance(0)
link_23.SetName("Coincident25")
exported_items.append(link_23)

link_24 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.09007090026555,2.7581116684078,-1.1299994178955)
dA = chrono.ChVectorD(-0.0416558036603413,-2.85068089004698e-15,-0.99913202031634)
cB = chrono.ChVectorD(-3.09007090026555,2.7581116684078,-1.1299994178955)
dB = chrono.ChVectorD(0.0416558036603413,2.85608731879049e-15,0.99913202031634)
link_24.SetFlipped(True)
link_24.Initialize(body_26,body_33,False,cA,cB,dA,dB)
link_24.SetName("Coincident25")
exported_items.append(link_24)


# Mate constraint: Concentric2 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_28 , SW name: M-410iB-300 -8/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_30 , SW name: M-410iB-300 -8/M-410iB-300-09-1 ,  SW ref.type:2 (2)

link_25 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.07501984257415,2.7581116684078,-0.768993450954597)
dA = chrono.ChVectorD(-0.0416558036603408,-3.56949234828483e-15,-0.99913202031634)
cB = chrono.ChVectorD(-3.0724497211392,2.75811166841889,-0.70734800436813)
dB = chrono.ChVectorD(-0.0416558036603411,-2.77414641929916e-15,-0.99913202031634)
link_25.Initialize(body_28,body_30,False,cA,cB,dA,dB)
link_25.SetName("Concentric2")
exported_items.append(link_25)

link_26 = chrono.ChLinkMateGeneric()
link_26.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.07501984257415,2.7581116684078,-0.768993450954597)
cB = chrono.ChVectorD(-3.0724497211392,2.75811166841889,-0.70734800436813)
dA = chrono.ChVectorD(-0.0416558036603408,-3.56949234828483e-15,-0.99913202031634)
dB = chrono.ChVectorD(-0.0416558036603411,-2.77414641929916e-15,-0.99913202031634)
link_26.Initialize(body_28,body_30,False,cA,cB,dA,dB)
link_26.SetName("Concentric2")
exported_items.append(link_26)


# Mate constraint: Concentric3 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_30 , SW name: M-410iB-300 -8/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_34 , SW name: M-410iB-300 -8/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_27 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.57213597411099,3.03011496694477,-0.734204323475019)
dA = chrono.ChVectorD(-0.0416558036603411,-2.77414641929916e-15,-0.99913202031634)
cB = chrono.ChVectorD(-2.57036485110329,3.03011496694473,-0.691723191114709)
dB = chrono.ChVectorD(-0.0416558036603407,-2.96522855540048e-15,-0.99913202031634)
link_27.Initialize(body_30,body_34,False,cA,cB,dA,dB)
link_27.SetName("Concentric3")
exported_items.append(link_27)

link_28 = chrono.ChLinkMateGeneric()
link_28.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-2.57213597411099,3.03011496694477,-0.734204323475019)
cB = chrono.ChVectorD(-2.57036485110329,3.03011496694473,-0.691723191114709)
dA = chrono.ChVectorD(-0.0416558036603411,-2.77414641929916e-15,-0.99913202031634)
dB = chrono.ChVectorD(-0.0416558036603407,-2.96522855540048e-15,-0.99913202031634)
link_28.Initialize(body_30,body_34,False,cA,cB,dA,dB)
link_28.SetName("Concentric3")
exported_items.append(link_28)


# Mate constraint: Concentric4 [MateConcentric] type:1 align:1 flip:False
#   Entity 0: C::E name: body_30 , SW name: M-410iB-300 -8/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_31 , SW name: M-410iB-300 -8/M-410iB-300-11-1 ,  SW ref.type:2 (2)

link_29 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.57226711325161,3.02810836636703,-0.692506864561186)
dA = chrono.ChVectorD(-0.0416558036603411,-2.77414641929916e-15,-0.99913202031634)
cB = chrono.ChVectorD(-3.57645077069101,3.02810836635593,-0.792853652769045)
dB = chrono.ChVectorD(0.0416558036603414,3.22399503807163e-15,0.99913202031634)
link_29.SetFlipped(True)
link_29.Initialize(body_30,body_31,False,cA,cB,dA,dB)
link_29.SetName("Concentric4")
exported_items.append(link_29)

link_30 = chrono.ChLinkMateGeneric()
link_30.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.57226711325161,3.02810836636703,-0.692506864561186)
cB = chrono.ChVectorD(-3.57645077069101,3.02810836635593,-0.792853652769045)
dA = chrono.ChVectorD(-0.0416558036603411,-2.77414641929916e-15,-0.99913202031634)
dB = chrono.ChVectorD(0.0416558036603414,3.22399503807163e-15,0.99913202031634)
link_30.Initialize(body_30,body_31,False,cA,cB,dA,dB)
link_30.SetName("Concentric4")
exported_items.append(link_30)


# Mate constraint: Concentric6 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_26 , SW name: M-410iB-300 -8/M-410iB-300-03-1 ,  SW ref.type:1 (1)
#   Entity 1: C::E name: body_33 , SW name: M-410iB-300 -8/M-410iB-300-05-1 ,  SW ref.type:2 (2)

link_31 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.09007090026555,2.7581116684078,-1.1299994178955)
dA = chrono.ChVectorD(-0.0416558036603413,-2.85068089004698e-15,-0.99913202031634)
cB = chrono.ChVectorD(-3.09007090026555,2.7581116684078,-1.1299994178955)
dB = chrono.ChVectorD(-0.0416558036603413,-2.85608731879049e-15,-0.99913202031634)
link_31.Initialize(body_26,body_33,False,cA,cB,dA,dB)
link_31.SetName("Concentric6")
exported_items.append(link_31)

link_32 = chrono.ChLinkMateGeneric()
link_32.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.09007090026555,2.7581116684078,-1.1299994178955)
cB = chrono.ChVectorD(-3.09007090026555,2.7581116684078,-1.1299994178955)
dA = chrono.ChVectorD(-0.0416558036603413,-2.85068089004698e-15,-0.99913202031634)
dB = chrono.ChVectorD(-0.0416558036603413,-2.85608731879049e-15,-0.99913202031634)
link_32.Initialize(body_26,body_33,False,cA,cB,dA,dB)
link_32.SetName("Concentric6")
exported_items.append(link_32)


# Mate constraint: Concentric7 [MateConcentric] type:1 align:1 flip:False
#   Entity 0: C::E name: body_27 , SW name: M-410iB-300 -8/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_37 , SW name: M-410iB-300 -8/M-410iB-300-04-1 ,  SW ref.type:2 (2)

link_33 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.89874798586263,2.78049691677857,-1.2582157628575)
dA = chrono.ChVectorD(0.041655803660341,2.95268223151123e-15,0.99913202031634)
cB = chrono.ChVectorD(-1.89780874986299,2.78049691677857,-1.2356877912568)
dB = chrono.ChVectorD(-0.0416558036603407,-3.14101410620626e-15,-0.99913202031634)
link_33.SetFlipped(True)
link_33.Initialize(body_27,body_37,False,cA,cB,dA,dB)
link_33.SetName("Concentric7")
exported_items.append(link_33)

link_34 = chrono.ChLinkMateGeneric()
link_34.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.89874798586263,2.78049691677857,-1.2582157628575)
cB = chrono.ChVectorD(-1.89780874986299,2.78049691677857,-1.2356877912568)
dA = chrono.ChVectorD(0.041655803660341,2.95268223151123e-15,0.99913202031634)
dB = chrono.ChVectorD(-0.0416558036603407,-3.14101410620626e-15,-0.99913202031634)
link_34.Initialize(body_27,body_37,False,cA,cB,dA,dB)
link_34.SetName("Concentric7")
exported_items.append(link_34)


# Mate constraint: Concentric8 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_31 , SW name: M-410iB-300 -8/M-410iB-300-11-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_32 , SW name: M-410iB-300 -8/M-410iB-300-12-1 ,  SW ref.type:2 (2)

link_35 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-4.32219380397017,1.96373031031278,-0.761762140592794)
dA = chrono.ChVectorD(0.0416558036603414,3.22399503807163e-15,0.99913202031634)
cB = chrono.ChVectorD(-4.3247573854455,1.96373031031285,-0.823250723542728)
dB = chrono.ChVectorD(0.0416558036603417,2.99405003119286e-15,0.99913202031634)
link_35.Initialize(body_31,body_32,False,cA,cB,dA,dB)
link_35.SetName("Concentric8")
exported_items.append(link_35)

link_36 = chrono.ChLinkMateGeneric()
link_36.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-4.32219380397017,1.96373031031278,-0.761762140592794)
cB = chrono.ChVectorD(-4.3247573854455,1.96373031031285,-0.823250723542728)
dA = chrono.ChVectorD(0.0416558036603414,3.22399503807163e-15,0.99913202031634)
dB = chrono.ChVectorD(0.0416558036603417,2.99405003119286e-15,0.99913202031634)
link_36.Initialize(body_31,body_32,False,cA,cB,dA,dB)
link_36.SetName("Concentric8")
exported_items.append(link_36)


# Mate constraint: Concentric9 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_26 , SW name: M-410iB-300 -8/M-410iB-300-03-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_36 , SW name: M-410iB-300 -8/M-410iB-300-07-1 ,  SW ref.type:2 (2)

link_37 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.89521085613829,2.51550127212935,-1.17345999619426)
dA = chrono.ChVectorD(0.0416558036603413,2.85068089004698e-15,0.99913202031634)
cB = chrono.ChVectorD(-1.89294603454568,2.51550127212935,-1.11913729504236)
dB = chrono.ChVectorD(0.041655803660342,2.48436689812231e-15,0.99913202031634)
link_37.Initialize(body_26,body_36,False,cA,cB,dA,dB)
link_37.SetName("Concentric9")
exported_items.append(link_37)

link_38 = chrono.ChLinkMateGeneric()
link_38.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.89521085613829,2.51550127212935,-1.17345999619426)
cB = chrono.ChVectorD(-1.89294603454568,2.51550127212935,-1.11913729504236)
dA = chrono.ChVectorD(0.0416558036603413,2.85068089004698e-15,0.99913202031634)
dB = chrono.ChVectorD(0.041655803660342,2.48436689812231e-15,0.99913202031634)
link_38.Initialize(body_26,body_36,False,cA,cB,dA,dB)
link_38.SetName("Concentric9")
exported_items.append(link_38)


# Mate constraint: Coincident33 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_37 , SW name: M-410iB-300 -8/M-410iB-300-04-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_33 , SW name: M-410iB-300 -8/M-410iB-300-05-1 ,  SW ref.type:4 (4)

link_39 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.90153311195666,2.78049691677857,-1.32501818692924)
cB = chrono.ChVectorD(-2.22803156401319,2.77437872020599,-1.31140581625378)
dA = chrono.ChVectorD(0.018703029145819,-0.999824778981261,-0.000779766531456221)
dB = chrono.ChVectorD(0.018703029145819,-0.999824778981261,-0.000779766531456516)
link_39.Initialize(body_37,body_33,False,cA,cB,dB)
link_39.SetDistance(0)
link_39.SetName("Coincident33")
exported_items.append(link_39)

link_40 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.90153311195666,2.78049691677857,-1.32501818692924)
dA = chrono.ChVectorD(0.018703029145819,-0.999824778981261,-0.000779766531456221)
cB = chrono.ChVectorD(-2.22803156401319,2.77437872020599,-1.31140581625378)
dB = chrono.ChVectorD(0.018703029145819,-0.999824778981261,-0.000779766531456516)
link_40.Initialize(body_37,body_33,False,cA,cB,dA,dB)
link_40.SetName("Coincident33")
exported_items.append(link_40)


# Mate constraint: Coincident34 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_37 , SW name: M-410iB-300 -8/M-410iB-300-04-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_33 , SW name: M-410iB-300 -8/M-410iB-300-05-1 ,  SW ref.type:4 (4)

link_41 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.90153311195666,2.78049691677857,-1.32501818692924)
cB = chrono.ChVectorD(-2.22803156401319,2.77437872020599,-1.31140581625378)
dA = chrono.ChVectorD(0.0416558036603407,3.14101410620626e-15,0.99913202031634)
dB = chrono.ChVectorD(-0.0416558036603413,-2.85608731879049e-15,-0.99913202031634)
link_41.Initialize(body_37,body_33,False,cA,cB,dB)
link_41.SetDistance(0)
link_41.SetName("Coincident34")
exported_items.append(link_41)

link_42 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.90153311195666,2.78049691677857,-1.32501818692924)
dA = chrono.ChVectorD(0.0416558036603407,3.14101410620626e-15,0.99913202031634)
cB = chrono.ChVectorD(-2.22803156401319,2.77437872020599,-1.31140581625378)
dB = chrono.ChVectorD(-0.0416558036603413,-2.85608731879049e-15,-0.99913202031634)
link_42.SetFlipped(True)
link_42.Initialize(body_37,body_33,False,cA,cB,dA,dB)
link_42.SetName("Coincident34")
exported_items.append(link_42)


# Mate constraint: Concentric10 [MateConcentric] type:1 align:1 flip:False
#   Entity 0: C::E name: body_27 , SW name: M-410iB-300 -8/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_34 , SW name: M-410iB-300 -8/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_43 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.37755705516747,2.78749692402101,-0.784366971385829)
dA = chrono.ChVectorD(-0.041655803660341,-2.95268223151123e-15,-0.99913202031634)
cB = chrono.ChVectorD(-1.37755705516746,2.78749692402101,-0.784366971385828)
dB = chrono.ChVectorD(0.0416558036603407,2.96522855540048e-15,0.99913202031634)
link_43.SetFlipped(True)
link_43.Initialize(body_27,body_34,False,cA,cB,dA,dB)
link_43.SetName("Concentric10")
exported_items.append(link_43)

link_44 = chrono.ChLinkMateGeneric()
link_44.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.37755705516747,2.78749692402101,-0.784366971385829)
cB = chrono.ChVectorD(-1.37755705516746,2.78749692402101,-0.784366971385828)
dA = chrono.ChVectorD(-0.041655803660341,-2.95268223151123e-15,-0.99913202031634)
dB = chrono.ChVectorD(0.0416558036603407,2.96522855540048e-15,0.99913202031634)
link_44.Initialize(body_27,body_34,False,cA,cB,dA,dB)
link_44.SetName("Concentric10")
exported_items.append(link_44)


# Mate constraint: Coincident35 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_31 , SW name: M-410iB-300 -8/M-410iB-300-11-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_32 , SW name: M-410iB-300 -8/M-410iB-300-12-1 ,  SW ref.type:2 (2)

link_45 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-4.3227016715284,1.96373031031278,-0.773943558184491)
cB = chrono.ChVectorD(-4.18403337717326,2.16235200646254,-0.779724915534445)
dA = chrono.ChVectorD(-0.0416558036603414,-3.22399503807163e-15,-0.99913202031634)
dB = chrono.ChVectorD(0.0416558040073285,5.28992084709618e-15,0.999132020301874)
link_45.Initialize(body_31,body_32,False,cA,cB,dB)
link_45.SetDistance(0)
link_45.SetName("Coincident35")
exported_items.append(link_45)

link_46 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-4.3227016715284,1.96373031031278,-0.773943558184491)
dA = chrono.ChVectorD(-0.0416558036603414,-3.22399503807163e-15,-0.99913202031634)
cB = chrono.ChVectorD(-4.18403337717326,2.16235200646254,-0.779724915534445)
dB = chrono.ChVectorD(0.0416558040073285,5.28992084709618e-15,0.999132020301874)
link_46.SetFlipped(True)
link_46.Initialize(body_31,body_32,False,cA,cB,dA,dB)
link_46.SetName("Coincident35")
exported_items.append(link_46)


# Mate constraint: Coincident36 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_28 , SW name: M-410iB-300 -8/M-410iB-300-06-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_29 , SW name: M-410iB-300 -8/M-410iB-300-08-1 ,  SW ref.type:4 (4)

link_47 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.08137235263235,2.7581116684078,-0.921361084052839)
cB = chrono.ChVectorD(-1.56645472584531,3.00997129509906,-0.984521016814328)
dA = chrono.ChVectorD(-0.0416558036603408,-3.56949234828483e-15,-0.99913202031634)
dB = chrono.ChVectorD(-0.0416558036603418,-2.76863012562884e-15,-0.99913202031634)
link_47.Initialize(body_28,body_29,False,cA,cB,dB)
link_47.SetDistance(0)
link_47.SetName("Coincident36")
exported_items.append(link_47)

link_48 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.08137235263235,2.7581116684078,-0.921361084052839)
dA = chrono.ChVectorD(-0.0416558036603408,-3.56949234828483e-15,-0.99913202031634)
cB = chrono.ChVectorD(-1.56645472584531,3.00997129509906,-0.984521016814328)
dB = chrono.ChVectorD(-0.0416558036603418,-2.76863012562884e-15,-0.99913202031634)
link_48.Initialize(body_28,body_29,False,cA,cB,dA,dB)
link_48.SetName("Coincident36")
exported_items.append(link_48)


# Mate constraint: Coincident37 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_30 , SW name: M-410iB-300 -8/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_31 , SW name: M-410iB-300 -8/M-410iB-300-11-1 ,  SW ref.type:2 (2)

link_49 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.07397852203425,3.21365418351158,-0.761687486504726)
cB = chrono.ChVectorD(-3.57428175299442,3.02810836635593,-0.740828848471173)
dA = chrono.ChVectorD(-0.0416558036603411,-2.77414641929916e-15,-0.99913202031634)
dB = chrono.ChVectorD(0.0416558036603414,3.22399503807163e-15,0.99913202031634)
link_49.Initialize(body_30,body_31,False,cA,cB,dB)
link_49.SetDistance(0)
link_49.SetName("Coincident37")
exported_items.append(link_49)

link_50 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.07397852203425,3.21365418351158,-0.761687486504726)
dA = chrono.ChVectorD(-0.0416558036603411,-2.77414641929916e-15,-0.99913202031634)
cB = chrono.ChVectorD(-3.57428175299442,3.02810836635593,-0.740828848471173)
dB = chrono.ChVectorD(0.0416558036603414,3.22399503807163e-15,0.99913202031634)
link_50.SetFlipped(True)
link_50.Initialize(body_30,body_31,False,cA,cB,dA,dB)
link_50.SetName("Coincident37")
exported_items.append(link_50)


# Mate constraint: Coincident38 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_26 , SW name: M-410iB-300 -8/M-410iB-300-03-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_28 , SW name: M-410iB-300 -8/M-410iB-300-06-1 ,  SW ref.type:4 (4)

link_51 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.88802649696815,2.51550127212935,-1.00114011129009)
cB = chrono.ChVectorD(-3.08262202674216,2.7581116684078,-0.951335044662328)
dA = chrono.ChVectorD(-0.0416558036603413,-2.85068089004698e-15,-0.99913202031634)
dB = chrono.ChVectorD(0.0416558036603408,3.56949234828483e-15,0.99913202031634)
link_51.Initialize(body_26,body_28,False,cA,cB,dB)
link_51.SetDistance(0)
link_51.SetName("Coincident38")
exported_items.append(link_51)

link_52 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.88802649696815,2.51550127212935,-1.00114011129009)
dA = chrono.ChVectorD(-0.0416558036603413,-2.85068089004698e-15,-0.99913202031634)
cB = chrono.ChVectorD(-3.08262202674216,2.7581116684078,-0.951335044662328)
dB = chrono.ChVectorD(0.0416558036603408,3.56949234828483e-15,0.99913202031634)
link_52.SetFlipped(True)
link_52.Initialize(body_26,body_28,False,cA,cB,dA,dB)
link_52.SetName("Coincident38")
exported_items.append(link_52)


# Mate constraint: Coincident6 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_43 , SW name: M-410iB-300 -9/M-410iB-300-03-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_46 , SW name: M-410iB-300 -9/M-410iB-300-06-1 ,  SW ref.type:5 (5)

link_1 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.08302836213116,2.75811166839776,0.569733920980173)
dA = chrono.ChVectorD(0.0184050216223813,3.38131173957543e-15,0.999830613243603)
cB = chrono.ChVectorD(-3.08335810235742,2.75811166839776,0.551821180675222)
dB = chrono.ChVectorD(-0.0184050216223813,-3.02106951993987e-15,-0.999830613243603)
link_1.SetFlipped(True)
link_1.Initialize(body_43,body_46,False,cA,cB,dA,dB)
link_1.SetName("Coincident6")
exported_items.append(link_1)

link_2 = chrono.ChLinkMateGeneric()
link_2.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.08302836213116,2.75811166839776,0.569733920980173)
cB = chrono.ChVectorD(-3.08335810235742,2.75811166839776,0.551821180675222)
dA = chrono.ChVectorD(0.0184050216223813,3.38131173957543e-15,0.999830613243603)
dB = chrono.ChVectorD(-0.0184050216223813,-3.02106951993987e-15,-0.999830613243603)
link_2.Initialize(body_43,body_46,False,cA,cB,dA,dB)
link_2.SetName("Coincident6")
exported_items.append(link_2)


# Mate constraint: Coincident7 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_44 , SW name: M-410iB-300 -9/M-410iB-300-02-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_48 , SW name: M-410iB-300 -9/M-410iB-300-07-1 ,  SW ref.type:5 (5)

link_3 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.89422659812692,2.51550127212935,0.187614376851418)
dA = chrono.ChVectorD(0.0184050216289121,3.55911871829818e-15,0.999830613243483)
cB = chrono.ChVectorD(-1.88855367945124,2.51550127212935,0.495788845399941)
dB = chrono.ChVectorD(-0.0184050216223812,-3.38131173957544e-15,-0.999830613243603)
link_3.SetFlipped(True)
link_3.Initialize(body_44,body_48,False,cA,cB,dA,dB)
link_3.SetName("Coincident7")
exported_items.append(link_3)

link_4 = chrono.ChLinkMateGeneric()
link_4.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.89422659812692,2.51550127212935,0.187614376851418)
cB = chrono.ChVectorD(-1.88855367945124,2.51550127212935,0.495788845399941)
dA = chrono.ChVectorD(0.0184050216289121,3.55911871829818e-15,0.999830613243483)
dB = chrono.ChVectorD(-0.0184050216223812,-3.38131173957544e-15,-0.999830613243603)
link_4.Initialize(body_44,body_48,False,cA,cB,dA,dB)
link_4.SetName("Coincident7")
exported_items.append(link_4)


# Mate constraint: Coincident8 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_46 , SW name: M-410iB-300 -9/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_48 , SW name: M-410iB-300 -9/M-410iB-300-07-1 ,  SW ref.type:2 (2)

link_5 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-2.6149048109634,3.10882622101019,0.433179191336291)
cB = chrono.ChVectorD(-1.57325175888322,3.01244418440915,0.414004296416481)
dA = chrono.ChVectorD(0.0184050216223813,3.02106951993987e-15,0.999830613243603)
dB = chrono.ChVectorD(0.0184050216223812,3.38131173957544e-15,0.999830613243603)
link_5.Initialize(body_46,body_48,False,cA,cB,dB)
link_5.SetDistance(0)
link_5.SetName("Coincident8")
exported_items.append(link_5)

link_6 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.6149048109634,3.10882622101019,0.433179191336291)
dA = chrono.ChVectorD(0.0184050216223813,3.02106951993987e-15,0.999830613243603)
cB = chrono.ChVectorD(-1.57325175888322,3.01244418440915,0.414004296416481)
dB = chrono.ChVectorD(0.0184050216223812,3.38131173957544e-15,0.999830613243603)
link_6.Initialize(body_46,body_48,False,cA,cB,dA,dB)
link_6.SetName("Coincident8")
exported_items.append(link_6)


# Mate constraint: Coincident9 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_46 , SW name: M-410iB-300 -9/M-410iB-300-06-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_49 , SW name: M-410iB-300 -9/M-410iB-300-08-1 ,  SW ref.type:5 (5)

link_7 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.77196808469274,3.25747744022175,0.436070434023582)
dA = chrono.ChVectorD(0.0184050216223813,3.02106951993987e-15,0.999830613243603)
cB = chrono.ChVectorD(-2.77141913651783,3.25747744022175,0.465891381894186)
dB = chrono.ChVectorD(0.0184050216223813,3.1411502598179e-15,0.999830613243603)
link_7.Initialize(body_46,body_49,False,cA,cB,dA,dB)
link_7.SetName("Coincident9")
exported_items.append(link_7)

link_8 = chrono.ChLinkMateGeneric()
link_8.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-2.77196808469274,3.25747744022175,0.436070434023582)
cB = chrono.ChVectorD(-2.77141913651783,3.25747744022175,0.465891381894186)
dA = chrono.ChVectorD(0.0184050216223813,3.02106951993987e-15,0.999830613243603)
dB = chrono.ChVectorD(0.0184050216223813,3.1411502598179e-15,0.999830613243603)
link_8.Initialize(body_46,body_49,False,cA,cB,dA,dB)
link_8.SetName("Coincident9")
exported_items.append(link_8)


# Mate constraint: Coincident11 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_44 , SW name: M-410iB-300 -9/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_40 , SW name: M-410iB-300 -9/M-410iB-300-09-1 ,  SW ref.type:2 (2)

link_9 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.53208464393623,2.72491052060183,0.671139170083317)
cB = chrono.ChVectorD(-3.07990098211843,3.2136541835116,0.699631589503653)
dA = chrono.ChVectorD(0.0184050216289121,3.55911871829818e-15,0.999830613243483)
dB = chrono.ChVectorD(0.018405021628912,3.56712868232535e-15,0.999830613243483)
link_9.Initialize(body_44,body_40,False,cA,cB,dB)
link_9.SetDistance(0)
link_9.SetName("Coincident11")
exported_items.append(link_9)

link_10 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.53208464393623,2.72491052060183,0.671139170083317)
dA = chrono.ChVectorD(0.0184050216289121,3.55911871829818e-15,0.999830613243483)
cB = chrono.ChVectorD(-3.07990098211843,3.2136541835116,0.699631589503653)
dB = chrono.ChVectorD(0.018405021628912,3.56712868232535e-15,0.999830613243483)
link_10.Initialize(body_44,body_40,False,cA,cB,dA,dB)
link_10.SetName("Coincident11")
exported_items.append(link_10)


# Mate constraint: Coincident22 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_40 , SW name: M-410iB-300 -9/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_42 , SW name: M-410iB-300 -9/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_11 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.07990098211843,3.2136541835116,0.699631589503653)
cB = chrono.ChVectorD(-2.57972359435311,3.03011496694473,0.690424254262888)
dA = chrono.ChVectorD(0.018405021628912,3.56712868232535e-15,0.999830613243483)
dB = chrono.ChVectorD(-0.0184050216289114,-3.94783272266648e-15,-0.999830613243483)
link_11.Initialize(body_40,body_42,False,cA,cB,dB)
link_11.SetDistance(0)
link_11.SetName("Coincident22")
exported_items.append(link_11)

link_12 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.07990098211843,3.2136541835116,0.699631589503653)
dA = chrono.ChVectorD(0.018405021628912,3.56712868232535e-15,0.999830613243483)
cB = chrono.ChVectorD(-2.57972359435311,3.03011496694473,0.690424254262888)
dB = chrono.ChVectorD(-0.0184050216289114,-3.94783272266648e-15,-0.999830613243483)
link_12.SetFlipped(True)
link_12.Initialize(body_40,body_42,False,cA,cB,dA,dB)
link_12.SetName("Coincident22")
exported_items.append(link_12)


# Mate constraint: Coincident15 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_46 , SW name: M-410iB-300 -9/M-410iB-300-06-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_38 , SW name: M-410iB-300 -9/M-410iB-300-12-1 ,  SW ref.type:5 (5)

link_13 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.8217363702807,1.68799184812329,0.545409962623057)
dA = chrono.ChVectorD(-0.0184050216223813,-3.02106951993987e-15,-0.999830613243603)
cB = chrono.ChVectorD(-3.82150481669554,1.68799184813436,0.557988831565502)
dB = chrono.ChVectorD(0.0184050219696108,5.19696320789579e-15,0.999830613237211)
link_13.SetFlipped(True)
link_13.Initialize(body_46,body_38,False,cA,cB,dA,dB)
link_13.SetName("Coincident15")
exported_items.append(link_13)

link_14 = chrono.ChLinkMateGeneric()
link_14.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.8217363702807,1.68799184812329,0.545409962623057)
cB = chrono.ChVectorD(-3.82150481669554,1.68799184813436,0.557988831565502)
dA = chrono.ChVectorD(-0.0184050216223813,-3.02106951993987e-15,-0.999830613243603)
dB = chrono.ChVectorD(0.0184050219696108,5.19696320789579e-15,0.999830613237211)
link_14.Initialize(body_46,body_38,False,cA,cB,dA,dB)
link_14.SetName("Coincident15")
exported_items.append(link_14)


# Mate constraint: Coincident17 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_48 , SW name: M-410iB-300 -9/M-410iB-300-07-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_49 , SW name: M-410iB-300 -9/M-410iB-300-08-1 ,  SW ref.type:5 (5)

link_15 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.57162083470219,3.01244418440915,0.502602286547837)
dA = chrono.ChVectorD(-0.0184050216223812,-3.38131173957544e-15,-0.999830613243603)
cB = chrono.ChVectorD(-1.57270281070831,3.01244418440915,0.443825244287085)
dB = chrono.ChVectorD(0.0184050216223813,3.1411502598179e-15,0.999830613243603)
link_15.SetFlipped(True)
link_15.Initialize(body_48,body_49,False,cA,cB,dA,dB)
link_15.SetName("Coincident17")
exported_items.append(link_15)

link_16 = chrono.ChLinkMateGeneric()
link_16.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.57162083470219,3.01244418440915,0.502602286547837)
cB = chrono.ChVectorD(-1.57270281070831,3.01244418440915,0.443825244287085)
dA = chrono.ChVectorD(-0.0184050216223812,-3.38131173957544e-15,-0.999830613243603)
dB = chrono.ChVectorD(0.0184050216223813,3.1411502598179e-15,0.999830613243603)
link_16.Initialize(body_48,body_49,False,cA,cB,dA,dB)
link_16.SetName("Coincident17")
exported_items.append(link_16)


# Mate constraint: Coincident18 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_44 , SW name: M-410iB-300 -9/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_41 , SW name: M-410iB-300 -9/ArmBase-1 ,  SW ref.type:2 (2)

link_17 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.50067035795504,2.04602671615663,0.377403113437383)
cB = chrono.ChVectorD(-1.25867129241134,2.04602671615662,0.377403113437383)
dA = chrono.ChVectorD(1.94930294081343e-16,-1,3.55613338391913e-15)
dB = chrono.ChVectorD(-6.21947280249299e-17,1,-3.55871276754624e-15)
link_17.Initialize(body_44,body_41,False,cA,cB,dB)
link_17.SetDistance(0)
link_17.SetName("Coincident18")
exported_items.append(link_17)

link_18 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.50067035795504,2.04602671615663,0.377403113437383)
dA = chrono.ChVectorD(1.94930294081343e-16,-1,3.55613338391913e-15)
cB = chrono.ChVectorD(-1.25867129241134,2.04602671615662,0.377403113437383)
dB = chrono.ChVectorD(-6.21947280249299e-17,1,-3.55871276754624e-15)
link_18.SetFlipped(True)
link_18.Initialize(body_44,body_41,False,cA,cB,dA,dB)
link_18.SetName("Coincident18")
exported_items.append(link_18)


# Mate constraint: Concentric1 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_44 , SW name: M-410iB-300 -9/M-410iB-300-02-1 ,  SW ref.type:1 (1)
#   Entity 1: C::E name: body_41 , SW name: M-410iB-300 -9/ArmBase-1 ,  SW ref.type:1 (1)

link_19 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.50067035795504,2.04755071615663,0.377403113437383)
dA = chrono.ChVectorD(-1.94930294081343e-16,1,-3.55613338391913e-15)
cB = chrono.ChVectorD(-1.50067035795504,2.04602671615662,0.377403113437383)
dB = chrono.ChVectorD(-6.21947280249299e-17,1,-3.55871276754624e-15)
link_19.Initialize(body_44,body_41,False,cA,cB,dA,dB)
link_19.SetName("Concentric1")
exported_items.append(link_19)

link_20 = chrono.ChLinkMateGeneric()
link_20.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.50067035795504,2.04755071615663,0.377403113437383)
cB = chrono.ChVectorD(-1.50067035795504,2.04602671615662,0.377403113437383)
dA = chrono.ChVectorD(-1.94930294081343e-16,1,-3.55613338391913e-15)
dB = chrono.ChVectorD(-6.21947280249299e-17,1,-3.55871276754624e-15)
link_20.Initialize(body_44,body_41,False,cA,cB,dA,dB)
link_20.SetName("Concentric1")
exported_items.append(link_20)


# Mate constraint: Coincident21 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_46 , SW name: M-410iB-300 -9/M-410iB-300-06-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_38 , SW name: M-410iB-300 -9/M-410iB-300-12-1 ,  SW ref.type:4 (4)

link_21 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.08501455433988,2.75811166839776,0.461836423503213)
cB = chrono.ChVectorD(-4.07798047817131,1.52899016742593,0.480115080901988)
dA = chrono.ChVectorD(-0.0184050216223813,-3.02106951993987e-15,-0.999830613243603)
dB = chrono.ChVectorD(0.0184050217959961,4.04897599397846e-15,0.999830613240407)
link_21.Initialize(body_46,body_38,False,cA,cB,dB)
link_21.SetDistance(0)
link_21.SetName("Coincident21")
exported_items.append(link_21)

link_22 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.08501455433988,2.75811166839776,0.461836423503213)
dA = chrono.ChVectorD(-0.0184050216223813,-3.02106951993987e-15,-0.999830613243603)
cB = chrono.ChVectorD(-4.07798047817131,1.52899016742593,0.480115080901988)
dB = chrono.ChVectorD(0.0184050217959961,4.04897599397846e-15,0.999830613240407)
link_22.SetFlipped(True)
link_22.Initialize(body_46,body_38,False,cA,cB,dA,dB)
link_22.SetName("Coincident21")
exported_items.append(link_22)


# Mate constraint: Coincident25 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_43 , SW name: M-410iB-300 -9/M-410iB-300-03-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_45 , SW name: M-410iB-300 -9/M-410iB-300-05-1 ,  SW ref.type:2 (2)

link_23 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.08830573263186,2.75811166839775,0.283047130152786)
cB = chrono.ChVectorD(-3.08830573263186,2.75811166839775,0.283047130152786)
dA = chrono.ChVectorD(-0.0184050216223813,-3.38131173957543e-15,-0.999830613243603)
dB = chrono.ChVectorD(0.0184050216223813,3.26123099969697e-15,0.999830613243603)
link_23.Initialize(body_43,body_45,False,cA,cB,dB)
link_23.SetDistance(0)
link_23.SetName("Coincident25")
exported_items.append(link_23)

link_24 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.08830573263186,2.75811166839775,0.283047130152786)
dA = chrono.ChVectorD(-0.0184050216223813,-3.38131173957543e-15,-0.999830613243603)
cB = chrono.ChVectorD(-3.08830573263186,2.75811166839775,0.283047130152786)
dB = chrono.ChVectorD(0.0184050216223813,3.26123099969697e-15,0.999830613243603)
link_24.SetFlipped(True)
link_24.Initialize(body_43,body_45,False,cA,cB,dA,dB)
link_24.SetName("Coincident25")
exported_items.append(link_24)


# Mate constraint: Concentric2 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_46 , SW name: M-410iB-300 -9/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_40 , SW name: M-410iB-300 -9/M-410iB-300-09-1 ,  SW ref.type:2 (2)

link_25 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.08165563785735,2.75811166839776,0.644305512400255)
dA = chrono.ChVectorD(-0.0184050216223813,-3.02106951993987e-15,-0.999830613243603)
cB = chrono.ChVectorD(-3.08052006642069,2.7581116684189,0.70599406148212)
dB = chrono.ChVectorD(-0.018405021628912,-3.56712868232535e-15,-0.999830613243483)
link_25.Initialize(body_46,body_40,False,cA,cB,dA,dB)
link_25.SetName("Concentric2")
exported_items.append(link_25)

link_26 = chrono.ChLinkMateGeneric()
link_26.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.08165563785735,2.75811166839776,0.644305512400255)
cB = chrono.ChVectorD(-3.08052006642069,2.7581116684189,0.70599406148212)
dA = chrono.ChVectorD(-0.0184050216223813,-3.02106951993987e-15,-0.999830613243603)
dB = chrono.ChVectorD(-0.018405021628912,-3.56712868232535e-15,-0.999830613243483)
link_26.Initialize(body_46,body_40,False,cA,cB,dA,dB)
link_26.SetName("Concentric2")
exported_items.append(link_26)


# Mate constraint: Concentric3 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_40 , SW name: M-410iB-300 -9/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_42 , SW name: M-410iB-300 -9/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_27 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.57971700603921,3.03011496694478,0.690782156475974)
dA = chrono.ChVectorD(-0.018405021628912,-3.56712868232535e-15,-0.999830613243483)
cB = chrono.ChVectorD(-2.57893446064574,3.03011496694473,0.733292991636315)
dB = chrono.ChVectorD(-0.0184050216289114,-3.94783272266648e-15,-0.999830613243483)
link_27.Initialize(body_40,body_42,False,cA,cB,dA,dB)
link_27.SetName("Concentric3")
exported_items.append(link_27)

link_28 = chrono.ChLinkMateGeneric()
link_28.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-2.57971700603921,3.03011496694478,0.690782156475974)
cB = chrono.ChVectorD(-2.57893446064574,3.03011496694473,0.733292991636315)
dA = chrono.ChVectorD(-0.018405021628912,-3.56712868232535e-15,-0.999830613243483)
dB = chrono.ChVectorD(-0.0184050216289114,-3.94783272266648e-15,-0.999830613243483)
link_28.Initialize(body_40,body_42,False,cA,cB,dA,dB)
link_28.SetName("Concentric3")
exported_items.append(link_28)


# Mate constraint: Concentric4 [MateConcentric] type:1 align:1 flip:False
#   Entity 0: C::E name: body_40 , SW name: M-410iB-300 -9/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_39 , SW name: M-410iB-300 -9/M-410iB-300-11-1 ,  SW ref.type:2 (2)

link_29 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.58054743669067,3.02810836636704,0.709205582883431)
dA = chrono.ChVectorD(-0.018405021628912,-3.56712868232535e-15,-0.999830613243483)
cB = chrono.ChVectorD(-3.5823959259549,3.02810836634589,0.608788632205871)
dB = chrono.ChVectorD(0.0184050216223813,2.90098878006114e-15,0.999830613243603)
link_29.SetFlipped(True)
link_29.Initialize(body_40,body_39,False,cA,cB,dA,dB)
link_29.SetName("Concentric4")
exported_items.append(link_29)

link_30 = chrono.ChLinkMateGeneric()
link_30.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.58054743669067,3.02810836636704,0.709205582883431)
cB = chrono.ChVectorD(-3.5823959259549,3.02810836634589,0.608788632205871)
dA = chrono.ChVectorD(-0.018405021628912,-3.56712868232535e-15,-0.999830613243483)
dB = chrono.ChVectorD(0.0184050216223813,2.90098878006114e-15,0.999830613243603)
link_30.Initialize(body_40,body_39,False,cA,cB,dA,dB)
link_30.SetName("Concentric4")
exported_items.append(link_30)


# Mate constraint: Concentric6 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_43 , SW name: M-410iB-300 -9/M-410iB-300-03-1 ,  SW ref.type:1 (1)
#   Entity 1: C::E name: body_45 , SW name: M-410iB-300 -9/M-410iB-300-05-1 ,  SW ref.type:2 (2)

link_31 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.08830573263186,2.75811166839775,0.283047130152786)
dA = chrono.ChVectorD(-0.0184050216223813,-3.38131173957543e-15,-0.999830613243603)
cB = chrono.ChVectorD(-3.08830573263186,2.75811166839775,0.283047130152786)
dB = chrono.ChVectorD(-0.0184050216223813,-3.26123099969697e-15,-0.999830613243603)
link_31.Initialize(body_43,body_45,False,cA,cB,dA,dB)
link_31.SetName("Concentric6")
exported_items.append(link_31)

link_32 = chrono.ChLinkMateGeneric()
link_32.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.08830573263186,2.75811166839775,0.283047130152786)
cB = chrono.ChVectorD(-3.08830573263186,2.75811166839775,0.283047130152786)
dA = chrono.ChVectorD(-0.0184050216223813,-3.38131173957543e-15,-0.999830613243603)
dB = chrono.ChVectorD(-0.0184050216223813,-3.26123099969697e-15,-0.999830613243603)
link_32.Initialize(body_43,body_45,False,cA,cB,dA,dB)
link_32.SetName("Concentric6")
exported_items.append(link_32)


# Mate constraint: Concentric7 [MateConcentric] type:1 align:1 flip:False
#   Entity 0: C::E name: body_44 , SW name: M-410iB-300 -9/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_47 , SW name: M-410iB-300 -9/M-410iB-300-04-1 ,  SW ref.type:2 (2)

link_33 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.89432284895479,2.78049691677857,0.182575288404094)
dA = chrono.ChVectorD(0.0184050216289121,3.55911871829818e-15,0.999830613243483)
cB = chrono.ChVectorD(-1.89390786094794,2.78049691677857,0.205119011555882)
dB = chrono.ChVectorD(-0.0184050216223813,-3.02106951993959e-15,-0.999830613243603)
link_33.SetFlipped(True)
link_33.Initialize(body_44,body_47,False,cA,cB,dA,dB)
link_33.SetName("Concentric7")
exported_items.append(link_33)

link_34 = chrono.ChLinkMateGeneric()
link_34.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.89432284895479,2.78049691677857,0.182575288404094)
cB = chrono.ChVectorD(-1.89390786094794,2.78049691677857,0.205119011555882)
dA = chrono.ChVectorD(0.0184050216289121,3.55911871829818e-15,0.999830613243483)
dB = chrono.ChVectorD(-0.0184050216223813,-3.02106951993959e-15,-0.999830613243603)
link_34.Initialize(body_44,body_47,False,cA,cB,dA,dB)
link_34.SetName("Concentric7")
exported_items.append(link_34)


# Mate constraint: Concentric8 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_39 , SW name: M-410iB-300 -9/M-410iB-300-11-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_38 , SW name: M-410iB-300 -9/M-410iB-300-12-1 ,  SW ref.type:2 (2)

link_35 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-4.32040611135954,1.9579885584307,0.622374026811711)
dA = chrono.ChVectorD(0.0184050216223813,2.90098878006114e-15,0.999830613243603)
cB = chrono.ChVectorD(-4.32153879320309,1.9579885584307,0.56084245105574)
dB = chrono.ChVectorD(0.0184050216223813,2.90098878006114e-15,0.999830613243603)
link_35.Initialize(body_39,body_38,False,cA,cB,dA,dB)
link_35.SetName("Concentric8")
exported_items.append(link_35)

link_36 = chrono.ChLinkMateGeneric()
link_36.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-4.32040611135954,1.9579885584307,0.622374026811711)
cB = chrono.ChVectorD(-4.32153879320309,1.9579885584307,0.56084245105574)
dA = chrono.ChVectorD(0.0184050216223813,2.90098878006114e-15,0.999830613243603)
dB = chrono.ChVectorD(0.0184050216223813,2.90098878006114e-15,0.999830613243603)
link_36.Initialize(body_39,body_38,False,cA,cB,dA,dB)
link_36.SetName("Concentric8")
exported_items.append(link_36)


# Mate constraint: Concentric9 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_43 , SW name: M-410iB-300 -9/M-410iB-300-03-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_48 , SW name: M-410iB-300 -9/M-410iB-300-07-1 ,  SW ref.type:2 (2)

link_37 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.89275806999091,2.51550127212935,0.267390397528138)
dA = chrono.ChVectorD(0.0184050216223813,3.38131173957543e-15,0.999830613243603)
cB = chrono.ChVectorD(-1.89175739093254,2.51550127212935,0.321751081102819)
dB = chrono.ChVectorD(0.0184050216223812,3.38131173957544e-15,0.999830613243603)
link_37.Initialize(body_43,body_48,False,cA,cB,dA,dB)
link_37.SetName("Concentric9")
exported_items.append(link_37)

link_38 = chrono.ChLinkMateGeneric()
link_38.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.89275806999091,2.51550127212935,0.267390397528138)
cB = chrono.ChVectorD(-1.89175739093254,2.51550127212935,0.321751081102819)
dA = chrono.ChVectorD(0.0184050216223813,3.38131173957543e-15,0.999830613243603)
dB = chrono.ChVectorD(0.0184050216223812,3.38131173957544e-15,0.999830613243603)
link_38.Initialize(body_43,body_48,False,cA,cB,dA,dB)
link_38.SetName("Concentric9")
exported_items.append(link_38)


# Mate constraint: Coincident33 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_47 , SW name: M-410iB-300 -9/M-410iB-300-04-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_45 , SW name: M-410iB-300 -9/M-410iB-300-05-1 ,  SW ref.type:4 (4)

link_39 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.89555341712115,2.78049691677857,0.115726156086998)
cB = chrono.ChVectorD(-2.22228015683827,2.77437872020321,0.121740587561141)
dA = chrono.ChVectorD(0.0187161063087681,-0.999824778981104,-0.000344528699895605)
dB = chrono.ChVectorD(0.0187161063087681,-0.999824778981104,-0.000344528699895364)
link_39.Initialize(body_47,body_45,False,cA,cB,dB)
link_39.SetDistance(0)
link_39.SetName("Coincident33")
exported_items.append(link_39)

link_40 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.89555341712115,2.78049691677857,0.115726156086998)
dA = chrono.ChVectorD(0.0187161063087681,-0.999824778981104,-0.000344528699895605)
cB = chrono.ChVectorD(-2.22228015683827,2.77437872020321,0.121740587561141)
dB = chrono.ChVectorD(0.0187161063087681,-0.999824778981104,-0.000344528699895364)
link_40.Initialize(body_47,body_45,False,cA,cB,dA,dB)
link_40.SetName("Coincident33")
exported_items.append(link_40)


# Mate constraint: Coincident34 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_47 , SW name: M-410iB-300 -9/M-410iB-300-04-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_45 , SW name: M-410iB-300 -9/M-410iB-300-05-1 ,  SW ref.type:4 (4)

link_41 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.89555341712115,2.78049691677857,0.115726156086998)
cB = chrono.ChVectorD(-2.22228015683827,2.77437872020321,0.121740587561141)
dA = chrono.ChVectorD(0.0184050216223813,3.02106951993959e-15,0.999830613243603)
dB = chrono.ChVectorD(-0.0184050216223813,-3.26123099969697e-15,-0.999830613243603)
link_41.Initialize(body_47,body_45,False,cA,cB,dB)
link_41.SetDistance(0)
link_41.SetName("Coincident34")
exported_items.append(link_41)

link_42 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.89555341712115,2.78049691677857,0.115726156086998)
dA = chrono.ChVectorD(0.0184050216223813,3.02106951993959e-15,0.999830613243603)
cB = chrono.ChVectorD(-2.22228015683827,2.77437872020321,0.121740587561141)
dB = chrono.ChVectorD(-0.0184050216223813,-3.26123099969697e-15,-0.999830613243603)
link_42.SetFlipped(True)
link_42.Initialize(body_47,body_45,False,cA,cB,dA,dB)
link_42.SetName("Coincident34")
exported_items.append(link_42)


# Mate constraint: Concentric10 [MateConcentric] type:1 align:1 flip:False
#   Entity 0: C::E name: body_44 , SW name: M-410iB-300 -9/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_42 , SW name: M-410iB-300 -9/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_43 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.38429450439044,2.78749692402102,0.668418628544729)
dA = chrono.ChVectorD(-0.0184050216289121,-3.55911871829818e-15,-0.999830613243483)
cB = chrono.ChVectorD(-1.38429450439044,2.78749692402101,0.66841862854473)
dB = chrono.ChVectorD(0.0184050216289114,3.94783272266648e-15,0.999830613243483)
link_43.SetFlipped(True)
link_43.Initialize(body_44,body_42,False,cA,cB,dA,dB)
link_43.SetName("Concentric10")
exported_items.append(link_43)

link_44 = chrono.ChLinkMateGeneric()
link_44.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.38429450439044,2.78749692402102,0.668418628544729)
cB = chrono.ChVectorD(-1.38429450439044,2.78749692402101,0.66841862854473)
dA = chrono.ChVectorD(-0.0184050216289121,-3.55911871829818e-15,-0.999830613243483)
dB = chrono.ChVectorD(0.0184050216289114,3.94783272266648e-15,0.999830613243483)
link_44.Initialize(body_44,body_42,False,cA,cB,dA,dB)
link_44.SetName("Concentric10")
exported_items.append(link_44)


# Mate constraint: Coincident35 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_39 , SW name: M-410iB-300 -9/M-410iB-300-11-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_38 , SW name: M-410iB-300 -9/M-410iB-300-12-1 ,  SW ref.type:2 (2)

link_45 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-4.32063050538315,1.9579885584307,0.610184091975045)
cB = chrono.ChVectorD(-4.18186525424092,2.1566102546218,0.607629681838431)
dA = chrono.ChVectorD(-0.0184050216223813,-2.90098878006114e-15,-0.999830613243603)
dB = chrono.ChVectorD(0.0184050219696108,5.19696320789579e-15,0.999830613237211)
link_45.Initialize(body_39,body_38,False,cA,cB,dB)
link_45.SetDistance(0)
link_45.SetName("Coincident35")
exported_items.append(link_45)

link_46 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-4.32063050538315,1.9579885584307,0.610184091975045)
dA = chrono.ChVectorD(-0.0184050216223813,-2.90098878006114e-15,-0.999830613243603)
cB = chrono.ChVectorD(-4.18186525424092,2.1566102546218,0.607629681838431)
dB = chrono.ChVectorD(0.0184050219696108,5.19696320789579e-15,0.999830613237211)
link_46.SetFlipped(True)
link_46.Initialize(body_39,body_38,False,cA,cB,dA,dB)
link_46.SetName("Coincident35")
exported_items.append(link_46)


# Mate constraint: Coincident36 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_46 , SW name: M-410iB-300 -9/M-410iB-300-06-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_49 , SW name: M-410iB-300 -9/M-410iB-300-08-1 ,  SW ref.type:4 (4)

link_47 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.08446240365476,2.75811166839776,0.491831343880605)
cB = chrono.ChVectorD(-1.5723315078021,3.01244418440915,0.463995827078662)
dA = chrono.ChVectorD(-0.0184050216223813,-3.02106951993987e-15,-0.999830613243603)
dB = chrono.ChVectorD(-0.0184050216223813,-3.1411502598179e-15,-0.999830613243603)
link_47.Initialize(body_46,body_49,False,cA,cB,dB)
link_47.SetDistance(0)
link_47.SetName("Coincident36")
exported_items.append(link_47)

link_48 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.08446240365476,2.75811166839776,0.491831343880605)
dA = chrono.ChVectorD(-0.0184050216223813,-3.02106951993987e-15,-0.999830613243603)
cB = chrono.ChVectorD(-1.5723315078021,3.01244418440915,0.463995827078662)
dB = chrono.ChVectorD(-0.0184050216223813,-3.1411502598179e-15,-0.999830613243603)
link_48.Initialize(body_46,body_49,False,cA,cB,dA,dB)
link_48.SetName("Coincident36")
exported_items.append(link_48)


# Mate constraint: Coincident37 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_40 , SW name: M-410iB-300 -9/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_39 , SW name: M-410iB-300 -9/M-410iB-300-11-1 ,  SW ref.type:2 (2)

link_49 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.08078453358675,3.2136541835116,0.651633721084286)
cB = chrono.ChVectorD(-3.58143757647903,3.02810836634589,0.660849812237465)
dA = chrono.ChVectorD(-0.018405021628912,-3.56712868232535e-15,-0.999830613243483)
dB = chrono.ChVectorD(0.0184050216223813,2.90098878006114e-15,0.999830613243603)
link_49.Initialize(body_40,body_39,False,cA,cB,dB)
link_49.SetDistance(0)
link_49.SetName("Coincident37")
exported_items.append(link_49)

link_50 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.08078453358675,3.2136541835116,0.651633721084286)
dA = chrono.ChVectorD(-0.018405021628912,-3.56712868232535e-15,-0.999830613243483)
cB = chrono.ChVectorD(-3.58143757647903,3.02810836634589,0.660849812237465)
dB = chrono.ChVectorD(0.0184050216223813,2.90098878006114e-15,0.999830613243603)
link_50.SetFlipped(True)
link_50.Initialize(body_40,body_39,False,cA,cB,dA,dB)
link_50.SetName("Coincident37")
exported_items.append(link_50)


# Mate constraint: Coincident38 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_43 , SW name: M-410iB-300 -9/M-410iB-300-03-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_46 , SW name: M-410iB-300 -9/M-410iB-300-06-1 ,  SW ref.type:4 (4)

link_51 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.88958376354979,2.51550127212935,0.439830768464553)
cB = chrono.ChVectorD(-3.08501455430343,2.75811166839776,0.461836425483298)
dA = chrono.ChVectorD(-0.0184050216223813,-3.38131173957543e-15,-0.999830613243603)
dB = chrono.ChVectorD(0.0184050216223813,3.02106951993987e-15,0.999830613243603)
link_51.Initialize(body_43,body_46,False,cA,cB,dB)
link_51.SetDistance(0)
link_51.SetName("Coincident38")
exported_items.append(link_51)

link_52 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.88958376354979,2.51550127212935,0.439830768464553)
dA = chrono.ChVectorD(-0.0184050216223813,-3.38131173957543e-15,-0.999830613243603)
cB = chrono.ChVectorD(-3.08501455430343,2.75811166839776,0.461836425483298)
dB = chrono.ChVectorD(0.0184050216223813,3.02106951993987e-15,0.999830613243603)
link_52.SetFlipped(True)
link_52.Initialize(body_43,body_46,False,cA,cB,dA,dB)
link_52.SetName("Coincident38")
exported_items.append(link_52)


# Mate constraint: Coincident6 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_54 , SW name: M-410iB-300 -7/M-410iB-300-03-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_50 , SW name: M-410iB-300 -7/M-410iB-300-06-1 ,  SW ref.type:5 (5)

link_1 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.08068903286662,2.75811166844499,-2.31190996288065)
dA = chrono.ChVectorD(0.0300104876466858,3.49592597941212e-15,0.999549583878263)
cB = chrono.ChVectorD(-3.08122669401094,2.75811166844499,-2.32981766832672)
dB = chrono.ChVectorD(-0.0300104876466859,-3.49473335702243e-15,-0.999549583878263)
link_1.SetFlipped(True)
link_1.Initialize(body_54,body_50,False,cA,cB,dA,dB)
link_1.SetName("Coincident6")
exported_items.append(link_1)

link_2 = chrono.ChLinkMateGeneric()
link_2.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.08068903286662,2.75811166844499,-2.31190996288065)
cB = chrono.ChVectorD(-3.08122669401094,2.75811166844499,-2.32981766832672)
dA = chrono.ChVectorD(0.0300104876466858,3.49592597941212e-15,0.999549583878263)
dB = chrono.ChVectorD(-0.0300104876466859,-3.49473335702243e-15,-0.999549583878263)
link_2.Initialize(body_54,body_50,False,cA,cB,dA,dB)
link_2.SetName("Coincident6")
exported_items.append(link_2)


# Mate constraint: Coincident7 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_53 , SW name: M-410iB-300 -7/M-410iB-300-02-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_55 , SW name: M-410iB-300 -7/M-410iB-300-07-1 ,  SW ref.type:5 (5)

link_3 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.8964032744851,2.51550127212934,-2.7078041690917)
dA = chrono.ChVectorD(0.0300104876466856,3.40959596095003e-15,0.999549583878263)
cB = chrono.ChVectorD(-1.88715324154591,2.51550127212934,-2.399716321303)
dB = chrono.ChVectorD(-0.0300104876466857,-3.17034006701472e-15,-0.999549583878263)
link_3.SetFlipped(True)
link_3.Initialize(body_53,body_55,False,cA,cB,dA,dB)
link_3.SetName("Coincident7")
exported_items.append(link_3)

link_4 = chrono.ChLinkMateGeneric()
link_4.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.8964032744851,2.51550127212934,-2.7078041690917)
cB = chrono.ChVectorD(-1.88715324154591,2.51550127212934,-2.399716321303)
dA = chrono.ChVectorD(0.0300104876466856,3.40959596095003e-15,0.999549583878263)
dB = chrono.ChVectorD(-0.0300104876466857,-3.17034006701472e-15,-0.999549583878263)
link_4.Initialize(body_53,body_55,False,cA,cB,dA,dB)
link_4.SetName("Coincident7")
exported_items.append(link_4)


# Mate constraint: Coincident8 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_50 , SW name: M-410iB-300 -7/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_55 , SW name: M-410iB-300 -7/M-410iB-300-07-1 ,  SW ref.type:2 (2)

link_5 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-2.6114846378689,3.10517580019773,-2.45397077706144)
cB = chrono.ChVectorD(-1.56897709714406,3.00997129523558,-2.48527103487467)
dA = chrono.ChVectorD(0.0300104876466859,3.49473335702243e-15,0.999549583878263)
dB = chrono.ChVectorD(0.0300104876466857,3.17034006701472e-15,0.999549583878263)
link_5.Initialize(body_50,body_55,False,cA,cB,dB)
link_5.SetDistance(0)
link_5.SetName("Coincident8")
exported_items.append(link_5)

link_6 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.6114846378689,3.10517580019773,-2.45397077706144)
dA = chrono.ChVectorD(0.0300104876466859,3.49473335702243e-15,0.999549583878263)
cB = chrono.ChVectorD(-1.56897709714406,3.00997129523558,-2.48527103487467)
dB = chrono.ChVectorD(0.0300104876466857,3.17034006701472e-15,0.999549583878263)
link_6.Initialize(body_50,body_55,False,cA,cB,dA,dB)
link_6.SetName("Coincident8")
exported_items.append(link_6)


# Mate constraint: Coincident9 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_50 , SW name: M-410iB-300 -7/M-410iB-300-06-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_56 , SW name: M-410iB-300 -7/M-410iB-300-08-1 ,  SW ref.type:5 (5)

link_7 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.76734971546373,3.25503771749134,-2.44929108226575)
dA = chrono.ChVectorD(0.0300104876466859,3.49473335702243e-15,0.999549583878263)
cB = chrono.ChVectorD(-2.76645462265918,3.25503771749134,-2.419478516377)
dB = chrono.ChVectorD(0.0300104876466858,2.93021356617892e-15,0.999549583878263)
link_7.Initialize(body_50,body_56,False,cA,cB,dA,dB)
link_7.SetName("Coincident9")
exported_items.append(link_7)

link_8 = chrono.ChLinkMateGeneric()
link_8.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-2.76734971546373,3.25503771749134,-2.44929108226575)
cB = chrono.ChVectorD(-2.76645462265918,3.25503771749134,-2.419478516377)
dA = chrono.ChVectorD(0.0300104876466859,3.49473335702243e-15,0.999549583878263)
dB = chrono.ChVectorD(0.0300104876466858,2.93021356617892e-15,0.999549583878263)
link_8.Initialize(body_50,body_56,False,cA,cB,dA,dB)
link_8.SetName("Coincident9")
exported_items.append(link_8)


# Mate constraint: Coincident11 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_53 , SW name: M-410iB-300 -7/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_57 , SW name: M-410iB-300 -7/M-410iB-300-09-1 ,  SW ref.type:2 (2)

link_9 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.52867264147508,2.72491052060181,-2.22851594453256)
cB = chrono.ChVectorD(-3.07605392412587,3.21365418352611,-2.18205735196579)
dA = chrono.ChVectorD(0.0300104876466856,3.40959596095003e-15,0.999549583878263)
dB = chrono.ChVectorD(0.0300104876466859,3.50092543256461e-15,0.999549583878263)
link_9.Initialize(body_53,body_57,False,cA,cB,dB)
link_9.SetDistance(0)
link_9.SetName("Coincident11")
exported_items.append(link_9)

link_10 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.52867264147508,2.72491052060181,-2.22851594453256)
dA = chrono.ChVectorD(0.0300104876466856,3.40959596095003e-15,0.999549583878263)
cB = chrono.ChVectorD(-3.07605392412587,3.21365418352611,-2.18205735196579)
dB = chrono.ChVectorD(0.0300104876466859,3.50092543256461e-15,0.999549583878263)
link_10.Initialize(body_53,body_57,False,cA,cB,dA,dB)
link_10.SetName("Coincident11")
exported_items.append(link_10)


# Mate constraint: Coincident22 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_57 , SW name: M-410iB-300 -7/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_59 , SW name: M-410iB-300 -7/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_11 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.07605392412587,3.21365418352611,-2.18205735196579)
cB = chrono.ChVectorD(-2.57601712464689,3.03011496697179,-2.19707046231143)
dA = chrono.ChVectorD(0.0300104876466859,3.50092543256461e-15,0.999549583878263)
dB = chrono.ChVectorD(-0.0300104876466859,-3.50167225092629e-15,-0.999549583878263)
link_11.Initialize(body_57,body_59,False,cA,cB,dB)
link_11.SetDistance(0)
link_11.SetName("Coincident22")
exported_items.append(link_11)

link_12 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.07605392412587,3.21365418352611,-2.18205735196579)
dA = chrono.ChVectorD(0.0300104876466859,3.50092543256461e-15,0.999549583878263)
cB = chrono.ChVectorD(-2.57601712464689,3.03011496697179,-2.19707046231143)
dB = chrono.ChVectorD(-0.0300104876466859,-3.50167225092629e-15,-0.999549583878263)
link_12.SetFlipped(True)
link_12.Initialize(body_57,body_59,False,cA,cB,dA,dB)
link_12.SetName("Coincident22")
exported_items.append(link_12)


# Mate constraint: Coincident15 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_50 , SW name: M-410iB-300 -7/M-410iB-300-06-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_60 , SW name: M-410iB-300 -7/M-410iB-300-12-1 ,  SW ref.type:5 (5)

link_13 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.82788158440072,1.69373359957664,-2.32740910617047)
dA = chrono.ChVectorD(-0.0300104876466859,-3.49473335702243e-15,-0.999549583878263)
cB = chrono.ChVectorD(-3.82750402244753,1.69373359958772,-2.31483377285857)
dB = chrono.ChVectorD(0.0300104879938178,5.67054092762953e-15,0.999549583867841)
link_13.SetFlipped(True)
link_13.Initialize(body_50,body_60,False,cA,cB,dA,dB)
link_13.SetName("Coincident15")
exported_items.append(link_13)

link_14 = chrono.ChLinkMateGeneric()
link_14.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.82788158440072,1.69373359957664,-2.32740910617047)
cB = chrono.ChVectorD(-3.82750402244753,1.69373359958772,-2.31483377285857)
dA = chrono.ChVectorD(-0.0300104876466859,-3.49473335702243e-15,-0.999549583878263)
dB = chrono.ChVectorD(0.0300104879938178,5.67054092762953e-15,0.999549583867841)
link_14.Initialize(body_50,body_60,False,cA,cB,dA,dB)
link_14.SetName("Coincident15")
exported_items.append(link_14)


# Mate constraint: Coincident17 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_55 , SW name: M-410iB-300 -7/M-410iB-300-07-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_56 , SW name: M-410iB-300 -7/M-410iB-300-08-1 ,  SW ref.type:5 (5)

link_15 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.56631777780223,3.00997129523558,-2.39669794759847)
dA = chrono.ChVectorD(-0.0300104876466857,-3.17034006701472e-15,-0.999549583878263)
cB = chrono.ChVectorD(-1.56808200433951,3.00997129523558,-2.45545846898592)
dB = chrono.ChVectorD(0.0300104876466858,2.93021356617892e-15,0.999549583878263)
link_15.SetFlipped(True)
link_15.Initialize(body_55,body_56,False,cA,cB,dA,dB)
link_15.SetName("Coincident17")
exported_items.append(link_15)

link_16 = chrono.ChLinkMateGeneric()
link_16.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.56631777780223,3.00997129523558,-2.39669794759847)
cB = chrono.ChVectorD(-1.56808200433951,3.00997129523558,-2.45545846898592)
dA = chrono.ChVectorD(-0.0300104876466857,-3.17034006701472e-15,-0.999549583878263)
dB = chrono.ChVectorD(0.0300104876466858,2.93021356617892e-15,0.999549583878263)
link_16.Initialize(body_55,body_56,False,cA,cB,dA,dB)
link_16.SetName("Coincident17")
exported_items.append(link_16)


# Mate constraint: Coincident18 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_53 , SW name: M-410iB-300 -7/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_61 , SW name: M-410iB-300 -7/ArmBase-1 ,  SW ref.type:2 (2)

link_17 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.50067035797968,2.04602671615661,-2.52259688654794)
cB = chrono.ChVectorD(-1.25867129241134,2.04602671615662,-2.52259688656262)
dA = chrono.ChVectorD(9.92208192593352e-17,-1,3.40815338300842e-15)
dB = chrono.ChVectorD(-6.42083927456682e-17,1,-3.44169137633798e-15)
link_17.Initialize(body_53,body_61,False,cA,cB,dB)
link_17.SetDistance(0)
link_17.SetName("Coincident18")
exported_items.append(link_17)

link_18 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.50067035797968,2.04602671615661,-2.52259688654794)
dA = chrono.ChVectorD(9.92208192593352e-17,-1,3.40815338300842e-15)
cB = chrono.ChVectorD(-1.25867129241134,2.04602671615662,-2.52259688656262)
dB = chrono.ChVectorD(-6.42083927456682e-17,1,-3.44169137633798e-15)
link_18.SetFlipped(True)
link_18.Initialize(body_53,body_61,False,cA,cB,dA,dB)
link_18.SetName("Coincident18")
exported_items.append(link_18)


# Mate constraint: Concentric1 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_53 , SW name: M-410iB-300 -7/M-410iB-300-02-1 ,  SW ref.type:1 (1)
#   Entity 1: C::E name: body_61 , SW name: M-410iB-300 -7/ArmBase-1 ,  SW ref.type:1 (1)

link_19 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.50067035797968,2.04755071615661,-2.52259688654794)
dA = chrono.ChVectorD(-9.92208192593352e-17,1,-3.40815338300842e-15)
cB = chrono.ChVectorD(-1.50067035795504,2.04602671615662,-2.52259688656262)
dB = chrono.ChVectorD(-6.42083927456682e-17,1,-3.44169137633798e-15)
link_19.Initialize(body_53,body_61,False,cA,cB,dA,dB)
link_19.SetName("Concentric1")
exported_items.append(link_19)

link_20 = chrono.ChLinkMateGeneric()
link_20.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.50067035797968,2.04755071615661,-2.52259688654794)
cB = chrono.ChVectorD(-1.50067035795504,2.04602671615662,-2.52259688656262)
dA = chrono.ChVectorD(-9.92208192593352e-17,1,-3.40815338300842e-15)
dB = chrono.ChVectorD(-6.42083927456682e-17,1,-3.44169137633798e-15)
link_20.Initialize(body_53,body_61,False,cA,cB,dA,dB)
link_20.SetName("Concentric1")
exported_items.append(link_20)


# Mate constraint: Coincident21 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_50 , SW name: M-410iB-300 -7/M-410iB-300-06-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_60 , SW name: M-410iB-300 -7/M-410iB-300-12-1 ,  SW ref.type:4 (4)

link_21 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.08392763795857,2.75811166844499,-2.41977713285529)
cB = chrono.ChVectorD(-4.08486641276716,1.53473191895536,-2.38972493418615)
dA = chrono.ChVectorD(-0.0300104876466859,-3.49473335702243e-15,-0.999549583878263)
dB = chrono.ChVectorD(0.0300104878202518,4.52260551711703e-15,0.999549583873052)
link_21.Initialize(body_50,body_60,False,cA,cB,dB)
link_21.SetDistance(0)
link_21.SetName("Coincident21")
exported_items.append(link_21)

link_22 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.08392763795857,2.75811166844499,-2.41977713285529)
dA = chrono.ChVectorD(-0.0300104876466859,-3.49473335702243e-15,-0.999549583878263)
cB = chrono.ChVectorD(-4.08486641276716,1.53473191895536,-2.38972493418615)
dB = chrono.ChVectorD(0.0300104878202518,4.52260551711703e-15,0.999549583873052)
link_22.SetFlipped(True)
link_22.Initialize(body_50,body_60,False,cA,cB,dA,dB)
link_22.SetName("Coincident21")
exported_items.append(link_22)


# Mate constraint: Coincident25 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_54 , SW name: M-410iB-300 -7/M-410iB-300-03-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_52 , SW name: M-410iB-300 -7/M-410iB-300-05-1 ,  SW ref.type:2 (2)

link_23 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.08929410084576,2.75811166844499,-2.59851617265179)
cB = chrono.ChVectorD(-3.08929410084576,2.75811166844499,-2.59851617265179)
dA = chrono.ChVectorD(-0.0300104876466858,-3.49592597941212e-15,-0.999549583878263)
dB = chrono.ChVectorD(0.0300104876466858,3.49592597941212e-15,0.999549583878263)
link_23.Initialize(body_54,body_52,False,cA,cB,dB)
link_23.SetDistance(0)
link_23.SetName("Coincident25")
exported_items.append(link_23)

link_24 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.08929410084576,2.75811166844499,-2.59851617265179)
dA = chrono.ChVectorD(-0.0300104876466858,-3.49592597941212e-15,-0.999549583878263)
cB = chrono.ChVectorD(-3.08929410084576,2.75811166844499,-2.59851617265179)
dB = chrono.ChVectorD(0.0300104876466858,3.49592597941212e-15,0.999549583878263)
link_24.SetFlipped(True)
link_24.Initialize(body_54,body_52,False,cA,cB,dA,dB)
link_24.SetName("Coincident25")
exported_items.append(link_24)


# Mate constraint: Concentric2 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_50 , SW name: M-410iB-300 -7/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_57 , SW name: M-410iB-300 -7/M-410iB-300-09-1 ,  SW ref.type:2 (2)

link_25 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.07845072390362,2.75811166844499,-2.23735933181798)
dA = chrono.ChVectorD(-0.0300104876466859,-3.49473335702243e-15,-0.999549583878263)
cB = chrono.ChVectorD(-3.07659910685857,2.75811166843342,-2.17568812196224)
dB = chrono.ChVectorD(-0.0300104876466859,-3.50092543256461e-15,-0.999549583878263)
link_25.Initialize(body_50,body_57,False,cA,cB,dA,dB)
link_25.SetName("Concentric2")
exported_items.append(link_25)

link_26 = chrono.ChLinkMateGeneric()
link_26.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.07845072390362,2.75811166844499,-2.23735933181798)
cB = chrono.ChVectorD(-3.07659910685857,2.75811166843342,-2.17568812196224)
dA = chrono.ChVectorD(-0.0300104876466859,-3.49473335702243e-15,-0.999549583878263)
dB = chrono.ChVectorD(-0.0300104876466859,-3.50092543256461e-15,-0.999549583878263)
link_26.Initialize(body_50,body_57,False,cA,cB,dA,dB)
link_26.SetName("Concentric2")
exported_items.append(link_26)


# Mate constraint: Concentric3 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_57 , SW name: M-410iB-300 -7/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_59 , SW name: M-410iB-300 -7/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_27 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.57600638206857,3.0301149669593,-2.19671266068952)
dA = chrono.ChVectorD(-0.0300104876466859,-3.50092543256461e-15,-0.999549583878263)
cB = chrono.ChVectorD(-2.57473039497855,3.03011496697179,-2.15421377435307)
dB = chrono.ChVectorD(-0.0300104876466859,-3.50167225092629e-15,-0.999549583878263)
link_27.Initialize(body_57,body_59,False,cA,cB,dA,dB)
link_27.SetName("Concentric3")
exported_items.append(link_27)

link_28 = chrono.ChLinkMateGeneric()
link_28.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-2.57600638206857,3.0301149669593,-2.19671266068952)
cB = chrono.ChVectorD(-2.57473039497855,3.03011496697179,-2.15421377435307)
dA = chrono.ChVectorD(-0.0300104876466859,-3.50092543256461e-15,-0.999549583878263)
dB = chrono.ChVectorD(-0.0300104876466859,-3.50167225092629e-15,-0.999549583878263)
link_28.Initialize(body_57,body_59,False,cA,cB,dA,dB)
link_28.SetName("Concentric3")
exported_items.append(link_28)


# Mate constraint: Concentric4 [MateConcentric] type:1 align:1 flip:False
#   Entity 0: C::E name: body_57 , SW name: M-410iB-300 -7/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_58 , SW name: M-410iB-300 -7/M-410iB-300-11-1 ,  SW ref.type:2 (2)

link_29 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.57655550232916,3.02810836638155,-2.16667216295155)
dA = chrono.ChVectorD(-0.0300104876466859,-3.50092543256461e-15,-0.999549583878263)
cB = chrono.ChVectorD(-3.57956957449628,3.02810836639312,-2.26706088873771)
dB = chrono.ChVectorD(0.0300104876466859,3.37467010660448e-15,0.999549583878263)
link_29.SetFlipped(True)
link_29.Initialize(body_57,body_58,False,cA,cB,dA,dB)
link_29.SetName("Concentric4")
exported_items.append(link_29)

link_30 = chrono.ChLinkMateGeneric()
link_30.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.57655550232916,3.02810836638155,-2.16667216295155)
cB = chrono.ChVectorD(-3.57956957449628,3.02810836639312,-2.26706088873771)
dA = chrono.ChVectorD(-0.0300104876466859,-3.50092543256461e-15,-0.999549583878263)
dB = chrono.ChVectorD(0.0300104876466859,3.37467010660448e-15,0.999549583878263)
link_30.Initialize(body_57,body_58,False,cA,cB,dA,dB)
link_30.SetName("Concentric4")
exported_items.append(link_30)


# Mate constraint: Concentric6 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_54 , SW name: M-410iB-300 -7/M-410iB-300-03-1 ,  SW ref.type:1 (1)
#   Entity 1: C::E name: body_52 , SW name: M-410iB-300 -7/M-410iB-300-05-1 ,  SW ref.type:2 (2)

link_31 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.08929410084576,2.75811166844499,-2.59851617265179)
dA = chrono.ChVectorD(-0.0300104876466858,-3.49592597941212e-15,-0.999549583878263)
cB = chrono.ChVectorD(-3.08929410084576,2.75811166844499,-2.59851617265179)
dB = chrono.ChVectorD(-0.0300104876466858,-3.49592597941212e-15,-0.999549583878263)
link_31.Initialize(body_54,body_52,False,cA,cB,dA,dB)
link_31.SetName("Concentric6")
exported_items.append(link_31)

link_32 = chrono.ChLinkMateGeneric()
link_32.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.08929410084576,2.75811166844499,-2.59851617265179)
cB = chrono.ChVectorD(-3.08929410084576,2.75811166844499,-2.59851617265179)
dA = chrono.ChVectorD(-0.0300104876466858,-3.49592597941212e-15,-0.999549583878263)
dB = chrono.ChVectorD(-0.0300104876466858,-3.49592597941212e-15,-0.999549583878263)
link_32.Initialize(body_54,body_52,False,cA,cB,dA,dB)
link_32.SetName("Concentric6")
exported_items.append(link_32)


# Mate constraint: Concentric7 [MateConcentric] type:1 align:1 flip:False
#   Entity 0: C::E name: body_53 , SW name: M-410iB-300 -7/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_51 , SW name: M-410iB-300 -7/M-410iB-300-04-1 ,  SW ref.type:2 (2)

link_33 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.89655801595507,2.78049691677856,-2.71284180064624)
dA = chrono.ChVectorD(0.0300104876466856,3.40959596095003e-15,0.999549583878263)
cB = chrono.ChVectorD(-1.89588135318749,2.78049691677856,-2.69030441402808)
dB = chrono.ChVectorD(-0.0300104876466857,-3.2895327105321e-15,-0.999549583878263)
link_33.SetFlipped(True)
link_33.Initialize(body_53,body_51,False,cA,cB,dA,dB)
link_33.SetName("Concentric7")
exported_items.append(link_33)

link_34 = chrono.ChLinkMateGeneric()
link_34.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.89655801595507,2.78049691677856,-2.71284180064624)
cB = chrono.ChVectorD(-1.89588135318749,2.78049691677856,-2.69030441402808)
dA = chrono.ChVectorD(0.0300104876466856,3.40959596095003e-15,0.999549583878263)
dB = chrono.ChVectorD(-0.0300104876466857,-3.2895327105321e-15,-0.999549583878263)
link_34.Initialize(body_53,body_51,False,cA,cB,dA,dB)
link_34.SetName("Concentric7")
exported_items.append(link_34)


# Mate constraint: Concentric8 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_58 , SW name: M-410iB-300 -7/M-410iB-300-11-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_60 , SW name: M-410iB-300 -7/M-410iB-300-12-1 ,  SW ref.type:2 (2)

link_35 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-4.32562427296064,1.96373031003322,-2.24466133430525)
dA = chrono.ChVectorD(0.0300104876466859,3.37467010660448e-15,0.999549583878263)
cB = chrono.ChVectorD(-4.32747117839606,1.96373031003323,-2.30617561495198)
dB = chrono.ChVectorD(0.0300104876466859,3.37467010660452e-15,0.999549583878263)
link_35.Initialize(body_58,body_60,False,cA,cB,dA,dB)
link_35.SetName("Concentric8")
exported_items.append(link_35)

link_36 = chrono.ChLinkMateGeneric()
link_36.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-4.32562427296064,1.96373031003322,-2.24466133430525)
cB = chrono.ChVectorD(-4.32747117839606,1.96373031003323,-2.30617561495198)
dA = chrono.ChVectorD(0.0300104876466859,3.37467010660448e-15,0.999549583878263)
dB = chrono.ChVectorD(0.0300104876466859,3.37467010660452e-15,0.999549583878263)
link_36.Initialize(body_58,body_60,False,cA,cB,dA,dB)
link_36.SetName("Concentric8")
exported_items.append(link_36)


# Mate constraint: Concentric9 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_54 , SW name: M-410iB-300 -7/M-410iB-300-03-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_55 , SW name: M-410iB-300 -7/M-410iB-300-07-1 ,  SW ref.type:2 (2)

link_37 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.89400875157689,2.51550127212934,-2.62805057162974)
dA = chrono.ChVectorD(0.0300104876466858,3.49592597941212e-15,0.999549583878263)
cB = chrono.ChVectorD(-1.89237708457123,2.51550127212934,-2.57370516759161)
dB = chrono.ChVectorD(0.0300104876466857,3.17034006701472e-15,0.999549583878263)
link_37.Initialize(body_54,body_55,False,cA,cB,dA,dB)
link_37.SetName("Concentric9")
exported_items.append(link_37)

link_38 = chrono.ChLinkMateGeneric()
link_38.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.89400875157689,2.51550127212934,-2.62805057162974)
cB = chrono.ChVectorD(-1.89237708457123,2.51550127212934,-2.57370516759161)
dA = chrono.ChVectorD(0.0300104876466858,3.49592597941212e-15,0.999549583878263)
dB = chrono.ChVectorD(0.0300104876466857,3.17034006701472e-15,0.999549583878263)
link_38.Initialize(body_54,body_55,False,cA,cB,dA,dB)
link_38.SetName("Concentric9")
exported_items.append(link_38)


# Mate constraint: Coincident33 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_51 , SW name: M-410iB-300 -7/M-410iB-300-04-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_52 , SW name: M-410iB-300 -7/M-410iB-300-05-1 ,  SW ref.type:4 (4)

link_39 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.898564530867,2.78049691677856,-2.77967214322347)
cB = chrono.ChVectorD(-2.22519943520991,2.77437872021626,-2.76986525328038)
dA = chrono.ChVectorD(0.0187108456028805,-0.999824778981841,-0.000561774633172564)
dB = chrono.ChVectorD(0.0187108456028806,-0.999824778981841,-0.000561774633172361)
link_39.Initialize(body_51,body_52,False,cA,cB,dB)
link_39.SetDistance(0)
link_39.SetName("Coincident33")
exported_items.append(link_39)

link_40 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.898564530867,2.78049691677856,-2.77967214322347)
dA = chrono.ChVectorD(0.0187108456028805,-0.999824778981841,-0.000561774633172564)
cB = chrono.ChVectorD(-2.22519943520991,2.77437872021626,-2.76986525328038)
dB = chrono.ChVectorD(0.0187108456028806,-0.999824778981841,-0.000561774633172361)
link_40.Initialize(body_51,body_52,False,cA,cB,dA,dB)
link_40.SetName("Coincident33")
exported_items.append(link_40)


# Mate constraint: Coincident34 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_51 , SW name: M-410iB-300 -7/M-410iB-300-04-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_52 , SW name: M-410iB-300 -7/M-410iB-300-05-1 ,  SW ref.type:4 (4)

link_41 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.898564530867,2.78049691677856,-2.77967214322347)
cB = chrono.ChVectorD(-2.22519943520991,2.77437872021626,-2.76986525328038)
dA = chrono.ChVectorD(0.0300104876466857,3.2895327105321e-15,0.999549583878263)
dB = chrono.ChVectorD(-0.0300104876466858,-3.49592597941212e-15,-0.999549583878263)
link_41.Initialize(body_51,body_52,False,cA,cB,dB)
link_41.SetDistance(0)
link_41.SetName("Coincident34")
exported_items.append(link_41)

link_42 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.898564530867,2.78049691677856,-2.77967214322347)
dA = chrono.ChVectorD(0.0300104876466857,3.2895327105321e-15,0.999549583878263)
cB = chrono.ChVectorD(-2.22519943520991,2.77437872021626,-2.76986525328038)
dB = chrono.ChVectorD(-0.0300104876466858,-3.49592597941212e-15,-0.999549583878263)
link_42.SetFlipped(True)
link_42.Initialize(body_51,body_52,False,cA,cB,dA,dB)
link_42.SetName("Coincident34")
exported_items.append(link_42)


# Mate constraint: Concentric10 [MateConcentric] type:1 align:1 flip:False
#   Entity 0: C::E name: body_53 , SW name: M-410iB-300 -7/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_59 , SW name: M-410iB-300 -7/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_43 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.38092404233479,2.78749692402101,-2.23295195009029)
dA = chrono.ChVectorD(-0.0300104876466856,-3.40959596095003e-15,-0.999549583878263)
cB = chrono.ChVectorD(-1.38092404228073,2.78749692403349,-2.23295195009699)
dB = chrono.ChVectorD(0.0300104876466859,3.50167225092629e-15,0.999549583878263)
link_43.SetFlipped(True)
link_43.Initialize(body_53,body_59,False,cA,cB,dA,dB)
link_43.SetName("Concentric10")
exported_items.append(link_43)

link_44 = chrono.ChLinkMateGeneric()
link_44.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.38092404233479,2.78749692402101,-2.23295195009029)
cB = chrono.ChVectorD(-1.38092404228073,2.78749692403349,-2.23295195009699)
dA = chrono.ChVectorD(-0.0300104876466856,-3.40959596095003e-15,-0.999549583878263)
dB = chrono.ChVectorD(0.0300104876466859,3.50167225092629e-15,0.999549583878263)
link_44.Initialize(body_53,body_59,False,cA,cB,dA,dB)
link_44.SetName("Concentric10")
exported_items.append(link_44)


# Mate constraint: Coincident35 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_58 , SW name: M-410iB-300 -7/M-410iB-300-11-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_60 , SW name: M-410iB-300 -7/M-410iB-300-12-1 ,  SW ref.type:2 (2)

link_45 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-4.32599016082603,1.96373031003322,-2.2568478428319)
cB = chrono.ChVectorD(-4.1872639133418,2.16235200618291,-2.26101296121042)
dA = chrono.ChVectorD(-0.0300104876466859,-3.37467010660448e-15,-0.999549583878263)
dB = chrono.ChVectorD(0.0300104879938178,5.67054092762953e-15,0.999549583867841)
link_45.Initialize(body_58,body_60,False,cA,cB,dB)
link_45.SetDistance(0)
link_45.SetName("Coincident35")
exported_items.append(link_45)

link_46 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-4.32599016082603,1.96373031003322,-2.2568478428319)
dA = chrono.ChVectorD(-0.0300104876466859,-3.37467010660448e-15,-0.999549583878263)
cB = chrono.ChVectorD(-4.1872639133418,2.16235200618291,-2.26101296121042)
dB = chrono.ChVectorD(0.0300104879938178,5.67054092762953e-15,0.999549583867841)
link_46.SetFlipped(True)
link_46.Initialize(body_58,body_60,False,cA,cB,dA,dB)
link_46.SetName("Coincident35")
exported_items.append(link_46)


# Mate constraint: Coincident36 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_50 , SW name: M-410iB-300 -7/M-410iB-300-06-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_56 , SW name: M-410iB-300 -7/M-410iB-300-08-1 ,  SW ref.type:4 (4)

link_47 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.08302732326974,2.75811166844499,-2.38979064335942)
cB = chrono.ChVectorD(-1.56747657276173,3.00997129523558,-2.43529355568076)
dA = chrono.ChVectorD(-0.0300104876466859,-3.49473335702243e-15,-0.999549583878263)
dB = chrono.ChVectorD(-0.0300104876466858,-2.93021356617892e-15,-0.999549583878263)
link_47.Initialize(body_50,body_56,False,cA,cB,dB)
link_47.SetDistance(0)
link_47.SetName("Coincident36")
exported_items.append(link_47)

link_48 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.08302732326974,2.75811166844499,-2.38979064335942)
dA = chrono.ChVectorD(-0.0300104876466859,-3.49473335702243e-15,-0.999549583878263)
cB = chrono.ChVectorD(-1.56747657276173,3.00997129523558,-2.43529355568076)
dB = chrono.ChVectorD(-0.0300104876466858,-2.93021356617892e-15,-0.999549583878263)
link_48.Initialize(body_50,body_56,False,cA,cB,dA,dB)
link_48.SetName("Coincident36")
exported_items.append(link_48)


# Mate constraint: Coincident37 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_57 , SW name: M-410iB-300 -7/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_58 , SW name: M-410iB-300 -7/M-410iB-300-11-1 ,  SW ref.type:2 (2)

link_49 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.07749460759584,3.21365418352611,-2.23004172928945)
cB = chrono.ChVectorD(-3.57800692840451,3.02810836639312,-2.21501434190517)
dA = chrono.ChVectorD(-0.0300104876466859,-3.50092543256461e-15,-0.999549583878263)
dB = chrono.ChVectorD(0.0300104876466859,3.37467010660448e-15,0.999549583878263)
link_49.Initialize(body_57,body_58,False,cA,cB,dB)
link_49.SetDistance(0)
link_49.SetName("Coincident37")
exported_items.append(link_49)

link_50 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.07749460759584,3.21365418352611,-2.23004172928945)
dA = chrono.ChVectorD(-0.0300104876466859,-3.50092543256461e-15,-0.999549583878263)
cB = chrono.ChVectorD(-3.57800692840451,3.02810836639312,-2.21501434190517)
dB = chrono.ChVectorD(0.0300104876466859,3.37467010660448e-15,0.999549583878263)
link_50.SetFlipped(True)
link_50.Initialize(body_57,body_58,False,cA,cB,dA,dB)
link_50.SetName("Coincident37")
exported_items.append(link_50)


# Mate constraint: Coincident38 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_54 , SW name: M-410iB-300 -7/M-410iB-300-03-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_50 , SW name: M-410iB-300 -7/M-410iB-300-06-1 ,  SW ref.type:4 (4)

link_51 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.88883285522682,2.51550127212934,-2.45565866971133)
cB = chrono.ChVectorD(-3.08392763789914,2.75811166844499,-2.41977713087576)
dA = chrono.ChVectorD(-0.0300104876466858,-3.49592597941212e-15,-0.999549583878263)
dB = chrono.ChVectorD(0.0300104876466859,3.49473335702243e-15,0.999549583878263)
link_51.Initialize(body_54,body_50,False,cA,cB,dB)
link_51.SetDistance(0)
link_51.SetName("Coincident38")
exported_items.append(link_51)

link_52 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.88883285522682,2.51550127212934,-2.45565866971133)
dA = chrono.ChVectorD(-0.0300104876466858,-3.49592597941212e-15,-0.999549583878263)
cB = chrono.ChVectorD(-3.08392763789914,2.75811166844499,-2.41977713087576)
dB = chrono.ChVectorD(0.0300104876466859,3.49473335702243e-15,0.999549583878263)
link_52.SetFlipped(True)
link_52.Initialize(body_54,body_50,False,cA,cB,dA,dB)
link_52.SetName("Coincident38")
exported_items.append(link_52)


# Mate constraint: Coincident6 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_65 , SW name: M-410iB-300 -1/M-410iB-300-03-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_73 , SW name: M-410iB-300 -1/M-410iB-300-06-1 ,  SW ref.type:5 (5)

link_1 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.43112677510438,2.82931662753848,0.244485154748101)
dA = chrono.ChVectorD(0.0192655948011811,-3.29030050554087e-15,-0.999814401205022)
cB = chrono.ChVectorD(1.43078161704268,2.82931662753848,0.262397604601817)
dB = chrono.ChVectorD(-0.0192655948011819,3.59261231874797e-15,0.999814401205022)
link_1.SetFlipped(True)
link_1.Initialize(body_65,body_73,False,cA,cB,dA,dB)
link_1.SetName("Coincident6")
exported_items.append(link_1)

link_2 = chrono.ChLinkMateGeneric()
link_2.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.43112677510438,2.82931662753848,0.244485154748101)
cB = chrono.ChVectorD(1.43078161704268,2.82931662753848,0.262397604601817)
dA = chrono.ChVectorD(0.0192655948011811,-3.29030050554087e-15,-0.999814401205022)
dB = chrono.ChVectorD(-0.0192655948011819,3.59261231874797e-15,0.999814401205022)
link_2.Initialize(body_65,body_73,False,cA,cB,dA,dB)
link_2.SetName("Coincident6")
exported_items.append(link_2)


# Mate constraint: Coincident7 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_64 , SW name: M-410iB-300 -1/M-410iB-300-02-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_70 , SW name: M-410iB-300 -1/M-410iB-300-07-1 ,  SW ref.type:5 (5)

link_3 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.245458448190709,2.51550127212939,0.581880065299065)
dA = chrono.ChVectorD(0.0192655948011815,-3.49083332468477e-15,-0.999814401205022)
cB = chrono.ChVectorD(0.251396618427903,2.51550127212935,0.273710593682706)
dB = chrono.ChVectorD(-0.0192655948011813,2.76646720397296e-15,0.999814401205022)
link_3.SetFlipped(True)
link_3.Initialize(body_64,body_70,False,cA,cB,dA,dB)
link_3.SetName("Coincident7")
exported_items.append(link_3)

link_4 = chrono.ChLinkMateGeneric()
link_4.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.245458448190709,2.51550127212939,0.581880065299065)
cB = chrono.ChVectorD(0.251396618427903,2.51550127212935,0.273710593682706)
dA = chrono.ChVectorD(0.0192655948011815,-3.49083332468477e-15,-0.999814401205022)
dB = chrono.ChVectorD(-0.0192655948011813,2.76646720397296e-15,0.999814401205022)
link_4.Initialize(body_64,body_70,False,cA,cB,dA,dB)
link_4.SetName("Coincident7")
exported_items.append(link_4)


# Mate constraint: Coincident8 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_73 , SW name: M-410iB-300 -1/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_70 , SW name: M-410iB-300 -1/M-410iB-300-07-1 ,  SW ref.type:2 (2)

link_5 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.959094532128875,3.18123885131226,0.363329005097225)
cB = chrono.ChVectorD(-0.0653960042876609,3.01331234559424,0.343587921623675)
dA = chrono.ChVectorD(0.0192655948011819,-3.59261231874797e-15,-0.999814401205022)
dB = chrono.ChVectorD(0.0192655948011813,-2.76646720397296e-15,-0.999814401205022)
link_5.Initialize(body_73,body_70,False,cA,cB,dB)
link_5.SetDistance(0)
link_5.SetName("Coincident8")
exported_items.append(link_5)

link_6 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.959094532128875,3.18123885131226,0.363329005097225)
dA = chrono.ChVectorD(0.0192655948011819,-3.59261231874797e-15,-0.999814401205022)
cB = chrono.ChVectorD(-0.0653960042876609,3.01331234559424,0.343587921623675)
dB = chrono.ChVectorD(0.0192655948011813,-2.76646720397296e-15,-0.999814401205022)
link_6.Initialize(body_73,body_70,False,cA,cB,dA,dB)
link_6.SetName("Coincident8")
exported_items.append(link_6)


# Mate constraint: Coincident9 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_73 , SW name: M-410iB-300 -1/M-410iB-300-06-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_66 , SW name: M-410iB-300 -1/M-410iB-300-08-1 ,  SW ref.type:5 (5)

link_7 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.11653654424522,3.32948602743832,0.36636278217271)
dA = chrono.ChVectorD(0.0192655948011819,-3.59261231874797e-15,-0.999814401205022)
cB = chrono.ChVectorD(1.11711115987576,3.32948602743832,0.336542317842369)
dB = chrono.ChVectorD(0.0192655948011819,-2.84230320855858e-15,-0.999814401205022)
link_7.Initialize(body_73,body_66,False,cA,cB,dA,dB)
link_7.SetName("Coincident9")
exported_items.append(link_7)

link_8 = chrono.ChLinkMateGeneric()
link_8.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.11653654424522,3.32948602743832,0.36636278217271)
cB = chrono.ChVectorD(1.11711115987576,3.32948602743832,0.336542317842369)
dA = chrono.ChVectorD(0.0192655948011819,-3.59261231874797e-15,-0.999814401205022)
dB = chrono.ChVectorD(0.0192655948011819,-2.84230320855858e-15,-0.999814401205022)
link_8.Initialize(body_73,body_66,False,cA,cB,dA,dB)
link_8.SetName("Coincident9")
exported_items.append(link_8)


# Mate constraint: Coincident11 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_64 , SW name: M-410iB-300 -1/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_71 , SW name: M-410iB-300 -1/M-410iB-300-09-1 ,  SW ref.type:2 (2)

link_9 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.0982151051739213,2.72491052060186,0.0850586593867076)
cB = chrono.ChVectorD(1.43289352578048,3.28485914175995,0.114561853616837)
dA = chrono.ChVectorD(0.0192655948011815,-3.49083332468477e-15,-0.999814401205022)
dB = chrono.ChVectorD(0.0192655948011817,-3.49083253824843e-15,-0.999814401205022)
link_9.Initialize(body_64,body_71,False,cA,cB,dB)
link_9.SetDistance(0)
link_9.SetName("Coincident11")
exported_items.append(link_9)

link_10 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.0982151051739213,2.72491052060186,0.0850586593867076)
dA = chrono.ChVectorD(0.0192655948011815,-3.49083332468477e-15,-0.999814401205022)
cB = chrono.ChVectorD(1.43289352578048,3.28485914175995,0.114561853616837)
dB = chrono.ChVectorD(0.0192655948011817,-3.49083253824843e-15,-0.999814401205022)
link_10.Initialize(body_64,body_71,False,cA,cB,dA,dB)
link_10.SetName("Coincident11")
exported_items.append(link_10)


# Mate constraint: Coincident22 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_71 , SW name: M-410iB-300 -1/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_67 , SW name: M-410iB-300 -1/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_11 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.43289352578048,3.28485914175995,0.114561853616837)
cB = chrono.ChVectorD(0.93272446825396,3.10131932553662,0.104924010450315)
dA = chrono.ChVectorD(0.0192655948011817,-3.49083253824843e-15,-0.999814401205022)
dB = chrono.ChVectorD(-0.019265594801182,3.49499787570612e-15,0.999814401205022)
link_11.Initialize(body_71,body_67,False,cA,cB,dB)
link_11.SetDistance(0)
link_11.SetName("Coincident22")
exported_items.append(link_11)

link_12 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.43289352578048,3.28485914175995,0.114561853616837)
dA = chrono.ChVectorD(0.0192655948011817,-3.49083253824843e-15,-0.999814401205022)
cB = chrono.ChVectorD(0.93272446825396,3.10131932553662,0.104924010450315)
dB = chrono.ChVectorD(-0.019265594801182,3.49499787570612e-15,0.999814401205022)
link_12.SetFlipped(True)
link_12.Initialize(body_71,body_67,False,cA,cB,dA,dB)
link_12.SetName("Coincident22")
exported_items.append(link_12)


# Mate constraint: Coincident15 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_73 , SW name: M-410iB-300 -1/M-410iB-300-06-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_68 , SW name: M-410iB-300 -1/M-410iB-300-12-1 ,  SW ref.type:5 (5)

link_13 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(2.16564352035515,1.75730412224227,0.296561497106508)
dA = chrono.ChVectorD(-0.0192655948011819,3.59261231874797e-15,0.999814401205022)
cB = chrono.ChVectorD(2.16588590080449,1.75730412223511,0.283982832151698)
dB = chrono.ChVectorD(0.0192655944539581,-1.61113297942825e-15,-0.999814401211713)
link_13.SetFlipped(True)
link_13.Initialize(body_73,body_68,False,cA,cB,dA,dB)
link_13.SetName("Coincident15")
exported_items.append(link_13)

link_14 = chrono.ChLinkMateGeneric()
link_14.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(2.16564352035515,1.75730412224227,0.296561497106508)
cB = chrono.ChVectorD(2.16588590080449,1.75730412223511,0.283982832151698)
dA = chrono.ChVectorD(-0.0192655948011819,3.59261231874797e-15,0.999814401205022)
dB = chrono.ChVectorD(0.0192655944539581,-1.61113297942825e-15,-0.999814401211713)
link_14.Initialize(body_73,body_68,False,cA,cB,dA,dB)
link_14.SetName("Coincident15")
exported_items.append(link_14)


# Mate constraint: Coincident17 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_70 , SW name: M-410iB-300 -1/M-410iB-300-07-1 ,  SW ref.type:5 (5)
#   Entity 1: C::E name: body_66 , SW name: M-410iB-300 -1/M-410iB-300-08-1 ,  SW ref.type:5 (5)

link_15 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.0636888221355439,3.01331234559424,0.254991368089694)
dA = chrono.ChVectorD(-0.0192655948011813,2.76646720397296e-15,0.999814401205022)
cB = chrono.ChVectorD(-0.0648213886571205,3.01331234559424,0.313767457293333)
dB = chrono.ChVectorD(0.0192655948011819,-2.84230320855858e-15,-0.999814401205022)
link_15.SetFlipped(True)
link_15.Initialize(body_70,body_66,False,cA,cB,dA,dB)
link_15.SetName("Coincident17")
exported_items.append(link_15)

link_16 = chrono.ChLinkMateGeneric()
link_16.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-0.0636888221355439,3.01331234559424,0.254991368089694)
cB = chrono.ChVectorD(-0.0648213886571205,3.01331234559424,0.313767457293333)
dA = chrono.ChVectorD(-0.0192655948011813,2.76646720397296e-15,0.999814401205022)
dB = chrono.ChVectorD(0.0192655948011819,-2.84230320855858e-15,-0.999814401205022)
link_16.Initialize(body_70,body_66,False,cA,cB,dA,dB)
link_16.SetName("Coincident17")
exported_items.append(link_16)


# Mate constraint: Coincident18 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_64 , SW name: M-410iB-300 -1/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_72 , SW name: M-410iB-300 -1/ArmBase-1 ,  SW ref.type:2 (2)

link_17 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.140670357906007,2.04602671615666,0.377403113503883)
cB = chrono.ChVectorD(-0.382669423498732,2.04602671615662,0.37740311343739)
dA = chrono.ChVectorD(-1.89684880012487e-18,-1,3.49144478870991e-15)
dB = chrono.ChVectorD(0,1,0)
link_17.Initialize(body_64,body_72,False,cA,cB,dB)
link_17.SetDistance(0)
link_17.SetName("Coincident18")
exported_items.append(link_17)

link_18 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.140670357906007,2.04602671615666,0.377403113503883)
dA = chrono.ChVectorD(-1.89684880012487e-18,-1,3.49144478870991e-15)
cB = chrono.ChVectorD(-0.382669423498732,2.04602671615662,0.37740311343739)
dB = chrono.ChVectorD(0,1,0)
link_18.SetFlipped(True)
link_18.Initialize(body_64,body_72,False,cA,cB,dA,dB)
link_18.SetName("Coincident18")
exported_items.append(link_18)


# Mate constraint: Concentric1 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_64 , SW name: M-410iB-300 -1/M-410iB-300-02-1 ,  SW ref.type:1 (1)
#   Entity 1: C::E name: body_72 , SW name: M-410iB-300 -1/ArmBase-1 ,  SW ref.type:1 (1)

link_19 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.140670357906007,2.04755071615666,0.377403113503883)
dA = chrono.ChVectorD(1.89684880012487e-18,1,-3.49144478870991e-15)
cB = chrono.ChVectorD(-0.140670357955037,2.04602671615662,0.37740311343739)
dB = chrono.ChVectorD(0,1,0)
link_19.Initialize(body_64,body_72,False,cA,cB,dA,dB)
link_19.SetName("Concentric1")
exported_items.append(link_19)

link_20 = chrono.ChLinkMateGeneric()
link_20.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-0.140670357906007,2.04755071615666,0.377403113503883)
cB = chrono.ChVectorD(-0.140670357955037,2.04602671615662,0.37740311343739)
dA = chrono.ChVectorD(1.89684880012487e-18,1,-3.49144478870991e-15)
dB = chrono.ChVectorD(0,1,0)
link_20.Initialize(body_64,body_72,False,cA,cB,dA,dB)
link_20.SetName("Concentric1")
exported_items.append(link_20)


# Mate constraint: Coincident21 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_73 , SW name: M-410iB-300 -1/M-410iB-300-06-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_68 , SW name: M-410iB-300 -1/M-410iB-300-12-1 ,  SW ref.type:4 (4)

link_21 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.42904771347242,2.82931662753848,0.352380902690323)
cB = chrono.ChVectorD(2.41924674160339,1.59830274717827,0.371461215308074)
dA = chrono.ChVectorD(-0.0192655948011819,3.59261231874797e-15,0.999814401205022)
dB = chrono.ChVectorD(0.0192655946275701,-2.55098369818665e-15,-0.999814401208368)
link_21.Initialize(body_73,body_68,False,cA,cB,dB)
link_21.SetDistance(0)
link_21.SetName("Coincident21")
exported_items.append(link_21)

link_22 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.42904771347242,2.82931662753848,0.352380902690323)
dA = chrono.ChVectorD(-0.0192655948011819,3.59261231874797e-15,0.999814401205022)
cB = chrono.ChVectorD(2.41924674160339,1.59830274717827,0.371461215308074)
dB = chrono.ChVectorD(0.0192655946275701,-2.55098369818665e-15,-0.999814401208368)
link_22.SetFlipped(True)
link_22.Initialize(body_73,body_68,False,cA,cB,dA,dB)
link_22.SetName("Coincident21")
exported_items.append(link_22)


# Mate constraint: Coincident25 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_65 , SW name: M-410iB-300 -1/M-410iB-300-03-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_63 , SW name: M-410iB-300 -1/M-410iB-300-05-1 ,  SW ref.type:2 (2)

link_23 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.42560264784345,2.82931662753848,0.531167297010769)
cB = chrono.ChVectorD(1.42560264784345,2.82931662753848,0.531167297010769)
dA = chrono.ChVectorD(-0.0192655948011811,3.29030050554087e-15,0.999814401205022)
dB = chrono.ChVectorD(0.0192655948011811,-3.26952007134731e-15,-0.999814401205022)
link_23.Initialize(body_65,body_63,False,cA,cB,dB)
link_23.SetDistance(0)
link_23.SetName("Coincident25")
exported_items.append(link_23)

link_24 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.42560264784345,2.82931662753848,0.531167297010769)
dA = chrono.ChVectorD(-0.0192655948011811,3.29030050554087e-15,0.999814401205022)
cB = chrono.ChVectorD(1.42560264784345,2.82931662753848,0.531167297010769)
dB = chrono.ChVectorD(0.0192655948011811,-3.26952007134731e-15,-0.999814401205022)
link_24.SetFlipped(True)
link_24.Initialize(body_65,body_63,False,cA,cB,dA,dB)
link_24.SetName("Coincident25")
exported_items.append(link_24)


# Mate constraint: Concentric2 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_73 , SW name: M-410iB-300 -1/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_71 , SW name: M-410iB-300 -1/M-410iB-300-09-1 ,  SW ref.type:2 (2)

link_25 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.43256368456179,2.82931662753848,0.169914772490354)
dA = chrono.ChVectorD(-0.0192655948011819,3.59261231874797e-15,0.999814401205022)
cB = chrono.ChVectorD(1.43375235252151,2.82931662754992,0.108227223725161)
dB = chrono.ChVectorD(-0.0192655948011817,3.49083253824843e-15,0.999814401205022)
link_25.Initialize(body_73,body_71,False,cA,cB,dA,dB)
link_25.SetName("Concentric2")
exported_items.append(link_25)

link_26 = chrono.ChLinkMateGeneric()
link_26.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.43256368456179,2.82931662753848,0.169914772490354)
cB = chrono.ChVectorD(1.43375235252151,2.82931662754992,0.108227223725161)
dA = chrono.ChVectorD(-0.0192655948011819,3.59261231874797e-15,0.999814401205022)
dB = chrono.ChVectorD(-0.0192655948011817,3.49083253824843e-15,0.999814401205022)
link_26.Initialize(body_73,body_71,False,cA,cB,dA,dB)
link_26.SetName("Concentric2")
exported_items.append(link_26)


# Mate constraint: Concentric3 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_71 , SW name: M-410iB-300 -1/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_67 , SW name: M-410iB-300 -1/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_27 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.932731364619317,3.10131932552868,0.104566114040552)
dA = chrono.ChVectorD(-0.0192655948011817,3.49083253824843e-15,0.999814401205022)
cB = chrono.ChVectorD(0.933550499896655,3.10131932553662,0.0620559681842487)
dB = chrono.ChVectorD(-0.019265594801182,3.49499787570612e-15,0.999814401205022)
link_27.Initialize(body_71,body_67,False,cA,cB,dA,dB)
link_27.SetName("Concentric3")
exported_items.append(link_27)

link_28 = chrono.ChLinkMateGeneric()
link_28.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.932731364619317,3.10131932552868,0.104566114040552)
cB = chrono.ChVectorD(0.933550499896655,3.10131932553662,0.0620559681842487)
dA = chrono.ChVectorD(-0.0192655948011817,3.49083253824843e-15,0.999814401205022)
dB = chrono.ChVectorD(-0.019265594801182,3.49499787570612e-15,0.999814401205022)
link_28.Initialize(body_71,body_67,False,cA,cB,dA,dB)
link_28.SetName("Concentric3")
exported_items.append(link_28)


# Mate constraint: Concentric4 [MateConcentric] type:1 align:1 flip:False
#   Entity 0: C::E name: body_71 , SW name: M-410iB-300 -1/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_69 , SW name: M-410iB-300 -1/M-410iB-300-11-1 ,  SW ref.type:2 (2)

link_29 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.93354556942464,3.09931392485038,0.12385097422841)
dA = chrono.ChVectorD(-0.0192655948011817,3.49083253824843e-15,0.999814401205022)
cB = chrono.ChVectorD(1.93161064936769,3.09931392483892,0.224266296594882)
dB = chrono.ChVectorD(0.0192655948011819,-3.48505946323731e-15,-0.999814401205022)
link_29.SetFlipped(True)
link_29.Initialize(body_71,body_69,False,cA,cB,dA,dB)
link_29.SetName("Concentric4")
exported_items.append(link_29)

link_30 = chrono.ChLinkMateGeneric()
link_30.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.93354556942464,3.09931392485038,0.12385097422841)
cB = chrono.ChVectorD(1.93161064936769,3.09931392483892,0.224266296594882)
dA = chrono.ChVectorD(-0.0192655948011817,3.49083253824843e-15,0.999814401205022)
dB = chrono.ChVectorD(0.0192655948011819,-3.48505946323731e-15,-0.999814401205022)
link_30.Initialize(body_71,body_69,False,cA,cB,dA,dB)
link_30.SetName("Concentric4")
exported_items.append(link_30)


# Mate constraint: Concentric6 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_65 , SW name: M-410iB-300 -1/M-410iB-300-03-1 ,  SW ref.type:1 (1)
#   Entity 1: C::E name: body_63 , SW name: M-410iB-300 -1/M-410iB-300-05-1 ,  SW ref.type:2 (2)

link_31 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.42560264784345,2.82931662753848,0.531167297010769)
dA = chrono.ChVectorD(-0.0192655948011811,3.29030050554087e-15,0.999814401205022)
cB = chrono.ChVectorD(1.42560264784345,2.82931662753848,0.531167297010769)
dB = chrono.ChVectorD(-0.0192655948011811,3.26952007134731e-15,0.999814401205022)
link_31.Initialize(body_65,body_63,False,cA,cB,dA,dB)
link_31.SetName("Concentric6")
exported_items.append(link_31)

link_32 = chrono.ChLinkMateGeneric()
link_32.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.42560264784345,2.82931662753848,0.531167297010769)
cB = chrono.ChVectorD(1.42560264784345,2.82931662753848,0.531167297010769)
dA = chrono.ChVectorD(-0.0192655948011811,3.29030050554087e-15,0.999814401205022)
dB = chrono.ChVectorD(-0.0192655948011811,3.26952007134731e-15,0.999814401205022)
link_32.Initialize(body_65,body_63,False,cA,cB,dA,dB)
link_32.SetName("Concentric6")
exported_items.append(link_32)


# Mate constraint: Concentric7 [MateConcentric] type:1 align:1 flip:False
#   Entity 0: C::E name: body_64 , SW name: M-410iB-300 -1/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_62 , SW name: M-410iB-300 -1/M-410iB-300-04-1 ,  SW ref.type:2 (2)

link_33 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.245364838814431,2.78049691677861,0.586919203507774)
dA = chrono.ChVectorD(0.0192655948011815,-3.49083332468477e-15,-0.999814401205022)
cB = chrono.ChVectorD(0.245799230580869,2.78049691677857,0.564375845846981)
dB = chrono.ChVectorD(-0.0192655948011817,3.49650505729958e-15,0.999814401205022)
link_33.SetFlipped(True)
link_33.Initialize(body_64,body_62,False,cA,cB,dA,dB)
link_33.SetName("Concentric7")
exported_items.append(link_33)

link_34 = chrono.ChLinkMateGeneric()
link_34.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.245364838814431,2.78049691677861,0.586919203507774)
cB = chrono.ChVectorD(0.245799230580869,2.78049691677857,0.564375845846981)
dA = chrono.ChVectorD(0.0192655948011815,-3.49083332468477e-15,-0.999814401205022)
dB = chrono.ChVectorD(-0.0192655948011817,3.49650505729958e-15,0.999814401205022)
link_34.Initialize(body_64,body_62,False,cA,cB,dA,dB)
link_34.SetName("Concentric7")
exported_items.append(link_34)


# Mate constraint: Concentric8 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_69 , SW name: M-410iB-300 -1/M-410iB-300-11-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_68 , SW name: M-410iB-300 -1/M-410iB-300-12-1 ,  SW ref.type:2 (2)

link_35 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(2.66685788251879,2.02730143185251,0.238433901357837)
dA = chrono.ChVectorD(0.0192655948011819,-3.48505946323731e-15,-0.999814401205022)
cB = chrono.ChVectorD(2.66567223927972,2.02730143185251,0.299964479435062)
dB = chrono.ChVectorD(0.019265594801182,-3.49083441694505e-15,-0.999814401205022)
link_35.Initialize(body_69,body_68,False,cA,cB,dA,dB)
link_35.SetName("Concentric8")
exported_items.append(link_35)

link_36 = chrono.ChLinkMateGeneric()
link_36.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(2.66685788251879,2.02730143185251,0.238433901357837)
cB = chrono.ChVectorD(2.66567223927972,2.02730143185251,0.299964479435062)
dA = chrono.ChVectorD(0.0192655948011819,-3.48505946323731e-15,-0.999814401205022)
dB = chrono.ChVectorD(0.019265594801182,-3.49083441694505e-15,-0.999814401205022)
link_36.Initialize(body_69,body_68,False,cA,cB,dA,dB)
link_36.SetName("Concentric8")
exported_items.append(link_36)


# Mate constraint: Concentric9 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_65 , SW name: M-410iB-300 -1/M-410iB-300-03-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_70 , SW name: M-410iB-300 -1/M-410iB-300-07-1 ,  SW ref.type:2 (2)

link_37 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.246995641010696,2.51550127212935,0.502105338122748)
dA = chrono.ChVectorD(0.0192655948011811,-3.29030050554087e-15,-0.999814401205022)
cB = chrono.ChVectorD(0.248043109340824,2.51550127212935,0.447745535994871)
dB = chrono.ChVectorD(0.0192655948011813,-2.76646720397296e-15,-0.999814401205022)
link_37.Initialize(body_65,body_70,False,cA,cB,dA,dB)
link_37.SetName("Concentric9")
exported_items.append(link_37)

link_38 = chrono.ChLinkMateGeneric()
link_38.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.246995641010696,2.51550127212935,0.502105338122748)
cB = chrono.ChVectorD(0.248043109340824,2.51550127212935,0.447745535994871)
dA = chrono.ChVectorD(0.0192655948011811,-3.29030050554087e-15,-0.999814401205022)
dB = chrono.ChVectorD(0.0192655948011813,-2.76646720397296e-15,-0.999814401205022)
link_38.Initialize(body_65,body_70,False,cA,cB,dA,dB)
link_38.SetName("Concentric9")
exported_items.append(link_38)


# Mate constraint: Coincident33 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_62 , SW name: M-410iB-300 -1/M-410iB-300-04-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_63 , SW name: M-410iB-300 -1/M-410iB-300-05-1 ,  SW ref.type:4 (4)

link_39 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.244076732280884,2.78049691677857,0.653767251829919)
cB = chrono.ChVectorD(0.55470784029864,2.79336243660645,0.659752855810517)
dA = chrono.ChVectorD(0.0413665338061261,-0.999143720650007,0.000797098819222029)
dB = chrono.ChVectorD(0.0413665338061262,-0.999143720650007,0.000797098819221778)
link_39.Initialize(body_62,body_63,False,cA,cB,dB)
link_39.SetDistance(0)
link_39.SetName("Coincident33")
exported_items.append(link_39)

link_40 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.244076732280884,2.78049691677857,0.653767251829919)
dA = chrono.ChVectorD(0.0413665338061261,-0.999143720650007,0.000797098819222029)
cB = chrono.ChVectorD(0.55470784029864,2.79336243660645,0.659752855810517)
dB = chrono.ChVectorD(0.0413665338061262,-0.999143720650007,0.000797098819221778)
link_40.Initialize(body_62,body_63,False,cA,cB,dA,dB)
link_40.SetName("Coincident33")
exported_items.append(link_40)


# Mate constraint: Coincident34 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_62 , SW name: M-410iB-300 -1/M-410iB-300-04-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_63 , SW name: M-410iB-300 -1/M-410iB-300-05-1 ,  SW ref.type:4 (4)

link_41 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.244076732280884,2.78049691677857,0.653767251829919)
cB = chrono.ChVectorD(0.55470784029864,2.79336243660645,0.659752855810517)
dA = chrono.ChVectorD(0.0192655948011817,-3.49650505729958e-15,-0.999814401205022)
dB = chrono.ChVectorD(-0.0192655948011811,3.26952007134731e-15,0.999814401205022)
link_41.Initialize(body_62,body_63,False,cA,cB,dB)
link_41.SetDistance(0)
link_41.SetName("Coincident34")
exported_items.append(link_41)

link_42 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.244076732280884,2.78049691677857,0.653767251829919)
dA = chrono.ChVectorD(0.0192655948011817,-3.49650505729958e-15,-0.999814401205022)
cB = chrono.ChVectorD(0.55470784029864,2.79336243660645,0.659752855810517)
dB = chrono.ChVectorD(-0.0192655948011811,3.26952007134731e-15,0.999814401205022)
link_42.SetFlipped(True)
link_42.Initialize(body_62,body_63,False,cA,cB,dA,dB)
link_42.SetName("Coincident34")
exported_items.append(link_42)


# Mate constraint: Concentric10 [MateConcentric] type:1 align:1 flip:False
#   Entity 0: C::E name: body_64 , SW name: M-410iB-300 -1/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_67 , SW name: M-410iB-300 -1/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_43 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.246002848334368,2.78749692402105,0.0822109120719271)
dA = chrono.ChVectorD(-0.0192655948011815,3.49083332468477e-15,0.999814401205022)
cB = chrono.ChVectorD(-0.246002848354475,2.78749692403041,0.0822109120637631)
dB = chrono.ChVectorD(0.019265594801182,-3.49499787570612e-15,-0.999814401205022)
link_43.SetFlipped(True)
link_43.Initialize(body_64,body_67,False,cA,cB,dA,dB)
link_43.SetName("Concentric10")
exported_items.append(link_43)

link_44 = chrono.ChLinkMateGeneric()
link_44.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-0.246002848334368,2.78749692402105,0.0822109120719271)
cB = chrono.ChVectorD(-0.246002848354475,2.78749692403041,0.0822109120637631)
dA = chrono.ChVectorD(-0.0192655948011815,3.49083332468477e-15,0.999814401205022)
dB = chrono.ChVectorD(0.019265594801182,-3.49499787570612e-15,-0.999814401205022)
link_44.Initialize(body_64,body_67,False,cA,cB,dA,dB)
link_44.SetName("Concentric10")
exported_items.append(link_44)


# Mate constraint: Coincident35 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_69 , SW name: M-410iB-300 -1/M-410iB-300-11-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_68 , SW name: M-410iB-300 -1/M-410iB-300-12-1 ,  SW ref.type:2 (2)

link_45 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(2.66662299638698,2.02730143185251,0.250623638537328)
cB = chrono.ChVectorD(2.52785975726118,2.22592296168595,0.247949785983419)
dA = chrono.ChVectorD(-0.0192655948011819,3.48505946323731e-15,0.999814401205022)
dB = chrono.ChVectorD(0.0192655944539581,-1.61113297942825e-15,-0.999814401211713)
link_45.Initialize(body_69,body_68,False,cA,cB,dB)
link_45.SetDistance(0)
link_45.SetName("Coincident35")
exported_items.append(link_45)

link_46 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(2.66662299638698,2.02730143185251,0.250623638537328)
dA = chrono.ChVectorD(-0.0192655948011819,3.48505946323731e-15,0.999814401205022)
cB = chrono.ChVectorD(2.52785975726118,2.22592296168595,0.247949785983419)
dB = chrono.ChVectorD(0.0192655944539581,-1.61113297942825e-15,-0.999814401211713)
link_46.SetFlipped(True)
link_46.Initialize(body_69,body_68,False,cA,cB,dA,dB)
link_46.SetName("Coincident35")
exported_items.append(link_46)


# Mate constraint: Coincident36 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_73 , SW name: M-410iB-300 -1/M-410iB-300-06-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_66 , SW name: M-410iB-300 -1/M-410iB-300-08-1 ,  SW ref.type:4 (4)

link_47 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.42962568135461,2.82931662753848,0.32238646867412)
cB = chrono.ChVectorD(-0.0644327245476014,3.01331234559424,0.293597201563423)
dA = chrono.ChVectorD(-0.0192655948011819,3.59261231874797e-15,0.999814401205022)
dB = chrono.ChVectorD(-0.0192655948011819,2.84230320855858e-15,0.999814401205022)
link_47.Initialize(body_73,body_66,False,cA,cB,dB)
link_47.SetDistance(0)
link_47.SetName("Coincident36")
exported_items.append(link_47)

link_48 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.42962568135461,2.82931662753848,0.32238646867412)
dA = chrono.ChVectorD(-0.0192655948011819,3.59261231874797e-15,0.999814401205022)
cB = chrono.ChVectorD(-0.0644327245476014,3.01331234559424,0.293597201563423)
dB = chrono.ChVectorD(-0.0192655948011819,2.84230320855858e-15,0.999814401205022)
link_48.Initialize(body_73,body_66,False,cA,cB,dA,dB)
link_48.SetName("Coincident36")
exported_items.append(link_48)


# Mate constraint: Coincident37 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_71 , SW name: M-410iB-300 -1/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_69 , SW name: M-410iB-300 -1/M-410iB-300-11-1 ,  SW ref.type:2 (2)

link_49 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.43196866163646,3.28485914175995,0.162558943761085)
cB = chrono.ChVectorD(1.93261380888899,3.09931392483892,0.172205960724137)
dA = chrono.ChVectorD(-0.0192655948011817,3.49083253824843e-15,0.999814401205022)
dB = chrono.ChVectorD(0.0192655948011819,-3.48505946323731e-15,-0.999814401205022)
link_49.Initialize(body_71,body_69,False,cA,cB,dB)
link_49.SetDistance(0)
link_49.SetName("Coincident37")
exported_items.append(link_49)

link_50 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.43196866163646,3.28485914175995,0.162558943761085)
dA = chrono.ChVectorD(-0.0192655948011817,3.49083253824843e-15,0.999814401205022)
cB = chrono.ChVectorD(1.93261380888899,3.09931392483892,0.172205960724137)
dB = chrono.ChVectorD(0.0192655948011819,-3.48505946323731e-15,-0.999814401205022)
link_50.SetFlipped(True)
link_50.Initialize(body_71,body_69,False,cA,cB,dA,dB)
link_50.SetName("Coincident37")
exported_items.append(link_50)


# Mate constraint: Coincident38 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_65 , SW name: M-410iB-300 -1/M-410iB-300-03-1 ,  SW ref.type:4 (4)
#   Entity 1: C::E name: body_73 , SW name: M-410iB-300 -1/M-410iB-300-06-1 ,  SW ref.type:4 (4)

link_51 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.250318370150834,2.51550127212935,0.329667763269899)
cB = chrono.ChVectorD(1.42904771351058,2.82931662753848,0.352380900710269)
dA = chrono.ChVectorD(-0.0192655948011811,3.29030050554087e-15,0.999814401205022)
dB = chrono.ChVectorD(0.0192655948011819,-3.59261231874797e-15,-0.999814401205022)
link_51.Initialize(body_65,body_73,False,cA,cB,dB)
link_51.SetDistance(0)
link_51.SetName("Coincident38")
exported_items.append(link_51)

link_52 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.250318370150834,2.51550127212935,0.329667763269899)
dA = chrono.ChVectorD(-0.0192655948011811,3.29030050554087e-15,0.999814401205022)
cB = chrono.ChVectorD(1.42904771351058,2.82931662753848,0.352380900710269)
dB = chrono.ChVectorD(0.0192655948011819,-3.59261231874797e-15,-0.999814401205022)
link_52.SetFlipped(True)
link_52.Initialize(body_65,body_73,False,cA,cB,dA,dB)
link_52.SetName("Coincident38")
exported_items.append(link_52)

