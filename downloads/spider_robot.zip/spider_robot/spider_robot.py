# Chrono::Engine Python script from SolidWorks 
# Assembly: C:\Users\Alessandro\Desktop\robot_fanucM410IB-300\SPIDER_ROBOT.SLDASM


import ChronoEngine_python_core as chrono 
import builtins 

shapes_dir = 'spider_robot_shapes/' 

if hasattr(builtins, 'exported_system_relpath'): 
    shapes_dir = builtins.exported_system_relpath + shapes_dir 

exported_items = [] 

body_0= chrono.ChBodyAuxRef()
body_0.SetName('ground')
body_0.SetBodyFixed(True)
exported_items.append(body_0)

# Rigid body part
body_1= chrono.ChBodyAuxRef()
body_1.SetName('M-410iB-300 -9/M-410iB-300-12-1')
body_1.SetPos(chrono.ChVectorD(-4.07967425969663,1.53452994138092,0.579942165862929))
body_1.SetRot(chrono.ChQuaternionD(-0.0412727252884181,-0.000468569478897146,0.999147807992026,1.93556340954814e-05))
body_1.SetMass(16.1636065115335)
body_1.SetInertiaXX(chrono.ChVectorD(0.270733820597613,0.400877809867468,0.427371867141468))
body_1.SetInertiaXY(chrono.ChVectorD(0.0574221068634287,0.0377110505251339,-0.0625539343672037))
body_1.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0294847451383035,0.131793864973377,-0.039955675141979),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_1_1_shape = chrono.ChObjShapeFile() 
body_1_1_shape.SetFilename(shapes_dir +'body_1_1.obj') 
body_1_1_level = chrono.ChAssetLevel() 
body_1_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_1_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_1_1_level.GetAssets().push_back(body_1_1_shape) 
body_1.GetAssets().push_back(body_1_1_level) 

# Collision shapes 
body_1.GetCollisionModel().ClearModel()
mr = chrono.ChMatrix33D()
mr[0,0]=0; mr[1,0]=0; mr[2,0]=-1 
mr[0,1]=0; mr[1,1]=-1; mr[2,1]=0 
mr[0,2]=-1; mr[1,2]=0; mr[2,2]=0 
body_1.GetCollisionModel().AddCylinder(0.0891514706007005,0.0891514706007005,0.0737653824400992,chrono.ChVectorD(4.57739150408006E-17,0.0737653824400992,0),mr)
body_1.GetCollisionModel().BuildModel()
body_1.SetCollide(True)

exported_items.append(body_1)



# Rigid body part
body_2= chrono.ChBodyAuxRef()
body_2.SetName('M-410iB-300 -9/ArmBase-1')
body_2.SetPos(chrono.ChVectorD(-1.50067035795504,1.75770592148926,0.377403113437384))
body_2.SetRot(chrono.ChQuaternionD(1.11022302462516e-16,-3.10973640124651e-17,1,-1.77935638377312e-15))
body_2.SetMass(29.4636133436255)
body_2.SetInertiaXX(chrono.ChVectorD(0.754351795243641,1.45825924231452,0.754351795243641))
body_2.SetInertiaXY(chrono.ChVectorD(-4.2125923912256e-17,-2.6454533008646e-17,-2.51327146062721e-15))
body_2.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-9.77354995986777e-18,0.231605672678633,-6.24094154063845e-18),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_2_1_shape = chrono.ChObjShapeFile() 
body_2_1_shape.SetFilename(shapes_dir +'body_2_1.obj') 
body_2_1_level = chrono.ChAssetLevel() 
body_2_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_2_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_2_1_level.GetAssets().push_back(body_2_1_shape) 
body_2.GetAssets().push_back(body_2_1_level) 

# Auxiliary marker (coordinate system feature)
marker_2_1 =chrono.ChMarker()
marker_2_1.SetName('marker_M1_B')
body_2.AddMarker(marker_2_1)
marker_2_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.50067035795504,1.75770592148926,0.377403113437384),chrono.ChQuaternionD(-0.499999999999999,0.500000000000001,-0.500000000000001,-0.499999999999999)))

exported_items.append(body_2)



# Rigid body part
body_3= chrono.ChBodyAuxRef()
body_3.SetName('M-410iB-300 -9/M-410iB-300-02-1')
body_3.SetPos(chrono.ChVectorD(-1.50067035795504,2.15049691615662,0.377403113437382))
body_3.SetRot(chrono.ChQuaternionD(-0.0412727298270154,-2.39528823459568e-17,0.99914791786433,-1.7763160888523e-15))
body_3.SetMass(286.960740367602)
body_3.SetInertiaXX(chrono.ChVectorD(20.3261470881377,23.3528740040787,23.2169905170889))
body_3.SetInertiaXY(chrono.ChVectorD(5.60160689862223,-0.500091644770925,-0.179388605538523))
body_3.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.175382085214385,0.199890816413736,-0.00351536323719578),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_3_1_shape = chrono.ChObjShapeFile() 
body_3_1_shape.SetFilename(shapes_dir +'body_3_1.obj') 
body_3_1_level = chrono.ChAssetLevel() 
body_3_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_3_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_3_1_level.GetAssets().push_back(body_3_1_shape) 
body_3.GetAssets().push_back(body_3_1_level) 

# Auxiliary marker (coordinate system feature)
marker_3_1 =chrono.ChMarker()
marker_3_1.SetName('marker_M1_A')
body_3.AddMarker(marker_3_1)
marker_3_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.50067035795504,2.15049691615662,0.377403113437382),chrono.ChQuaternionD(0.478937594018657,-0.478937594018658,0.520210323845674,0.520210323845672)))

# Auxiliary marker (coordinate system feature)
marker_3_2 =chrono.ChMarker()
marker_3_2.SetName('marker_M2_B')
body_3.AddMarker(marker_3_2)
marker_3_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.87878486024742,2.51549691615663,0.537132331666721),chrono.ChQuaternionD(-0.0412727298270154,-2.39528823459568E-17,0.99914791786433,-1.7763160888523E-15)))

exported_items.append(body_3)



# Rigid body part
body_4= chrono.ChBodyAuxRef()
body_4.SetName('M-410iB-300 -9/M-410iB-300-03-1')
body_4.SetPos(chrono.ChVectorD(-1.88880804908083,2.51550127212935,0.415974224708171))
body_4.SetRot(chrono.ChQuaternionD(-0.0319545439404119,-0.632366290411082,0.773569283596727,0.0261217409246416))
body_4.SetMass(72.2394925421727)
body_4.SetInertiaXX(chrono.ChVectorD(1.40287854682595,10.9514973454794,11.2634766916778))
body_4.SetInertiaXY(chrono.ChVectorD(1.87720647579531,0.783602183259728,-0.127372995689095))
body_4.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.0436192441530501,0.531901199956275,-0.00110013226020073),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_4_1_shape = chrono.ChObjShapeFile() 
body_4_1_shape.SetFilename(shapes_dir +'body_4_1.obj') 
body_4_1_level = chrono.ChAssetLevel() 
body_4_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_4_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_4_1_level.GetAssets().push_back(body_4_1_shape) 
body_4.GetAssets().push_back(body_4_1_level) 

# Auxiliary marker (coordinate system feature)
marker_4_1 =chrono.ChMarker()
marker_4_1.SetName('marker_M2_A')
body_4.AddMarker(marker_4_1)
marker_4_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.87552911202723,2.51550127212935,0.57643105933806),chrono.ChQuaternionD(-0.041066134854201,0.0998455940054075,0.994146578292323,-0.00412441456577647)))

# Auxiliary marker (coordinate system feature)
marker_4_2 =chrono.ChMarker()
marker_4_2.SetName('marker_M3_B')
body_4.AddMarker(marker_4_2)
marker_4_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-3.06708905223563,2.75811166841886,0.675041065437937),chrono.ChQuaternionD(-0.041066134854201,0.0998455940054075,0.994146578292323,-0.00412441456577647)))

exported_items.append(body_4)



# Rigid body part
body_5= chrono.ChBodyAuxRef()
body_5.SetName('M-410iB-300 -9/M-410iB-300-06-1')
body_5.SetPos(chrono.ChVectorD(-3.08455315977265,2.75811166841885,0.464012471527217))
body_5.SetRot(chrono.ChQuaternionD(-0.0366164450839617,-0.461025460250217,0.886426582844683,0.0190440063218589))
body_5.SetMass(57.487443257986)
body_5.SetInertiaXX(chrono.ChVectorD(9.2600016804482,4.0019522848551,12.6893237121296))
body_5.SetInertiaXY(chrono.ChVectorD(-5.2493241443179,-0.644943244770499,-0.949887858884848))
body_5.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.216990574023306,0.112589145111018,-0.097224117310279),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_5_1_shape = chrono.ChObjShapeFile() 
body_5_1_shape.SetFilename(shapes_dir +'body_5_1.obj') 
body_5_1_level = chrono.ChAssetLevel() 
body_5_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_5_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_5_1_level.GetAssets().push_back(body_5_1_shape) 
body_5.GetAssets().push_back(body_5_1_level) 

# Auxiliary marker (coordinate system feature)
marker_5_1 =chrono.ChMarker()
marker_5_1.SetName('marker_M3_A')
body_5.AddMarker(marker_5_1)
marker_5_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-3.07135713256595,2.75811166324713,0.623467370623119),chrono.ChQuaternionD(-0.0396174502701613,0.280123903774525,0.959076201512031,-0.011571337928912)))

exported_items.append(body_5)



# Rigid body part
body_6= chrono.ChBodyAuxRef()
body_6.SetName('M-410iB-300 -9/M-410iB-300-04-1')
body_6.SetPos(chrono.ChVectorD(-1.9112185542406,2.78048238827908,0.154616112714263))
body_6.SetRot(chrono.ChQuaternionD(0.515318353824204,0.52505671720601,-0.47443374577748,0.483399481584652))
body_6.SetMass(1.58709182620022)
body_6.SetInertiaXX(chrono.ChVectorD(0.112490505154964,0.112417280652057,0.000998085946496919))
body_6.SetInertiaXY(chrono.ChVectorD(4.46219075106967e-06,-8.52197416889094e-05,-0.00105743461725763))
body_6.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.002504718931018,0.259643195204338,6.66879538413068e-09),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_6_1_shape = chrono.ChObjShapeFile() 
body_6_1_shape.SetFilename(shapes_dir +'body_6_1.obj') 
body_6_1_level = chrono.ChAssetLevel() 
body_6_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_6_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_6_1_level.GetAssets().push_back(body_6_1_shape) 
body_6.GetAssets().push_back(body_6_1_level) 

exported_items.append(body_6)



# Rigid body part
body_7= chrono.ChBodyAuxRef()
body_7.SetName('M-410iB-300 -9/M-410iB-300-05-1')
body_7.SetPos(chrono.ChVectorD(-2.23611485821017,2.77437870841747,0.181503577989966))
body_7.SetRot(chrono.ChQuaternionD(0.0289097831045671,0.713086228370467,-0.699860409425343,-0.0294561142756589))
body_7.SetMass(44.264758578016)
body_7.SetInertiaXX(chrono.ChVectorD(0.420124912385258,2.77592729192813,2.76548569075428))
body_7.SetInertiaXY(chrono.ChVectorD(-0.0484362735024024,0.0533450810289393,0.00194028329366022))
body_7.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-5.19600690940307e-06,0.410805913274014,-0.00264008387504332),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_7_1_shape = chrono.ChObjShapeFile() 
body_7_1_shape.SetFilename(shapes_dir +'body_7_1.obj') 
body_7_1_level = chrono.ChAssetLevel() 
body_7_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_7_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_7_1_level.GetAssets().push_back(body_7_1_shape) 
body_7.GetAssets().push_back(body_7_1_level) 

exported_items.append(body_7)



# Rigid body part
body_8= chrono.ChBodyAuxRef()
body_8.SetName('M-410iB-300 -9/M-410iB-300-09-1')
body_8.SetPos(chrono.ChVectorD(-3.06068331152684,2.75811166841881,0.752445218599795))
body_8.SetRot(chrono.ChQuaternionD(-0.0412727252885811,-0.000468561066093716,0.999147807995971,1.93552865804904e-05))
body_8.SetMass(8.44776262879024)
body_8.SetInertiaXX(chrono.ChVectorD(0.114982298903477,0.723331728155272,0.823884312212851))
body_8.SetInertiaXY(chrono.ChVectorD(-0.00519662652260742,-0.0591077417070737,-0.00184089226659356))
body_8.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.00309747019490024,0.11726872541838,-0.0225919700688117),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_8_1_shape = chrono.ChObjShapeFile() 
body_8_1_shape.SetFilename(shapes_dir +'body_8_1.obj') 
body_8_1_level = chrono.ChAssetLevel() 
body_8_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_8_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_8_1_level.GetAssets().push_back(body_8_1_shape) 
body_8.GetAssets().push_back(body_8_1_level) 

exported_items.append(body_8)



# Rigid body part
body_9= chrono.ChBodyAuxRef()
body_9.SetName('M-410iB-300 -9/M-410iB-300-08-1')
body_9.SetPos(chrono.ChVectorD(-1.5638039494725,3.00995602354017,0.455658029064815))
body_9.SetRot(chrono.ChQuaternionD(-0.0319960429220257,-0.631135343417726,0.77457390871473,0.0260708930553924))
body_9.SetMass(7.16874140056196)
body_9.SetInertiaXX(chrono.ChVectorD(0.0717801649549737,1.02988843373916,1.09908804347467))
body_9.SetInertiaXY(chrono.ChVectorD(0.199483959762215,-0.0010063885817514,-0.00229075850811439))
body_9.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0995028745288738,0.617303418169042,1.66091348067148e-08),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_9_1_shape = chrono.ChObjShapeFile() 
body_9_1_shape.SetFilename(shapes_dir +'body_9_1.obj') 
body_9_1_level = chrono.ChAssetLevel() 
body_9_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_9_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_9_1_level.GetAssets().push_back(body_9_1_shape) 
body_9.GetAssets().push_back(body_9_1_level) 

exported_items.append(body_9)



# Rigid body part
body_10= chrono.ChBodyAuxRef()
body_10.SetName('M-410iB-300 -9/M-410iB-300-10-1')
body_10.SetPos(chrono.ChVectorD(-1.3636538381236,2.78749692402103,0.687190186274236))
body_10.SetRot(chrono.ChQuaternionD(-0.0319622275946809,-0.632138678339361,0.773755292789647,0.0261123387416676))
body_10.SetMass(2.24487855545089)
body_10.SetInertiaXX(chrono.ChVectorD(0.0179735699467435,0.411513202899812,0.428952544587403))
body_10.SetInertiaXY(chrono.ChVectorD(0.0835568878991346,-7.20049407702643e-06,-3.53813109576148e-05))
body_10.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-7.01342378264397e-15,0.610001635976697,-2.13860676946225e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_10_1_shape = chrono.ChObjShapeFile() 
body_10_1_shape.SetFilename(shapes_dir +'body_10_1.obj') 
body_10_1_level = chrono.ChAssetLevel() 
body_10_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_10_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_10_1_level.GetAssets().push_back(body_10_1_shape) 
body_10.GetAssets().push_back(body_10_1_level) 

exported_items.append(body_10)



# Rigid body part
body_11= chrono.ChBodyAuxRef()
body_11.SetName('M-410iB-300 -9/M-410iB-300-07-1')
body_11.SetPos(chrono.ChVectorD(-1.88884419029001,2.51550127212935,0.415537510233024))
body_11.SetRot(chrono.ChQuaternionD(-0.0366822356573985,-0.457950149324953,0.888019269219919,0.0189169716008908))
body_11.SetMass(6.52835644128616)
body_11.SetInertiaXX(chrono.ChVectorD(0.218294867413263,0.118058976079686,0.313789004836593))
body_11.SetInertiaXY(chrono.ChVectorD(-0.130435955573883,-0.0145129228531585,-0.0205846928418531))
body_11.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.244379956813902,-0.0286291495785353,-0.0666992297731388),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_11_1_shape = chrono.ChObjShapeFile() 
body_11_1_shape.SetFilename(shapes_dir +'body_11_1.obj') 
body_11_1_level = chrono.ChAssetLevel() 
body_11_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_11_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_11_1_level.GetAssets().push_back(body_11_1_shape) 
body_11.GetAssets().push_back(body_11_1_level) 

exported_items.append(body_11)



# Rigid body part
body_12= chrono.ChBodyAuxRef()
body_12.SetName('M-410iB-300 -9/M-410iB-300-11-1')
body_12.SetPos(chrono.ChVectorD(-3.56176682056872,3.02764258400503,0.763074355369571))
body_12.SetRot(chrono.ChQuaternionD(-0.0366164451753452,-0.461025455996663,0.886426585056933,0.0190440061461534))
body_12.SetMass(2.26635866531324)
body_12.SetInertiaXX(chrono.ChVectorD(0.342444575932242,0.170720475111163,0.50549125464023))
body_12.SetInertiaXY(chrono.ChVectorD(-0.237000682164841,-0.0239698954072387,-0.0341783208834424))
body_12.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.650000000546567,-0.000267013560427986,-4.19077490083408e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_12_1_shape = chrono.ChObjShapeFile() 
body_12_1_shape.SetFilename(shapes_dir +'body_12_1.obj') 
body_12_1_level = chrono.ChAssetLevel() 
body_12_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_12_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_12_1_level.GetAssets().push_back(body_12_1_shape) 
body_12.GetAssets().push_back(body_12_1_level) 

exported_items.append(body_12)



# Rigid body part
body_13= chrono.ChBodyAuxRef()
body_13.SetName('M-410iB-300 -7/M-410iB-300-06-1')
body_13.SetPos(chrono.ChVectorD(-3.08455315977282,2.75811166841884,-2.43598752847277))
body_13.SetRot(chrono.ChQuaternionD(-0.0366164450839616,-0.461025460250217,0.886426582844683,0.019044006321859))
body_13.SetMass(57.487443257986)
body_13.SetInertiaXX(chrono.ChVectorD(9.2600016804482,4.0019522848551,12.6893237121296))
body_13.SetInertiaXY(chrono.ChVectorD(-5.2493241443179,-0.644943244770499,-0.949887858884848))
body_13.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.216990574023306,0.112589145111018,-0.097224117310279),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_5_1_shape = chrono.ChObjShapeFile() 
body_5_1_shape.SetFilename(shapes_dir +'body_5_1.obj') 
body_5_1_level = chrono.ChAssetLevel() 
body_5_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_5_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_5_1_level.GetAssets().push_back(body_5_1_shape) 
body_13.GetAssets().push_back(body_5_1_level) 

# Auxiliary marker (coordinate system feature)
marker_13_1 =chrono.ChMarker()
marker_13_1.SetName('marker_M3_A')
body_13.AddMarker(marker_13_1)
marker_13_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-3.07135713256611,2.75811166324712,-2.27653262937687),chrono.ChQuaternionD(-0.0396174502701613,0.280123903774525,0.959076201512031,-0.0115713379289119)))

exported_items.append(body_13)



# Rigid body part
body_14= chrono.ChBodyAuxRef()
body_14.SetName('M-410iB-300 -7/M-410iB-300-04-1')
body_14.SetPos(chrono.ChVectorD(-1.91121855424051,2.78048238827907,-2.74538388728574))
body_14.SetRot(chrono.ChQuaternionD(0.515318353824204,0.52505671720601,-0.47443374577748,0.483399481584652))
body_14.SetMass(1.58709182620022)
body_14.SetInertiaXX(chrono.ChVectorD(0.112490505154964,0.112417280652057,0.000998085946496919))
body_14.SetInertiaXY(chrono.ChVectorD(4.46219075106967e-06,-8.52197416889224e-05,-0.00105743461725763))
body_14.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.002504718931018,0.259643195204338,6.66879538413068e-09),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_6_1_shape = chrono.ChObjShapeFile() 
body_6_1_shape.SetFilename(shapes_dir +'body_6_1.obj') 
body_6_1_level = chrono.ChAssetLevel() 
body_6_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_6_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_6_1_level.GetAssets().push_back(body_6_1_shape) 
body_14.GetAssets().push_back(body_6_1_level) 

exported_items.append(body_14)



# Rigid body part
body_15= chrono.ChBodyAuxRef()
body_15.SetName('M-410iB-300 -7/M-410iB-300-12-1')
body_15.SetPos(chrono.ChVectorD(-4.07967425969692,1.53452994138092,-2.32005783413704))
body_15.SetRot(chrono.ChQuaternionD(-0.0412727252884181,-0.000468569478897149,0.999147807992026,1.93556340955399e-05))
body_15.SetMass(16.1636065115335)
body_15.SetInertiaXX(chrono.ChVectorD(0.270733820597613,0.400877809867468,0.427371867141468))
body_15.SetInertiaXY(chrono.ChVectorD(0.0574221068634287,0.0377110505251339,-0.0625539343672037))
body_15.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0294847451383035,0.131793864973377,-0.039955675141979),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_1_1_shape = chrono.ChObjShapeFile() 
body_1_1_shape.SetFilename(shapes_dir +'body_1_1.obj') 
body_1_1_level = chrono.ChAssetLevel() 
body_1_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_1_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_1_1_level.GetAssets().push_back(body_1_1_shape) 
body_15.GetAssets().push_back(body_1_1_level) 

# Collision shapes 
body_15.GetCollisionModel().ClearModel()
mr = chrono.ChMatrix33D()
mr[0,0]=0; mr[1,0]=0; mr[2,0]=-1 
mr[0,1]=0; mr[1,1]=-1; mr[2,1]=0 
mr[0,2]=-1; mr[1,2]=0; mr[2,2]=0 
body_15.GetCollisionModel().AddCylinder(0.0891514706007005,0.0891514706007005,0.0737653824400992,chrono.ChVectorD(4.57739150408006E-17,0.0737653824400992,0),mr)
body_15.GetCollisionModel().BuildModel()
body_15.SetCollide(True)

exported_items.append(body_15)



# Rigid body part
body_16= chrono.ChBodyAuxRef()
body_16.SetName('M-410iB-300 -7/M-410iB-300-03-1')
body_16.SetPos(chrono.ChVectorD(-1.88880804908083,2.51550127212934,-2.48402577529183))
body_16.SetRot(chrono.ChQuaternionD(-0.0319545439404118,-0.632366290411082,0.773569283596727,0.0261217409246417))
body_16.SetMass(72.2394925421727)
body_16.SetInertiaXX(chrono.ChVectorD(1.40287854682595,10.9514973454794,11.2634766916778))
body_16.SetInertiaXY(chrono.ChVectorD(1.87720647579531,0.783602183259729,-0.127372995689095))
body_16.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.0436192441530501,0.531901199956275,-0.00110013226020073),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_4_1_shape = chrono.ChObjShapeFile() 
body_4_1_shape.SetFilename(shapes_dir +'body_4_1.obj') 
body_4_1_level = chrono.ChAssetLevel() 
body_4_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_4_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_4_1_level.GetAssets().push_back(body_4_1_shape) 
body_16.GetAssets().push_back(body_4_1_level) 

# Auxiliary marker (coordinate system feature)
marker_16_1 =chrono.ChMarker()
marker_16_1.SetName('marker_M2_A')
body_16.AddMarker(marker_16_1)
marker_16_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.87552911202723,2.51550127212934,-2.32356894066194),chrono.ChQuaternionD(-0.041066134854201,0.0998455940054075,0.994146578292323,-0.00412441456577641)))

# Auxiliary marker (coordinate system feature)
marker_16_2 =chrono.ChMarker()
marker_16_2.SetName('marker_M3_B')
body_16.AddMarker(marker_16_2)
marker_16_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-3.06708905223563,2.75811166841885,-2.22495893456206),chrono.ChQuaternionD(-0.041066134854201,0.0998455940054075,0.994146578292323,-0.00412441456577641)))

exported_items.append(body_16)



# Rigid body part
body_17= chrono.ChBodyAuxRef()
body_17.SetName('M-410iB-300 -7/ArmBase-1')
body_17.SetPos(chrono.ChVectorD(-1.50067035795504,1.75770592148925,-2.52259688656262))
body_17.SetRot(chrono.ChQuaternionD(1.08554747315437e-16,-3.21041963728343e-17,1,-1.72084568816899e-15))
body_17.SetMass(29.4636133436255)
body_17.SetInertiaXX(chrono.ChVectorD(0.754351795243641,1.45825924231452,0.754351795243641))
body_17.SetInertiaXY(chrono.ChVectorD(-4.35433575050877e-17,-2.64545330086461e-17,-2.43089923188912e-15))
body_17.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-9.77354995986777e-18,0.231605672678633,-6.24094154063845e-18),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_2_1_shape = chrono.ChObjShapeFile() 
body_2_1_shape.SetFilename(shapes_dir +'body_2_1.obj') 
body_2_1_level = chrono.ChAssetLevel() 
body_2_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_2_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_2_1_level.GetAssets().push_back(body_2_1_shape) 
body_17.GetAssets().push_back(body_2_1_level) 

# Auxiliary marker (coordinate system feature)
marker_17_1 =chrono.ChMarker()
marker_17_1.SetName('marker_M1_B')
body_17.AddMarker(marker_17_1)
marker_17_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.50067035795504,1.75770592148925,-2.52259688656262),chrono.ChQuaternionD(-0.499999999999999,0.500000000000001,-0.500000000000001,-0.499999999999999)))

exported_items.append(body_17)



# Rigid body part
body_18= chrono.ChBodyAuxRef()
body_18.SetName('M-410iB-300 -7/M-410iB-300-02-1')
body_18.SetPos(chrono.ChVectorD(-1.50067035795504,2.15049691615662,-2.52259688656262))
body_18.SetRot(chrono.ChQuaternionD(-0.0412727298270154,-2.7373752934118e-17,0.99914791786433,-1.71789680388663e-15))
body_18.SetMass(286.960740367602)
body_18.SetInertiaXX(chrono.ChVectorD(20.3261470881377,23.3528740040787,23.2169905170889))
body_18.SetInertiaXY(chrono.ChVectorD(5.60160689862223,-0.500091644770924,-0.179388605538523))
body_18.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.175382085214385,0.199890816413736,-0.00351536323719578),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_3_1_shape = chrono.ChObjShapeFile() 
body_3_1_shape.SetFilename(shapes_dir +'body_3_1.obj') 
body_3_1_level = chrono.ChAssetLevel() 
body_3_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_3_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_3_1_level.GetAssets().push_back(body_3_1_shape) 
body_18.GetAssets().push_back(body_3_1_level) 

# Auxiliary marker (coordinate system feature)
marker_18_1 =chrono.ChMarker()
marker_18_1.SetName('marker_M1_A')
body_18.AddMarker(marker_18_1)
marker_18_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.50067035795504,2.15049691615662,-2.52259688656262),chrono.ChQuaternionD(0.478937594018657,-0.478937594018658,0.520210323845674,0.520210323845672)))

# Auxiliary marker (coordinate system feature)
marker_18_2 =chrono.ChMarker()
marker_18_2.SetName('marker_M2_B')
body_18.AddMarker(marker_18_2)
marker_18_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.87878486024742,2.51549691615662,-2.36286766833328),chrono.ChQuaternionD(-0.0412727298270154,-2.7373752934118E-17,0.99914791786433,-1.71789680388663E-15)))

exported_items.append(body_18)



# Rigid body part
body_19= chrono.ChBodyAuxRef()
body_19.SetName('M-410iB-300 -7/M-410iB-300-07-1')
body_19.SetPos(chrono.ChVectorD(-1.88884419029001,2.51550127212935,-2.48446248976697))
body_19.SetRot(chrono.ChQuaternionD(-0.0366822356573985,-0.457950149324953,0.888019269219919,0.0189169716008909))
body_19.SetMass(6.52835644128616)
body_19.SetInertiaXX(chrono.ChVectorD(0.218294867413263,0.118058976079686,0.313789004836593))
body_19.SetInertiaXY(chrono.ChVectorD(-0.130435955573883,-0.0145129228531585,-0.0205846928418531))
body_19.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.244379956813902,-0.0286291495785353,-0.0666992297731388),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_11_1_shape = chrono.ChObjShapeFile() 
body_11_1_shape.SetFilename(shapes_dir +'body_11_1.obj') 
body_11_1_level = chrono.ChAssetLevel() 
body_11_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_11_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_11_1_level.GetAssets().push_back(body_11_1_shape) 
body_19.GetAssets().push_back(body_11_1_level) 

exported_items.append(body_19)



# Rigid body part
body_20= chrono.ChBodyAuxRef()
body_20.SetName('M-410iB-300 -7/M-410iB-300-09-1')
body_20.SetPos(chrono.ChVectorD(-3.06068331152731,2.75811166841881,-2.14755478140017))
body_20.SetRot(chrono.ChQuaternionD(-0.0412727252885811,-0.000468561066093719,0.999147807995971,1.93552865805488e-05))
body_20.SetMass(8.44776262879024)
body_20.SetInertiaXX(chrono.ChVectorD(0.114982298903477,0.723331728155272,0.823884312212851))
body_20.SetInertiaXY(chrono.ChVectorD(-0.00519662652260742,-0.0591077417070738,-0.00184089226659357))
body_20.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.00309747019490024,0.11726872541838,-0.0225919700688117),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_8_1_shape = chrono.ChObjShapeFile() 
body_8_1_shape.SetFilename(shapes_dir +'body_8_1.obj') 
body_8_1_level = chrono.ChAssetLevel() 
body_8_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_8_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_8_1_level.GetAssets().push_back(body_8_1_shape) 
body_20.GetAssets().push_back(body_8_1_level) 

exported_items.append(body_20)



# Rigid body part
body_21= chrono.ChBodyAuxRef()
body_21.SetName('M-410iB-300 -7/M-410iB-300-11-1')
body_21.SetPos(chrono.ChVectorD(-3.56176682056872,3.02764258400502,-2.13692564463043))
body_21.SetRot(chrono.ChQuaternionD(-0.0366164451753452,-0.461025455996663,0.886426585056933,0.0190440061461534))
body_21.SetMass(2.26635866531324)
body_21.SetInertiaXX(chrono.ChVectorD(0.342444575932242,0.170720475111163,0.50549125464023))
body_21.SetInertiaXY(chrono.ChVectorD(-0.237000682164841,-0.0239698954072387,-0.0341783208834424))
body_21.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.650000000546567,-0.000267013560427986,-4.19077490083408e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_12_1_shape = chrono.ChObjShapeFile() 
body_12_1_shape.SetFilename(shapes_dir +'body_12_1.obj') 
body_12_1_level = chrono.ChAssetLevel() 
body_12_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_12_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_12_1_level.GetAssets().push_back(body_12_1_shape) 
body_21.GetAssets().push_back(body_12_1_level) 

exported_items.append(body_21)



# Rigid body part
body_22= chrono.ChBodyAuxRef()
body_22.SetName('M-410iB-300 -7/M-410iB-300-05-1')
body_22.SetPos(chrono.ChVectorD(-2.2361148582101,2.77437870841746,-2.71849642201004))
body_22.SetRot(chrono.ChQuaternionD(0.0289097831045671,0.713086228370467,-0.699860409425343,-0.029456114275659))
body_22.SetMass(44.264758578016)
body_22.SetInertiaXX(chrono.ChVectorD(0.420124912385258,2.77592729192813,2.76548569075428))
body_22.SetInertiaXY(chrono.ChVectorD(-0.0484362735024024,0.0533450810289395,0.00194028329366022))
body_22.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-5.19600690940307e-06,0.410805913274014,-0.00264008387504332),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_7_1_shape = chrono.ChObjShapeFile() 
body_7_1_shape.SetFilename(shapes_dir +'body_7_1.obj') 
body_7_1_level = chrono.ChAssetLevel() 
body_7_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_7_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_7_1_level.GetAssets().push_back(body_7_1_shape) 
body_22.GetAssets().push_back(body_7_1_level) 

exported_items.append(body_22)



# Rigid body part
body_23= chrono.ChBodyAuxRef()
body_23.SetName('M-410iB-300 -7/M-410iB-300-08-1')
body_23.SetPos(chrono.ChVectorD(-1.56380394947237,3.00995602354015,-2.44434197093519))
body_23.SetRot(chrono.ChQuaternionD(-0.0319960429220256,-0.631135343417726,0.77457390871473,0.0260708930553925))
body_23.SetMass(7.16874140056196)
body_23.SetInertiaXX(chrono.ChVectorD(0.0717801649549737,1.02988843373916,1.09908804347467))
body_23.SetInertiaXY(chrono.ChVectorD(0.199483959762215,-0.00100638858175128,-0.00229075850811442))
body_23.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0995028745288738,0.617303418169042,1.66091348067148e-08),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_9_1_shape = chrono.ChObjShapeFile() 
body_9_1_shape.SetFilename(shapes_dir +'body_9_1.obj') 
body_9_1_level = chrono.ChAssetLevel() 
body_9_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_9_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_9_1_level.GetAssets().push_back(body_9_1_shape) 
body_23.GetAssets().push_back(body_9_1_level) 

exported_items.append(body_23)



# Rigid body part
body_24= chrono.ChBodyAuxRef()
body_24.SetName('M-410iB-300 -7/M-410iB-300-10-1')
body_24.SetPos(chrono.ChVectorD(-1.36365383812342,2.78749692402101,-2.21280981372578))
body_24.SetRot(chrono.ChQuaternionD(-0.0319622275946809,-0.632138678339361,0.773755292789647,0.0261123387416677))
body_24.SetMass(2.24487855545089)
body_24.SetInertiaXX(chrono.ChVectorD(0.0179735699467434,0.411513202899812,0.428952544587403))
body_24.SetInertiaXY(chrono.ChVectorD(0.0835568878991346,-7.20049407697872e-06,-3.53813109576287e-05))
body_24.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-7.01342378264397e-15,0.610001635976697,-2.13860676946225e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_10_1_shape = chrono.ChObjShapeFile() 
body_10_1_shape.SetFilename(shapes_dir +'body_10_1.obj') 
body_10_1_level = chrono.ChAssetLevel() 
body_10_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_10_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_10_1_level.GetAssets().push_back(body_10_1_shape) 
body_24.GetAssets().push_back(body_10_1_level) 

exported_items.append(body_24)



# Rigid body part
body_25= chrono.ChBodyAuxRef()
body_25.SetName('M-410iB-300 -8/M-410iB-300-02-1')
body_25.SetPos(chrono.ChVectorD(-1.50067035795504,2.15049691615662,-1.07259688656262))
body_25.SetRot(chrono.ChQuaternionD(-0.0412727298270156,5.2029682770771e-18,0.99914791786433,-1.56613006706117e-15))
body_25.SetMass(286.960740367602)
body_25.SetInertiaXX(chrono.ChVectorD(20.3261470881377,23.3528740040787,23.2169905170889))
body_25.SetInertiaXY(chrono.ChVectorD(5.60160689862223,-0.500091644770924,-0.179388605538521))
body_25.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.175382085214385,0.199890816413736,-0.00351536323719578),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_3_1_shape = chrono.ChObjShapeFile() 
body_3_1_shape.SetFilename(shapes_dir +'body_3_1.obj') 
body_3_1_level = chrono.ChAssetLevel() 
body_3_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_3_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_3_1_level.GetAssets().push_back(body_3_1_shape) 
body_25.GetAssets().push_back(body_3_1_level) 

# Auxiliary marker (coordinate system feature)
marker_25_1 =chrono.ChMarker()
marker_25_1.SetName('marker_M1_A')
body_25.AddMarker(marker_25_1)
marker_25_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.50067035795504,2.15049691615662,-1.07259688656262),chrono.ChQuaternionD(0.478937594018657,-0.478937594018658,0.520210323845674,0.520210323845672)))

# Auxiliary marker (coordinate system feature)
marker_25_2 =chrono.ChMarker()
marker_25_2.SetName('marker_M2_B')
body_25.AddMarker(marker_25_2)
marker_25_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.87878486024742,2.51549691615662,-0.912867668333278),chrono.ChQuaternionD(-0.0412727298270156,5.2029682770771E-18,0.99914791786433,-1.56613006706117E-15)))

exported_items.append(body_25)



# Rigid body part
body_26= chrono.ChBodyAuxRef()
body_26.SetName('M-410iB-300 -8/M-410iB-300-08-1')
body_26.SetPos(chrono.ChVectorD(-1.56380394947237,3.00995602354016,-0.99434197093519))
body_26.SetRot(chrono.ChQuaternionD(-0.0319960429220257,-0.631135343417726,0.77457390871473,0.0260708930553927))
body_26.SetMass(7.16874140056196)
body_26.SetInertiaXX(chrono.ChVectorD(0.0717801649549737,1.02988843373916,1.09908804347466))
body_26.SetInertiaXY(chrono.ChVectorD(0.199483959762215,-0.00100638858175097,-0.00229075850811446))
body_26.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0995028745288738,0.617303418169042,1.66091348067148e-08),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_9_1_shape = chrono.ChObjShapeFile() 
body_9_1_shape.SetFilename(shapes_dir +'body_9_1.obj') 
body_9_1_level = chrono.ChAssetLevel() 
body_9_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_9_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_9_1_level.GetAssets().push_back(body_9_1_shape) 
body_26.GetAssets().push_back(body_9_1_level) 

exported_items.append(body_26)



# Rigid body part
body_27= chrono.ChBodyAuxRef()
body_27.SetName('M-410iB-300 -8/M-410iB-300-04-1')
body_27.SetPos(chrono.ChVectorD(-1.91121855424051,2.78048238827907,-1.29538388728574))
body_27.SetRot(chrono.ChQuaternionD(0.515318353824204,0.52505671720601,-0.47443374577748,0.483399481584652))
body_27.SetMass(1.58709182620022)
body_27.SetInertiaXX(chrono.ChVectorD(0.112490505154964,0.112417280652057,0.000998085946496918))
body_27.SetInertiaXY(chrono.ChVectorD(4.4621907510662e-06,-8.52197416889356e-05,-0.00105743461725762))
body_27.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.002504718931018,0.259643195204338,6.66879538413068e-09),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_6_1_shape = chrono.ChObjShapeFile() 
body_6_1_shape.SetFilename(shapes_dir +'body_6_1.obj') 
body_6_1_level = chrono.ChAssetLevel() 
body_6_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_6_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_6_1_level.GetAssets().push_back(body_6_1_shape) 
body_27.GetAssets().push_back(body_6_1_level) 

exported_items.append(body_27)



# Rigid body part
body_28= chrono.ChBodyAuxRef()
body_28.SetName('M-410iB-300 -8/M-410iB-300-07-1')
body_28.SetPos(chrono.ChVectorD(-1.88884419029002,2.51550127212934,-1.03446248976697))
body_28.SetRot(chrono.ChQuaternionD(-0.0366822356573986,-0.457950149324953,0.888019269219919,0.0189169716008911))
body_28.SetMass(6.52835644128616)
body_28.SetInertiaXX(chrono.ChVectorD(0.218294867413263,0.118058976079686,0.313789004836593))
body_28.SetInertiaXY(chrono.ChVectorD(-0.130435955573883,-0.0145129228531585,-0.0205846928418532))
body_28.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.244379956813902,-0.0286291495785353,-0.0666992297731388),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_11_1_shape = chrono.ChObjShapeFile() 
body_11_1_shape.SetFilename(shapes_dir +'body_11_1.obj') 
body_11_1_level = chrono.ChAssetLevel() 
body_11_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_11_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_11_1_level.GetAssets().push_back(body_11_1_shape) 
body_28.GetAssets().push_back(body_11_1_level) 

exported_items.append(body_28)



# Rigid body part
body_29= chrono.ChBodyAuxRef()
body_29.SetName('M-410iB-300 -8/M-410iB-300-12-1')
body_29.SetPos(chrono.ChVectorD(-4.07967425969692,1.53452994138094,-0.870057834137042))
body_29.SetRot(chrono.ChQuaternionD(-0.0412727252884183,-0.000468569478897116,0.999147807992026,1.93556340956443e-05))
body_29.SetMass(16.1636065115335)
body_29.SetInertiaXX(chrono.ChVectorD(0.270733820597612,0.400877809867468,0.427371867141468))
body_29.SetInertiaXY(chrono.ChVectorD(0.0574221068634287,0.0377110505251338,-0.0625539343672038))
body_29.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0294847451383035,0.131793864973377,-0.039955675141979),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_1_1_shape = chrono.ChObjShapeFile() 
body_1_1_shape.SetFilename(shapes_dir +'body_1_1.obj') 
body_1_1_level = chrono.ChAssetLevel() 
body_1_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_1_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_1_1_level.GetAssets().push_back(body_1_1_shape) 
body_29.GetAssets().push_back(body_1_1_level) 

# Collision shapes 
body_29.GetCollisionModel().ClearModel()
mr = chrono.ChMatrix33D()
mr[0,0]=0; mr[1,0]=0; mr[2,0]=-1 
mr[0,1]=0; mr[1,1]=-1; mr[2,1]=0 
mr[0,2]=-1; mr[1,2]=0; mr[2,2]=0 
body_29.GetCollisionModel().AddCylinder(0.0891514706007005,0.0891514706007005,0.0737653824400992,chrono.ChVectorD(4.57739150408006E-17,0.0737653824400992,0),mr)
body_29.GetCollisionModel().BuildModel()
body_29.SetCollide(True)

exported_items.append(body_29)



# Rigid body part
body_30= chrono.ChBodyAuxRef()
body_30.SetName('M-410iB-300 -8/M-410iB-300-03-1')
body_30.SetPos(chrono.ChVectorD(-1.88880804908083,2.51550127212935,-1.03402577529183))
body_30.SetRot(chrono.ChQuaternionD(-0.0319545439404119,-0.632366290411082,0.773569283596727,0.0261217409246419))
body_30.SetMass(72.2394925421727)
body_30.SetInertiaXX(chrono.ChVectorD(1.40287854682595,10.9514973454794,11.2634766916778))
body_30.SetInertiaXY(chrono.ChVectorD(1.87720647579531,0.783602183259732,-0.127372995689095))
body_30.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.0436192441530501,0.531901199956275,-0.00110013226020073),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_4_1_shape = chrono.ChObjShapeFile() 
body_4_1_shape.SetFilename(shapes_dir +'body_4_1.obj') 
body_4_1_level = chrono.ChAssetLevel() 
body_4_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_4_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_4_1_level.GetAssets().push_back(body_4_1_shape) 
body_30.GetAssets().push_back(body_4_1_level) 

# Auxiliary marker (coordinate system feature)
marker_30_1 =chrono.ChMarker()
marker_30_1.SetName('marker_M2_A')
body_30.AddMarker(marker_30_1)
marker_30_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.87552911202723,2.51550127212935,-0.873568940661938),chrono.ChQuaternionD(-0.0410661348542012,0.0998455940054076,0.994146578292323,-0.00412441456577628)))

# Auxiliary marker (coordinate system feature)
marker_30_2 =chrono.ChMarker()
marker_30_2.SetName('marker_M3_B')
body_30.AddMarker(marker_30_2)
marker_30_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-3.06708905223563,2.75811166841886,-0.774958934562061),chrono.ChQuaternionD(-0.0410661348542012,0.0998455940054076,0.994146578292323,-0.00412441456577628)))

exported_items.append(body_30)



# Rigid body part
body_31= chrono.ChBodyAuxRef()
body_31.SetName('M-410iB-300 -8/M-410iB-300-05-1')
body_31.SetPos(chrono.ChVectorD(-2.2361148582101,2.77437870841746,-1.26849642201004))
body_31.SetRot(chrono.ChQuaternionD(0.0289097831045672,0.713086228370467,-0.699860409425343,-0.0294561142756592))
body_31.SetMass(44.264758578016)
body_31.SetInertiaXX(chrono.ChVectorD(0.420124912385258,2.77592729192813,2.76548569075428))
body_31.SetInertiaXY(chrono.ChVectorD(-0.0484362735024023,0.0533450810289404,0.00194028329365972))
body_31.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-5.19600690940307e-06,0.410805913274014,-0.00264008387504332),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_7_1_shape = chrono.ChObjShapeFile() 
body_7_1_shape.SetFilename(shapes_dir +'body_7_1.obj') 
body_7_1_level = chrono.ChAssetLevel() 
body_7_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_7_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_7_1_level.GetAssets().push_back(body_7_1_shape) 
body_31.GetAssets().push_back(body_7_1_level) 

exported_items.append(body_31)



# Rigid body part
body_32= chrono.ChBodyAuxRef()
body_32.SetName('M-410iB-300 -8/ArmBase-1')
body_32.SetPos(chrono.ChVectorD(-1.50067035795504,1.75770592148925,-1.07259688656262))
body_32.SetRot(chrono.ChQuaternionD(1.00613961606655e-16,2.24047304958526e-17,1,-1.80641517110252e-15))
body_32.SetMass(29.4636133436255)
body_32.SetInertiaXX(chrono.ChVectorD(0.754351795243641,1.45825924231452,0.754351795243641))
body_32.SetInertiaXY(chrono.ChVectorD(1.23873904251348e-17,-1.41610608623833e-16,-2.75999744864809e-15))
body_32.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-9.77354995986777e-18,0.231605672678633,-6.24094154063845e-18),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_2_1_shape = chrono.ChObjShapeFile() 
body_2_1_shape.SetFilename(shapes_dir +'body_2_1.obj') 
body_2_1_level = chrono.ChAssetLevel() 
body_2_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_2_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_2_1_level.GetAssets().push_back(body_2_1_shape) 
body_32.GetAssets().push_back(body_2_1_level) 

# Auxiliary marker (coordinate system feature)
marker_32_1 =chrono.ChMarker()
marker_32_1.SetName('marker_M1_B')
body_32.AddMarker(marker_32_1)
marker_32_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-1.50067035795504,1.75770592148925,-1.07259688656262),chrono.ChQuaternionD(-0.499999999999999,0.500000000000001,-0.500000000000001,-0.499999999999999)))

exported_items.append(body_32)



# Rigid body part
body_33= chrono.ChBodyAuxRef()
body_33.SetName('M-410iB-300 -8/M-410iB-300-06-1')
body_33.SetPos(chrono.ChVectorD(-3.08455315977282,2.75811166841884,-0.985987528472767))
body_33.SetRot(chrono.ChQuaternionD(-0.0366164450839617,-0.461025460250217,0.886426582844683,0.0190440063218592))
body_33.SetMass(57.487443257986)
body_33.SetInertiaXX(chrono.ChVectorD(9.2600016804482,4.0019522848551,12.6893237121296))
body_33.SetInertiaXY(chrono.ChVectorD(-5.2493241443179,-0.644943244770501,-0.949887858884852))
body_33.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.216990574023306,0.112589145111018,-0.097224117310279),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_5_1_shape = chrono.ChObjShapeFile() 
body_5_1_shape.SetFilename(shapes_dir +'body_5_1.obj') 
body_5_1_level = chrono.ChAssetLevel() 
body_5_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_5_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_5_1_level.GetAssets().push_back(body_5_1_shape) 
body_33.GetAssets().push_back(body_5_1_level) 

# Auxiliary marker (coordinate system feature)
marker_33_1 =chrono.ChMarker()
marker_33_1.SetName('marker_M3_A')
body_33.AddMarker(marker_33_1)
marker_33_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-3.07135713256612,2.75811166324712,-0.826532629376866),chrono.ChQuaternionD(-0.0396174502701616,0.280123903774525,0.959076201512031,-0.0115713379289118)))

exported_items.append(body_33)



# Rigid body part
body_34= chrono.ChBodyAuxRef()
body_34.SetName('M-410iB-300 -8/M-410iB-300-09-1')
body_34.SetPos(chrono.ChVectorD(-3.06068331152731,2.75811166841881,-0.697554781400164))
body_34.SetRot(chrono.ChQuaternionD(-0.0412727252885813,-0.000468561066093686,0.999147807995971,1.93552865807007e-05))
body_34.SetMass(8.44776262879024)
body_34.SetInertiaXX(chrono.ChVectorD(0.114982298903478,0.723331728155272,0.823884312212851))
body_34.SetInertiaXY(chrono.ChVectorD(-0.00519662652260737,-0.059107741707074,-0.0018408922665936))
body_34.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.00309747019490024,0.11726872541838,-0.0225919700688117),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_8_1_shape = chrono.ChObjShapeFile() 
body_8_1_shape.SetFilename(shapes_dir +'body_8_1.obj') 
body_8_1_level = chrono.ChAssetLevel() 
body_8_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_8_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_8_1_level.GetAssets().push_back(body_8_1_shape) 
body_34.GetAssets().push_back(body_8_1_level) 

exported_items.append(body_34)



# Rigid body part
body_35= chrono.ChBodyAuxRef()
body_35.SetName('M-410iB-300 -8/M-410iB-300-10-1')
body_35.SetPos(chrono.ChVectorD(-1.36365383812342,2.78749692402102,-0.762809813725776))
body_35.SetRot(chrono.ChQuaternionD(-0.031962227594681,-0.632138678339361,0.773755292789647,0.0261123387416679))
body_35.SetMass(2.24487855545089)
body_35.SetInertiaXX(chrono.ChVectorD(0.0179735699467435,0.411513202899812,0.428952544587403))
body_35.SetInertiaXY(chrono.ChVectorD(0.0835568878991346,-7.20049407685079e-06,-3.5381310957653e-05))
body_35.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-7.01342378264397e-15,0.610001635976697,-2.13860676946225e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_10_1_shape = chrono.ChObjShapeFile() 
body_10_1_shape.SetFilename(shapes_dir +'body_10_1.obj') 
body_10_1_level = chrono.ChAssetLevel() 
body_10_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_10_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_10_1_level.GetAssets().push_back(body_10_1_shape) 
body_35.GetAssets().push_back(body_10_1_level) 

exported_items.append(body_35)



# Rigid body part
body_36= chrono.ChBodyAuxRef()
body_36.SetName('M-410iB-300 -8/M-410iB-300-11-1')
body_36.SetPos(chrono.ChVectorD(-3.56176682056872,3.02764258400502,-0.686925644630427))
body_36.SetRot(chrono.ChQuaternionD(-0.0366164451753453,-0.461025455996663,0.886426585056933,0.0190440061461536))
body_36.SetMass(2.26635866531324)
body_36.SetInertiaXX(chrono.ChVectorD(0.342444575932242,0.170720475111163,0.50549125464023))
body_36.SetInertiaXY(chrono.ChVectorD(-0.237000682164841,-0.0239698954072389,-0.0341783208834425))
body_36.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.650000000546567,-0.000267013560427986,-4.19077490083408e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_12_1_shape = chrono.ChObjShapeFile() 
body_12_1_shape.SetFilename(shapes_dir +'body_12_1.obj') 
body_12_1_level = chrono.ChAssetLevel() 
body_12_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_12_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_12_1_level.GetAssets().push_back(body_12_1_shape) 
body_36.GetAssets().push_back(body_12_1_level) 

exported_items.append(body_36)



# Rigid body part
body_37= chrono.ChBodyAuxRef()
body_37.SetName('M-410iB-300 -2/M-410iB-300-11-1')
body_37.SetPos(chrono.ChVectorD(1.92042610465864,3.02764258400502,-1.4582681284948))
body_37.SetRot(chrono.ChQuaternionD(0.886426585056933,-0.019044006146155,0.0366164451753445,-0.461025455996663))
body_37.SetMass(2.26635866531324)
body_37.SetInertiaXX(chrono.ChVectorD(0.342444567987369,0.170720483056036,0.50549125464023))
body_37.SetInertiaXY(chrono.ChVectorD(-0.237000685043158,-0.0239698113746433,-0.0341783798169186))
body_37.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.650000000546567,-0.000267013560427986,-4.19077490083408e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_12_1_shape = chrono.ChObjShapeFile() 
body_12_1_shape.SetFilename(shapes_dir +'body_12_1.obj') 
body_12_1_level = chrono.ChAssetLevel() 
body_12_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_12_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_12_1_level.GetAssets().push_back(body_12_1_shape) 
body_37.GetAssets().push_back(body_12_1_level) 

exported_items.append(body_37)



# Rigid body part
body_38= chrono.ChBodyAuxRef()
body_38.SetName('M-410iB-300 -2/M-410iB-300-09-1')
body_38.SetPos(chrono.ChVectorD(1.41934259561724,2.75811166841883,-1.44763899172506))
body_38.SetRot(chrono.ChQuaternionD(0.999147807995971,-1.93552865822696e-05,0.0412727252885812,-0.000468561066093758))
body_38.SetMass(8.44776262879024)
body_38.SetInertiaXX(chrono.ChVectorD(0.11496494349016,0.723349083568589,0.823884312212851))
body_38.SetInertiaXY(chrono.ChVectorD(0.00405542478900021,-0.0591110909356658,0.0017300122666693))
body_38.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.00309747019490024,0.11726872541838,-0.0225919700688117),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_8_1_shape = chrono.ChObjShapeFile() 
body_8_1_shape.SetFilename(shapes_dir +'body_8_1.obj') 
body_8_1_level = chrono.ChAssetLevel() 
body_8_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_8_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_8_1_level.GetAssets().push_back(body_8_1_shape) 
body_38.GetAssets().push_back(body_8_1_level) 

exported_items.append(body_38)



# Rigid body part
body_39= chrono.ChBodyAuxRef()
body_39.SetName('M-410iB-300 -2/M-410iB-300-10-1')
body_39.SetPos(chrono.ChVectorD(-0.277686877786659,2.78749692402101,-1.38238395939945))
body_39.SetRot(chrono.ChQuaternionD(0.773755292789647,-0.0261123387416691,0.0319622275946799,-0.632138678339361))
body_39.SetMass(2.24487855545089)
body_39.SetInertiaXX(chrono.ChVectorD(0.0179735699808056,0.41151320286575,0.428952544587403))
body_39.SetInertiaXY(chrono.ChVectorD(0.0835568879793482,-7.20152596639639e-06,-3.53811009408747e-05))
body_39.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-7.01342378264397e-15,0.610001635976697,-2.13860676946225e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_10_1_shape = chrono.ChObjShapeFile() 
body_10_1_shape.SetFilename(shapes_dir +'body_10_1.obj') 
body_10_1_level = chrono.ChAssetLevel() 
body_10_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_10_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_10_1_level.GetAssets().push_back(body_10_1_shape) 
body_39.GetAssets().push_back(body_10_1_level) 

exported_items.append(body_39)



# Rigid body part
body_40= chrono.ChBodyAuxRef()
body_40.SetName('M-410iB-300 -2/M-410iB-300-05-1')
body_40.SetPos(chrono.ChVectorD(0.594774142300026,2.77437870841746,-0.876697351115191))
body_40.SetRot(chrono.ChQuaternionD(0.699860409425343,-0.0294561142756602,0.0289097831045659,-0.713086228370467))
body_40.SetMass(44.264758578016)
body_40.SetInertiaXX(chrono.ChVectorD(0.419802161252818,2.77625004306057,2.76548569075428))
body_40.SetInertiaXY(chrono.ChVectorD(-0.0398199766034855,-0.0533803242613383,-5.78878132818095e-05))
body_40.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-5.19600690940307e-06,0.410805913274014,-0.00264008387504332),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_7_1_shape = chrono.ChObjShapeFile() 
body_7_1_shape.SetFilename(shapes_dir +'body_7_1.obj') 
body_7_1_level = chrono.ChAssetLevel() 
body_7_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_7_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_7_1_level.GetAssets().push_back(body_7_1_shape) 
body_40.GetAssets().push_back(body_7_1_level) 

exported_items.append(body_40)



# Rigid body part
body_41= chrono.ChBodyAuxRef()
body_41.SetName('M-410iB-300 -2/M-410iB-300-04-1')
body_41.SetPos(chrono.ChVectorD(0.269877838330436,2.78048238827907,-0.849809885839491))
body_41.SetRot(chrono.ChQuaternionD(-0.474433745777481,-0.483399481584651,-0.515318353824203,0.525056717206011))
body_41.SetMass(1.58709182620022)
body_41.SetInertiaXX(chrono.ChVectorD(0.112490505154964,0.112340274058519,0.00107509254003515))
body_41.SetInertiaXY(chrono.ChVectorD(7.64900044070236e-06,8.49929897824014e-05,-0.00311323795964494))
body_41.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.002504718931018,0.259643195204338,6.66879538413068e-09),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_6_1_shape = chrono.ChObjShapeFile() 
body_6_1_shape.SetFilename(shapes_dir +'body_6_1.obj') 
body_6_1_level = chrono.ChAssetLevel() 
body_6_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_6_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_6_1_level.GetAssets().push_back(body_6_1_shape) 
body_41.GetAssets().push_back(body_6_1_level) 

exported_items.append(body_41)



# Rigid body part
body_42= chrono.ChBodyAuxRef()
body_42.SetName('M-410iB-300 -2/M-410iB-300-07-1')
body_42.SetPos(chrono.ChVectorD(0.24750347437993,2.51550127212935,-1.11073128335825))
body_42.SetRot(chrono.ChQuaternionD(0.888019269219919,-0.0189169716008925,0.0366822356573978,-0.457950149324953))
body_42.SetMass(6.52835644128616)
body_42.SetInertiaXX(chrono.ChVectorD(0.209548892318939,0.126804951174011,0.313789004836593))
body_42.SetInertiaXY(chrono.ChVectorD(-0.133468000042266,-0.014695331293433,-0.0204548709922948))
body_42.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.244379956813902,-0.0286291495785353,-0.0666992297731388),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_11_1_shape = chrono.ChObjShapeFile() 
body_11_1_shape.SetFilename(shapes_dir +'body_11_1.obj') 
body_11_1_level = chrono.ChAssetLevel() 
body_11_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_11_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_11_1_level.GetAssets().push_back(body_11_1_shape) 
body_42.GetAssets().push_back(body_11_1_level) 

exported_items.append(body_42)



# Rigid body part
body_43= chrono.ChBodyAuxRef()
body_43.SetName('M-410iB-300 -2/M-410iB-300-08-1')
body_43.SetPos(chrono.ChVectorD(-0.0775367664377166,3.00995602354016,-1.15085180219003))
body_43.SetRot(chrono.ChQuaternionD(0.77457390871473,-0.0260708930553939,0.0319960429220246,-0.631135343417726))
body_43.SetMass(7.16874140056196)
body_43.SetInertiaXX(chrono.ChVectorD(0.0767803688734156,1.02488822982072,1.09908804347467))
body_43.SetInertiaXY(chrono.ChVectorD(0.211091413570172,1.79884424153821e-05,-0.00250201297676742))
body_43.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0995028745288738,0.617303418169042,1.66091348067148e-08),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_9_1_shape = chrono.ChObjShapeFile() 
body_9_1_shape.SetFilename(shapes_dir +'body_9_1.obj') 
body_9_1_level = chrono.ChAssetLevel() 
body_9_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_9_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_9_1_level.GetAssets().push_back(body_9_1_shape) 
body_43.GetAssets().push_back(body_9_1_level) 

exported_items.append(body_43)



# Rigid body part
body_44= chrono.ChBodyAuxRef()
body_44.SetName('M-410iB-300 -2/ArmBase-1')
body_44.SetPos(chrono.ChVectorD(-0.140670357955037,1.75770592148926,-1.07259688656261))
body_44.SetRot(chrono.ChQuaternionD(1,0,0,0))
body_44.SetMass(29.4636133436255)
body_44.SetInertiaXX(chrono.ChVectorD(0.754351795243641,1.45825924231452,0.754351795243641))
body_44.SetInertiaXY(chrono.ChVectorD(-1.65340831304039e-18,-2.64545330086463e-17,8.26704156520197e-18))
body_44.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-9.77354995986777e-18,0.231605672678633,-6.24094154063845e-18),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_2_1_shape = chrono.ChObjShapeFile() 
body_2_1_shape.SetFilename(shapes_dir +'body_2_1.obj') 
body_2_1_level = chrono.ChAssetLevel() 
body_2_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_2_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_2_1_level.GetAssets().push_back(body_2_1_shape) 
body_44.GetAssets().push_back(body_2_1_level) 

# Auxiliary marker (coordinate system feature)
marker_44_1 =chrono.ChMarker()
marker_44_1.SetName('marker_M1_B')
body_44.AddMarker(marker_44_1)
marker_44_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-0.140670357955037,1.75770592148926,-1.07259688656261),chrono.ChQuaternionD(0.5,-0.5,-0.5,-0.5)))

exported_items.append(body_44)



# Rigid body part
body_45= chrono.ChBodyAuxRef()
body_45.SetName('M-410iB-300 -2/M-410iB-300-02-1')
body_45.SetPos(chrono.ChVectorD(-0.140670357955037,2.15049691615662,-1.07259688656261))
body_45.SetRot(chrono.ChQuaternionD(0.99914791786433,-2.80761023644036e-18,0.0412727298270155,-6.63209111352764e-17))
body_45.SetMass(286.960740367602)
body_45.SetInertiaXX(chrono.ChVectorD(20.3261470881377,23.3528740040787,23.2169905170889))
body_45.SetInertiaXY(chrono.ChVectorD(-5.60160689862223,-0.500091644770905,0.179388605538521))
body_45.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.175382085214385,0.199890816413736,-0.00351536323719578),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_3_1_shape = chrono.ChObjShapeFile() 
body_3_1_shape.SetFilename(shapes_dir +'body_3_1.obj') 
body_3_1_level = chrono.ChAssetLevel() 
body_3_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_3_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_3_1_level.GetAssets().push_back(body_3_1_shape) 
body_45.GetAssets().push_back(body_3_1_level) 

# Auxiliary marker (coordinate system feature)
marker_45_1 =chrono.ChMarker()
marker_45_1.SetName('marker_M1_A')
body_45.AddMarker(marker_45_1)
marker_45_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-0.140670357955037,2.15049691615662,-1.07259688656261),chrono.ChQuaternionD(0.520210323845673,-0.520210323845673,-0.478937594018657,-0.478937594018657)))

# Auxiliary marker (coordinate system feature)
marker_45_2 =chrono.ChMarker()
marker_45_2.SetName('marker_M2_B')
body_45.AddMarker(marker_45_2)
marker_45_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(0.237444144337344,2.51549691615662,-1.23232610479195),chrono.ChQuaternionD(0.99914791786433,-2.80761023644036E-18,0.0412727298270155,-6.63209111352764E-17)))

exported_items.append(body_45)



# Rigid body part
body_46= chrono.ChBodyAuxRef()
body_46.SetName('M-410iB-300 -2/M-410iB-300-12-1')
body_46.SetPos(chrono.ChVectorD(2.43833354378684,1.53452994138094,-1.27513593898818))
body_46.SetRot(chrono.ChQuaternionD(0.999147807992026,-1.93556340972606e-05,0.0412727252884182,-0.000468569478897188))
body_46.SetMass(16.1636065115335)
body_46.SetInertiaXX(chrono.ChVectorD(0.270949711605444,0.400661918859637,0.427371867141467))
body_46.SetInertiaXY(chrono.ChVectorD(-0.0576658362005998,0.0375936407947645,0.062624565533981))
body_46.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0294847451383035,0.131793864973377,-0.039955675141979),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_1_1_shape = chrono.ChObjShapeFile() 
body_1_1_shape.SetFilename(shapes_dir +'body_1_1.obj') 
body_1_1_level = chrono.ChAssetLevel() 
body_1_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_1_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_1_1_level.GetAssets().push_back(body_1_1_shape) 
body_46.GetAssets().push_back(body_1_1_level) 

# Collision shapes 
body_46.GetCollisionModel().ClearModel()
mr = chrono.ChMatrix33D()
mr[0,0]=0; mr[1,0]=0; mr[2,0]=-1 
mr[0,1]=0; mr[1,1]=-1; mr[2,1]=0 
mr[0,2]=-1; mr[1,2]=0; mr[2,2]=0 
body_46.GetCollisionModel().AddCylinder(0.0891514706007005,0.0891514706007005,0.0737653824400992,chrono.ChVectorD(4.57739150408006E-17,0.0737653824400992,0),mr)
body_46.GetCollisionModel().BuildModel()
body_46.SetCollide(True)

exported_items.append(body_46)



# Rigid body part
body_47= chrono.ChBodyAuxRef()
body_47.SetName('M-410iB-300 -2/M-410iB-300-03-1')
body_47.SetPos(chrono.ChVectorD(0.247467333170754,2.51550127212935,-1.1111679978334))
body_47.SetRot(chrono.ChQuaternionD(0.773569283596727,-0.0261217409246431,0.0319545439404108,-0.632366290411082))
body_47.SetMass(72.2394925421727)
body_47.SetInertiaXX(chrono.ChVectorD(1.50592710700546,10.8484487852999,11.2634766916778))
body_47.SetInertiaXY(chrono.ChVectorD(2.12067361135961,-0.771273236415114,0.188132550160896))
body_47.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.0436192441530501,0.531901199956275,-0.00110013226020073),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_4_1_shape = chrono.ChObjShapeFile() 
body_4_1_shape.SetFilename(shapes_dir +'body_4_1.obj') 
body_4_1_level = chrono.ChAssetLevel() 
body_4_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_4_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_4_1_level.GetAssets().push_back(body_4_1_shape) 
body_47.GetAssets().push_back(body_4_1_level) 

# Auxiliary marker (coordinate system feature)
marker_47_1 =chrono.ChMarker()
marker_47_1.SetName('marker_M2_A')
body_47.AddMarker(marker_47_1)
marker_47_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(0.234188396117153,2.51550127212935,-1.27162483246329),chrono.ChQuaternionD(0.994146578292323,0.00412441456577471,0.0410661348542013,0.0998455940054075)))

# Auxiliary marker (coordinate system feature)
marker_47_2 =chrono.ChMarker()
marker_47_2.SetName('marker_M3_B')
body_47.AddMarker(marker_47_2)
marker_47_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(1.42574833632556,2.75811166841886,-1.37023483856317),chrono.ChQuaternionD(0.994146578292323,0.00412441456577471,0.0410661348542013,0.0998455940054075)))

exported_items.append(body_47)



# Rigid body part
body_48= chrono.ChBodyAuxRef()
body_48.SetName('M-410iB-300 -2/M-410iB-300-06-1')
body_48.SetPos(chrono.ChVectorD(1.44321244386273,2.75811166841885,-1.15920624465246))
body_48.SetRot(chrono.ChQuaternionD(0.886426582844683,-0.0190440063218605,0.0366164450839609,-0.461025460250217))
body_48.SetMass(57.487443257986)
body_48.SetInertiaXX(chrono.ChVectorD(7.9742261479953,5.28772781730799,12.6893237121296))
body_48.SetInertiaXY(chrono.ChVectorD(-5.71514273781038,-0.673403451868731,-0.929928236179133))
body_48.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.216990574023306,0.112589145111018,-0.097224117310279),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_5_1_shape = chrono.ChObjShapeFile() 
body_5_1_shape.SetFilename(shapes_dir +'body_5_1.obj') 
body_5_1_level = chrono.ChAssetLevel() 
body_5_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_5_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_5_1_level.GetAssets().push_back(body_5_1_shape) 
body_48.GetAssets().push_back(body_5_1_level) 

# Auxiliary marker (coordinate system feature)
marker_48_1 =chrono.ChMarker()
marker_48_1.SetName('marker_M3_A')
body_48.AddMarker(marker_48_1)
marker_48_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(1.43001641665603,2.75811166324713,-1.31866114374836),chrono.ChQuaternionD(0.959076201512031,0.0115713379289103,0.0396174502701619,0.280123903774525)))

exported_items.append(body_48)



# Rigid body part
body_49= chrono.ChBodyAuxRef()
body_49.SetName('M-410iB-300 -3/M-410iB-300-06-1')
body_49.SetPos(chrono.ChVectorD(1.44321244386273,2.75811166841885,-2.60920624465246))
body_49.SetRot(chrono.ChQuaternionD(0.886426582844683,-0.0190440063218605,0.0366164450839609,-0.461025460250217))
body_49.SetMass(57.487443257986)
body_49.SetInertiaXX(chrono.ChVectorD(7.9742261479953,5.28772781730799,12.6893237121296))
body_49.SetInertiaXY(chrono.ChVectorD(-5.71514273781038,-0.673403451868731,-0.929928236179133))
body_49.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.216990574023306,0.112589145111018,-0.097224117310279),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_5_1_shape = chrono.ChObjShapeFile() 
body_5_1_shape.SetFilename(shapes_dir +'body_5_1.obj') 
body_5_1_level = chrono.ChAssetLevel() 
body_5_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_5_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_5_1_level.GetAssets().push_back(body_5_1_shape) 
body_49.GetAssets().push_back(body_5_1_level) 

# Auxiliary marker (coordinate system feature)
marker_49_1 =chrono.ChMarker()
marker_49_1.SetName('marker_M3_A')
body_49.AddMarker(marker_49_1)
marker_49_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(1.43001641665603,2.75811166324713,-2.76866114374836),chrono.ChQuaternionD(0.959076201512031,0.0115713379289103,0.0396174502701619,0.280123903774525)))

exported_items.append(body_49)



# Rigid body part
body_50= chrono.ChBodyAuxRef()
body_50.SetName('M-410iB-300 -3/M-410iB-300-07-1')
body_50.SetPos(chrono.ChVectorD(0.247503474379928,2.51550127212935,-2.56073128335825))
body_50.SetRot(chrono.ChQuaternionD(0.888019269219919,-0.0189169716008925,0.0366822356573978,-0.457950149324953))
body_50.SetMass(6.52835644128616)
body_50.SetInertiaXX(chrono.ChVectorD(0.209548892318939,0.126804951174011,0.313789004836593))
body_50.SetInertiaXY(chrono.ChVectorD(-0.133468000042266,-0.014695331293433,-0.0204548709922948))
body_50.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.244379956813902,-0.0286291495785353,-0.0666992297731388),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_11_1_shape = chrono.ChObjShapeFile() 
body_11_1_shape.SetFilename(shapes_dir +'body_11_1.obj') 
body_11_1_level = chrono.ChAssetLevel() 
body_11_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_11_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_11_1_level.GetAssets().push_back(body_11_1_shape) 
body_50.GetAssets().push_back(body_11_1_level) 

exported_items.append(body_50)



# Rigid body part
body_51= chrono.ChBodyAuxRef()
body_51.SetName('M-410iB-300 -3/M-410iB-300-04-1')
body_51.SetPos(chrono.ChVectorD(0.269877838330445,2.78048238827907,-2.29980988583949))
body_51.SetRot(chrono.ChQuaternionD(-0.474433745777481,-0.483399481584651,-0.515318353824203,0.525056717206011))
body_51.SetMass(1.58709182620022)
body_51.SetInertiaXX(chrono.ChVectorD(0.112490505154964,0.112340274058519,0.00107509254003515))
body_51.SetInertiaXY(chrono.ChVectorD(7.64900044070236e-06,8.49929897824014e-05,-0.00311323795964494))
body_51.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.002504718931018,0.259643195204338,6.66879538413068e-09),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_6_1_shape = chrono.ChObjShapeFile() 
body_6_1_shape.SetFilename(shapes_dir +'body_6_1.obj') 
body_6_1_level = chrono.ChAssetLevel() 
body_6_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_6_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_6_1_level.GetAssets().push_back(body_6_1_shape) 
body_51.GetAssets().push_back(body_6_1_level) 

exported_items.append(body_51)



# Rigid body part
body_52= chrono.ChBodyAuxRef()
body_52.SetName('M-410iB-300 -3/M-410iB-300-12-1')
body_52.SetPos(chrono.ChVectorD(2.43833354378685,1.53452994138093,-2.72513593898818))
body_52.SetRot(chrono.ChQuaternionD(0.999147807992026,-1.93556340972606e-05,0.0412727252884182,-0.000468569478897188))
body_52.SetMass(16.1636065115335)
body_52.SetInertiaXX(chrono.ChVectorD(0.270949711605444,0.400661918859637,0.427371867141467))
body_52.SetInertiaXY(chrono.ChVectorD(-0.0576658362005998,0.0375936407947645,0.062624565533981))
body_52.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0294847451383035,0.131793864973377,-0.039955675141979),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_1_1_shape = chrono.ChObjShapeFile() 
body_1_1_shape.SetFilename(shapes_dir +'body_1_1.obj') 
body_1_1_level = chrono.ChAssetLevel() 
body_1_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_1_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_1_1_level.GetAssets().push_back(body_1_1_shape) 
body_52.GetAssets().push_back(body_1_1_level) 

# Collision shapes 
body_52.GetCollisionModel().ClearModel()
mr = chrono.ChMatrix33D()
mr[0,0]=0; mr[1,0]=0; mr[2,0]=-1 
mr[0,1]=0; mr[1,1]=-1; mr[2,1]=0 
mr[0,2]=-1; mr[1,2]=0; mr[2,2]=0 
body_52.GetCollisionModel().AddCylinder(0.0891514706007005,0.0891514706007005,0.0737653824400992,chrono.ChVectorD(4.57739150408006E-17,0.0737653824400992,0),mr)
body_52.GetCollisionModel().BuildModel()
body_52.SetCollide(True)

exported_items.append(body_52)



# Rigid body part
body_53= chrono.ChBodyAuxRef()
body_53.SetName('M-410iB-300 -3/ArmBase-1')
body_53.SetPos(chrono.ChVectorD(-0.140670357955037,1.75770592148926,-2.52259688656261))
body_53.SetRot(chrono.ChQuaternionD(1,0,0,0))
body_53.SetMass(29.4636133436255)
body_53.SetInertiaXX(chrono.ChVectorD(0.754351795243641,1.45825924231452,0.754351795243641))
body_53.SetInertiaXY(chrono.ChVectorD(-1.65340831304039e-18,-2.64545330086463e-17,8.26704156520197e-18))
body_53.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-9.77354995986777e-18,0.231605672678633,-6.24094154063845e-18),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_2_1_shape = chrono.ChObjShapeFile() 
body_2_1_shape.SetFilename(shapes_dir +'body_2_1.obj') 
body_2_1_level = chrono.ChAssetLevel() 
body_2_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_2_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_2_1_level.GetAssets().push_back(body_2_1_shape) 
body_53.GetAssets().push_back(body_2_1_level) 

# Auxiliary marker (coordinate system feature)
marker_53_1 =chrono.ChMarker()
marker_53_1.SetName('marker_M1_B')
body_53.AddMarker(marker_53_1)
marker_53_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-0.140670357955037,1.75770592148926,-2.52259688656261),chrono.ChQuaternionD(0.5,-0.5,-0.5,-0.5)))

exported_items.append(body_53)



# Rigid body part
body_54= chrono.ChBodyAuxRef()
body_54.SetName('M-410iB-300 -3/M-410iB-300-02-1')
body_54.SetPos(chrono.ChVectorD(-0.140670357955037,2.15049691615662,-2.52259688656261))
body_54.SetRot(chrono.ChQuaternionD(0.99914791786433,-2.80761023644036e-18,0.0412727298270155,-6.63209111352764e-17))
body_54.SetMass(286.960740367602)
body_54.SetInertiaXX(chrono.ChVectorD(20.3261470881377,23.3528740040787,23.2169905170889))
body_54.SetInertiaXY(chrono.ChVectorD(-5.60160689862223,-0.500091644770905,0.179388605538521))
body_54.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.175382085214385,0.199890816413736,-0.00351536323719578),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_3_1_shape = chrono.ChObjShapeFile() 
body_3_1_shape.SetFilename(shapes_dir +'body_3_1.obj') 
body_3_1_level = chrono.ChAssetLevel() 
body_3_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_3_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_3_1_level.GetAssets().push_back(body_3_1_shape) 
body_54.GetAssets().push_back(body_3_1_level) 

# Auxiliary marker (coordinate system feature)
marker_54_1 =chrono.ChMarker()
marker_54_1.SetName('marker_M1_A')
body_54.AddMarker(marker_54_1)
marker_54_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-0.140670357955037,2.15049691615662,-2.52259688656261),chrono.ChQuaternionD(0.520210323845673,-0.520210323845673,-0.478937594018657,-0.478937594018657)))

# Auxiliary marker (coordinate system feature)
marker_54_2 =chrono.ChMarker()
marker_54_2.SetName('marker_M2_B')
body_54.AddMarker(marker_54_2)
marker_54_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(0.237444144337345,2.51549691615662,-2.68232610479195),chrono.ChQuaternionD(0.99914791786433,-2.80761023644036E-18,0.0412727298270155,-6.63209111352764E-17)))

exported_items.append(body_54)



# Rigid body part
body_55= chrono.ChBodyAuxRef()
body_55.SetName('M-410iB-300 -3/M-410iB-300-03-1')
body_55.SetPos(chrono.ChVectorD(0.247467333170762,2.51550127212935,-2.5611679978334))
body_55.SetRot(chrono.ChQuaternionD(0.773569283596727,-0.0261217409246431,0.0319545439404108,-0.632366290411082))
body_55.SetMass(72.2394925421727)
body_55.SetInertiaXX(chrono.ChVectorD(1.50592710700546,10.8484487852999,11.2634766916778))
body_55.SetInertiaXY(chrono.ChVectorD(2.12067361135961,-0.771273236415114,0.188132550160896))
body_55.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.0436192441530501,0.531901199956275,-0.00110013226020073),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_4_1_shape = chrono.ChObjShapeFile() 
body_4_1_shape.SetFilename(shapes_dir +'body_4_1.obj') 
body_4_1_level = chrono.ChAssetLevel() 
body_4_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_4_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_4_1_level.GetAssets().push_back(body_4_1_shape) 
body_55.GetAssets().push_back(body_4_1_level) 

# Auxiliary marker (coordinate system feature)
marker_55_1 =chrono.ChMarker()
marker_55_1.SetName('marker_M2_A')
body_55.AddMarker(marker_55_1)
marker_55_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(0.23418839611716,2.51550127212935,-2.72162483246329),chrono.ChQuaternionD(0.994146578292323,0.00412441456577471,0.0410661348542013,0.0998455940054075)))

# Auxiliary marker (coordinate system feature)
marker_55_2 =chrono.ChMarker()
marker_55_2.SetName('marker_M3_B')
body_55.AddMarker(marker_55_2)
marker_55_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(1.42574833632557,2.75811166841886,-2.82023483856317),chrono.ChQuaternionD(0.994146578292323,0.00412441456577471,0.0410661348542013,0.0998455940054075)))

exported_items.append(body_55)



# Rigid body part
body_56= chrono.ChBodyAuxRef()
body_56.SetName('M-410iB-300 -3/M-410iB-300-05-1')
body_56.SetPos(chrono.ChVectorD(0.594774142300034,2.77437870841746,-2.32669735111519))
body_56.SetRot(chrono.ChQuaternionD(0.699860409425343,-0.0294561142756602,0.0289097831045659,-0.713086228370467))
body_56.SetMass(44.264758578016)
body_56.SetInertiaXX(chrono.ChVectorD(0.419802161252818,2.77625004306057,2.76548569075428))
body_56.SetInertiaXY(chrono.ChVectorD(-0.0398199766034855,-0.0533803242613383,-5.78878132818095e-05))
body_56.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-5.19600690940307e-06,0.410805913274014,-0.00264008387504332),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_7_1_shape = chrono.ChObjShapeFile() 
body_7_1_shape.SetFilename(shapes_dir +'body_7_1.obj') 
body_7_1_level = chrono.ChAssetLevel() 
body_7_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_7_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_7_1_level.GetAssets().push_back(body_7_1_shape) 
body_56.GetAssets().push_back(body_7_1_level) 

exported_items.append(body_56)



# Rigid body part
body_57= chrono.ChBodyAuxRef()
body_57.SetName('M-410iB-300 -3/M-410iB-300-09-1')
body_57.SetPos(chrono.ChVectorD(1.41934259561724,2.75811166841883,-2.89763899172506))
body_57.SetRot(chrono.ChQuaternionD(0.999147807995971,-1.93552865822696e-05,0.0412727252885812,-0.000468561066093758))
body_57.SetMass(8.44776262879024)
body_57.SetInertiaXX(chrono.ChVectorD(0.11496494349016,0.723349083568589,0.823884312212851))
body_57.SetInertiaXY(chrono.ChVectorD(0.00405542478900021,-0.0591110909356658,0.0017300122666693))
body_57.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.00309747019490024,0.11726872541838,-0.0225919700688117),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_8_1_shape = chrono.ChObjShapeFile() 
body_8_1_shape.SetFilename(shapes_dir +'body_8_1.obj') 
body_8_1_level = chrono.ChAssetLevel() 
body_8_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_8_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_8_1_level.GetAssets().push_back(body_8_1_shape) 
body_57.GetAssets().push_back(body_8_1_level) 

exported_items.append(body_57)



# Rigid body part
body_58= chrono.ChBodyAuxRef()
body_58.SetName('M-410iB-300 -3/M-410iB-300-11-1')
body_58.SetPos(chrono.ChVectorD(1.92042610465864,3.02764258400503,-2.9082681284948))
body_58.SetRot(chrono.ChQuaternionD(0.886426585056933,-0.019044006146155,0.0366164451753445,-0.461025455996663))
body_58.SetMass(2.26635866531324)
body_58.SetInertiaXX(chrono.ChVectorD(0.342444567987369,0.170720483056036,0.50549125464023))
body_58.SetInertiaXY(chrono.ChVectorD(-0.237000685043158,-0.0239698113746433,-0.0341783798169186))
body_58.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.650000000546567,-0.000267013560427986,-4.19077490083408e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_12_1_shape = chrono.ChObjShapeFile() 
body_12_1_shape.SetFilename(shapes_dir +'body_12_1.obj') 
body_12_1_level = chrono.ChAssetLevel() 
body_12_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_12_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_12_1_level.GetAssets().push_back(body_12_1_shape) 
body_58.GetAssets().push_back(body_12_1_level) 

exported_items.append(body_58)



# Rigid body part
body_59= chrono.ChBodyAuxRef()
body_59.SetName('M-410iB-300 -3/M-410iB-300-10-1')
body_59.SetPos(chrono.ChVectorD(-0.277686877786653,2.78749692402101,-2.83238395939945))
body_59.SetRot(chrono.ChQuaternionD(0.773755292789647,-0.0261123387416691,0.0319622275946799,-0.632138678339361))
body_59.SetMass(2.24487855545089)
body_59.SetInertiaXX(chrono.ChVectorD(0.0179735699808056,0.41151320286575,0.428952544587403))
body_59.SetInertiaXY(chrono.ChVectorD(0.0835568879793482,-7.20152596639639e-06,-3.53811009408747e-05))
body_59.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-7.01342378264397e-15,0.610001635976697,-2.13860676946225e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_10_1_shape = chrono.ChObjShapeFile() 
body_10_1_shape.SetFilename(shapes_dir +'body_10_1.obj') 
body_10_1_level = chrono.ChAssetLevel() 
body_10_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_10_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_10_1_level.GetAssets().push_back(body_10_1_shape) 
body_59.GetAssets().push_back(body_10_1_level) 

exported_items.append(body_59)



# Rigid body part
body_60= chrono.ChBodyAuxRef()
body_60.SetName('M-410iB-300 -3/M-410iB-300-08-1')
body_60.SetPos(chrono.ChVectorD(-0.0775367664377189,3.00995602354016,-2.60085180219003))
body_60.SetRot(chrono.ChQuaternionD(0.77457390871473,-0.0260708930553939,0.0319960429220246,-0.631135343417726))
body_60.SetMass(7.16874140056196)
body_60.SetInertiaXX(chrono.ChVectorD(0.0767803688734156,1.02488822982072,1.09908804347467))
body_60.SetInertiaXY(chrono.ChVectorD(0.211091413570172,1.79884424153821e-05,-0.00250201297676742))
body_60.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0995028745288738,0.617303418169042,1.66091348067148e-08),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_9_1_shape = chrono.ChObjShapeFile() 
body_9_1_shape.SetFilename(shapes_dir +'body_9_1.obj') 
body_9_1_level = chrono.ChAssetLevel() 
body_9_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_9_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_9_1_level.GetAssets().push_back(body_9_1_shape) 
body_60.GetAssets().push_back(body_9_1_level) 

exported_items.append(body_60)



# Rigid body part
body_61= chrono.ChBodyAuxRef()
body_61.SetName('Part3^SPIDER_ROBOT-1')
body_61.SetPos(chrono.ChVectorD(-0.620670357955037,1.94456417249918,0.727403113437383))
body_61.SetRot(chrono.ChQuaternionD(1.74574066942157e-15,1,0,0))
body_61.SetMass(1472.20792264893)
body_61.SetInertiaXX(chrono.ChVectorD(1948.56933336626,2184.15530557198,283.239773065818))
body_61.SetInertiaXY(chrono.ChVectorD(-1.01016366442045e-05,0.000194532690206272,5.8301693938204))
body_61.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.200000019877454,0.0526986503540631,1.84480172081189),chrono.ChQuaternionD(1,0,0,0)))
body_61.SetBodyFixed(True)

# Visualization shape 
body_61_1_shape = chrono.ChObjShapeFile() 
body_61_1_shape.SetFilename(shapes_dir +'body_61_1.obj') 
body_61_1_level = chrono.ChAssetLevel() 
body_61_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_61_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_61_1_level.GetAssets().push_back(body_61_1_shape) 
body_61.GetAssets().push_back(body_61_1_level) 

exported_items.append(body_61)



# Rigid body part
body_62= chrono.ChBodyAuxRef()
body_62.SetName('M-410iB-300 -1/M-410iB-300-12-1')
body_62.SetPos(chrono.ChVectorD(2.43833354378685,1.53452994138093,0.174864061011822))
body_62.SetRot(chrono.ChQuaternionD(0.999147807992026,-1.93556340972606e-05,0.0412727252884182,-0.000468569478897188))
body_62.SetMass(16.1636065115335)
body_62.SetInertiaXX(chrono.ChVectorD(0.270949711605444,0.400661918859637,0.427371867141467))
body_62.SetInertiaXY(chrono.ChVectorD(-0.0576658362005998,0.0375936407947645,0.062624565533981))
body_62.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0294847451383035,0.131793864973377,-0.039955675141979),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_1_1_shape = chrono.ChObjShapeFile() 
body_1_1_shape.SetFilename(shapes_dir +'body_1_1.obj') 
body_1_1_level = chrono.ChAssetLevel() 
body_1_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_1_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_1_1_level.GetAssets().push_back(body_1_1_shape) 
body_62.GetAssets().push_back(body_1_1_level) 

# Collision shapes 
body_62.GetCollisionModel().ClearModel()
mr = chrono.ChMatrix33D()
mr[0,0]=0; mr[1,0]=0; mr[2,0]=-1 
mr[0,1]=0; mr[1,1]=-1; mr[2,1]=0 
mr[0,2]=-1; mr[1,2]=0; mr[2,2]=0 
body_62.GetCollisionModel().AddCylinder(0.0891514706007005,0.0891514706007005,0.0737653824400992,chrono.ChVectorD(4.57739150408006E-17,0.0737653824400992,0),mr)
body_62.GetCollisionModel().BuildModel()
body_62.SetCollide(True)

exported_items.append(body_62)



# Rigid body part
body_63= chrono.ChBodyAuxRef()
body_63.SetName('M-410iB-300 -1/M-410iB-300-02-1')
body_63.SetPos(chrono.ChVectorD(-0.140670357955037,2.15049691615662,0.37740311343739))
body_63.SetRot(chrono.ChQuaternionD(0.99914791786433,-2.80761023644036e-18,0.0412727298270155,-6.63209111352764e-17))
body_63.SetMass(286.960740367602)
body_63.SetInertiaXX(chrono.ChVectorD(20.3261470881377,23.3528740040787,23.2169905170889))
body_63.SetInertiaXY(chrono.ChVectorD(-5.60160689862223,-0.500091644770905,0.179388605538521))
body_63.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.175382085214385,0.199890816413736,-0.00351536323719578),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_3_1_shape = chrono.ChObjShapeFile() 
body_3_1_shape.SetFilename(shapes_dir +'body_3_1.obj') 
body_3_1_level = chrono.ChAssetLevel() 
body_3_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_3_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_3_1_level.GetAssets().push_back(body_3_1_shape) 
body_63.GetAssets().push_back(body_3_1_level) 

# Auxiliary marker (coordinate system feature)
marker_63_1 =chrono.ChMarker()
marker_63_1.SetName('marker_M1_A')
body_63.AddMarker(marker_63_1)
marker_63_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-0.140670357955037,2.15049691615662,0.37740311343739),chrono.ChQuaternionD(0.520210323845673,-0.520210323845673,-0.478937594018657,-0.478937594018657)))

# Auxiliary marker (coordinate system feature)
marker_63_2 =chrono.ChMarker()
marker_63_2.SetName('marker_M2_B')
body_63.AddMarker(marker_63_2)
marker_63_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(0.237444144337344,2.51549691615662,0.21767389520805),chrono.ChQuaternionD(0.99914791786433,-2.80761023644036E-18,0.0412727298270155,-6.63209111352764E-17)))

exported_items.append(body_63)



# Rigid body part
body_64= chrono.ChBodyAuxRef()
body_64.SetName('M-410iB-300 -1/M-410iB-300-03-1')
body_64.SetPos(chrono.ChVectorD(0.247467333170755,2.51550127212935,0.338832002166601))
body_64.SetRot(chrono.ChQuaternionD(0.773569283596727,-0.0261217409246431,0.0319545439404108,-0.632366290411082))
body_64.SetMass(72.2394925421727)
body_64.SetInertiaXX(chrono.ChVectorD(1.50592710700546,10.8484487852999,11.2634766916778))
body_64.SetInertiaXY(chrono.ChVectorD(2.12067361135961,-0.771273236415114,0.188132550160896))
body_64.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.0436192441530501,0.531901199956275,-0.00110013226020073),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_4_1_shape = chrono.ChObjShapeFile() 
body_4_1_shape.SetFilename(shapes_dir +'body_4_1.obj') 
body_4_1_level = chrono.ChAssetLevel() 
body_4_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_4_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_4_1_level.GetAssets().push_back(body_4_1_shape) 
body_64.GetAssets().push_back(body_4_1_level) 

# Auxiliary marker (coordinate system feature)
marker_64_1 =chrono.ChMarker()
marker_64_1.SetName('marker_M2_A')
body_64.AddMarker(marker_64_1)
marker_64_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(0.234188396117153,2.51550127212935,0.178375167536711),chrono.ChQuaternionD(0.994146578292323,0.00412441456577471,0.0410661348542013,0.0998455940054075)))

# Auxiliary marker (coordinate system feature)
marker_64_2 =chrono.ChMarker()
marker_64_2.SetName('marker_M3_B')
body_64.AddMarker(marker_64_2)
marker_64_2.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(1.42574833632556,2.75811166841886,0.0797651614368333),chrono.ChQuaternionD(0.994146578292323,0.00412441456577471,0.0410661348542013,0.0998455940054075)))

exported_items.append(body_64)



# Rigid body part
body_65= chrono.ChBodyAuxRef()
body_65.SetName('M-410iB-300 -1/ArmBase-1')
body_65.SetPos(chrono.ChVectorD(-0.140670357955037,1.75770592148926,0.37740311343739))
body_65.SetRot(chrono.ChQuaternionD(1,0,0,0))
body_65.SetMass(29.4636133436255)
body_65.SetInertiaXX(chrono.ChVectorD(0.754351795243641,1.45825924231452,0.754351795243641))
body_65.SetInertiaXY(chrono.ChVectorD(-1.65340831304039e-18,-2.64545330086463e-17,8.26704156520197e-18))
body_65.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-9.77354995986777e-18,0.231605672678633,-6.24094154063845e-18),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_2_1_shape = chrono.ChObjShapeFile() 
body_2_1_shape.SetFilename(shapes_dir +'body_2_1.obj') 
body_2_1_level = chrono.ChAssetLevel() 
body_2_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_2_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_2_1_level.GetAssets().push_back(body_2_1_shape) 
body_65.GetAssets().push_back(body_2_1_level) 

# Auxiliary marker (coordinate system feature)
marker_65_1 =chrono.ChMarker()
marker_65_1.SetName('marker_M1_B')
body_65.AddMarker(marker_65_1)
marker_65_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(-0.140670357955037,1.75770592148926,0.37740311343739),chrono.ChQuaternionD(0.5,-0.5,-0.5,-0.5)))

exported_items.append(body_65)



# Rigid body part
body_66= chrono.ChBodyAuxRef()
body_66.SetName('M-410iB-300 -1/M-410iB-300-11-1')
body_66.SetPos(chrono.ChVectorD(1.92042610465864,3.02764258400502,-0.00826812849479813))
body_66.SetRot(chrono.ChQuaternionD(0.886426585056933,-0.019044006146155,0.0366164451753445,-0.461025455996663))
body_66.SetMass(2.26635866531324)
body_66.SetInertiaXX(chrono.ChVectorD(0.342444567987369,0.170720483056036,0.50549125464023))
body_66.SetInertiaXY(chrono.ChVectorD(-0.237000685043158,-0.0239698113746433,-0.0341783798169186))
body_66.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.650000000546567,-0.000267013560427986,-4.19077490083408e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_12_1_shape = chrono.ChObjShapeFile() 
body_12_1_shape.SetFilename(shapes_dir +'body_12_1.obj') 
body_12_1_level = chrono.ChAssetLevel() 
body_12_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_12_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_12_1_level.GetAssets().push_back(body_12_1_shape) 
body_66.GetAssets().push_back(body_12_1_level) 

exported_items.append(body_66)



# Rigid body part
body_67= chrono.ChBodyAuxRef()
body_67.SetName('M-410iB-300 -1/M-410iB-300-05-1')
body_67.SetPos(chrono.ChVectorD(0.594774142300033,2.77437870841746,0.573302648884808))
body_67.SetRot(chrono.ChQuaternionD(0.699860409425343,-0.0294561142756602,0.0289097831045659,-0.713086228370467))
body_67.SetMass(44.264758578016)
body_67.SetInertiaXX(chrono.ChVectorD(0.419802161252818,2.77625004306057,2.76548569075428))
body_67.SetInertiaXY(chrono.ChVectorD(-0.0398199766034855,-0.0533803242613383,-5.78878132818095e-05))
body_67.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-5.19600690940307e-06,0.410805913274014,-0.00264008387504332),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_7_1_shape = chrono.ChObjShapeFile() 
body_7_1_shape.SetFilename(shapes_dir +'body_7_1.obj') 
body_7_1_level = chrono.ChAssetLevel() 
body_7_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_7_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_7_1_level.GetAssets().push_back(body_7_1_shape) 
body_67.GetAssets().push_back(body_7_1_level) 

exported_items.append(body_67)



# Rigid body part
body_68= chrono.ChBodyAuxRef()
body_68.SetName('M-410iB-300 -1/M-410iB-300-04-1')
body_68.SetPos(chrono.ChVectorD(0.269877838330444,2.78048238827907,0.600190114160508))
body_68.SetRot(chrono.ChQuaternionD(-0.474433745777481,-0.483399481584651,-0.515318353824203,0.525056717206011))
body_68.SetMass(1.58709182620022)
body_68.SetInertiaXX(chrono.ChVectorD(0.112490505154964,0.112340274058519,0.00107509254003515))
body_68.SetInertiaXY(chrono.ChVectorD(7.64900044070236e-06,8.49929897824014e-05,-0.00311323795964494))
body_68.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.002504718931018,0.259643195204338,6.66879538413068e-09),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_6_1_shape = chrono.ChObjShapeFile() 
body_6_1_shape.SetFilename(shapes_dir +'body_6_1.obj') 
body_6_1_level = chrono.ChAssetLevel() 
body_6_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_6_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_6_1_level.GetAssets().push_back(body_6_1_shape) 
body_68.GetAssets().push_back(body_6_1_level) 

exported_items.append(body_68)



# Rigid body part
body_69= chrono.ChBodyAuxRef()
body_69.SetName('M-410iB-300 -1/M-410iB-300-10-1')
body_69.SetPos(chrono.ChVectorD(-0.27768687778666,2.78749692402101,0.0676160406005512))
body_69.SetRot(chrono.ChQuaternionD(0.773755292789647,-0.0261123387416691,0.0319622275946799,-0.632138678339361))
body_69.SetMass(2.24487855545089)
body_69.SetInertiaXX(chrono.ChVectorD(0.0179735699808056,0.41151320286575,0.428952544587403))
body_69.SetInertiaXY(chrono.ChVectorD(0.0835568879793482,-7.20152596639639e-06,-3.53811009408747e-05))
body_69.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-7.01342378264397e-15,0.610001635976697,-2.13860676946225e-05),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_10_1_shape = chrono.ChObjShapeFile() 
body_10_1_shape.SetFilename(shapes_dir +'body_10_1.obj') 
body_10_1_level = chrono.ChAssetLevel() 
body_10_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_10_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_10_1_level.GetAssets().push_back(body_10_1_shape) 
body_69.GetAssets().push_back(body_10_1_level) 

exported_items.append(body_69)



# Rigid body part
body_70= chrono.ChBodyAuxRef()
body_70.SetName('M-410iB-300 -1/M-410iB-300-08-1')
body_70.SetPos(chrono.ChVectorD(-0.0775367664377177,3.00995602354016,0.299148197809966))
body_70.SetRot(chrono.ChQuaternionD(0.77457390871473,-0.0260708930553939,0.0319960429220246,-0.631135343417726))
body_70.SetMass(7.16874140056196)
body_70.SetInertiaXX(chrono.ChVectorD(0.0767803688734156,1.02488822982072,1.09908804347467))
body_70.SetInertiaXY(chrono.ChVectorD(0.211091413570172,1.79884424153821e-05,-0.00250201297676742))
body_70.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.0995028745288738,0.617303418169042,1.66091348067148e-08),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_9_1_shape = chrono.ChObjShapeFile() 
body_9_1_shape.SetFilename(shapes_dir +'body_9_1.obj') 
body_9_1_level = chrono.ChAssetLevel() 
body_9_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_9_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_9_1_level.GetAssets().push_back(body_9_1_shape) 
body_70.GetAssets().push_back(body_9_1_level) 

exported_items.append(body_70)



# Rigid body part
body_71= chrono.ChBodyAuxRef()
body_71.SetName('M-410iB-300 -1/M-410iB-300-09-1')
body_71.SetPos(chrono.ChVectorD(1.41934259561724,2.75811166841883,0.00236100827493541))
body_71.SetRot(chrono.ChQuaternionD(0.999147807995971,-1.93552865822696e-05,0.0412727252885812,-0.000468561066093758))
body_71.SetMass(8.44776262879024)
body_71.SetInertiaXX(chrono.ChVectorD(0.11496494349016,0.723349083568589,0.823884312212851))
body_71.SetInertiaXY(chrono.ChVectorD(0.00405542478900021,-0.0591110909356658,0.0017300122666693))
body_71.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.00309747019490024,0.11726872541838,-0.0225919700688117),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_8_1_shape = chrono.ChObjShapeFile() 
body_8_1_shape.SetFilename(shapes_dir +'body_8_1.obj') 
body_8_1_level = chrono.ChAssetLevel() 
body_8_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_8_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_8_1_level.GetAssets().push_back(body_8_1_shape) 
body_71.GetAssets().push_back(body_8_1_level) 

exported_items.append(body_71)



# Rigid body part
body_72= chrono.ChBodyAuxRef()
body_72.SetName('M-410iB-300 -1/M-410iB-300-07-1')
body_72.SetPos(chrono.ChVectorD(0.247503474379928,2.51550127212935,0.33926871664175))
body_72.SetRot(chrono.ChQuaternionD(0.888019269219919,-0.0189169716008925,0.0366822356573978,-0.457950149324953))
body_72.SetMass(6.52835644128616)
body_72.SetInertiaXX(chrono.ChVectorD(0.209548892318939,0.126804951174011,0.313789004836593))
body_72.SetInertiaXY(chrono.ChVectorD(-0.133468000042266,-0.014695331293433,-0.0204548709922948))
body_72.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(-0.244379956813902,-0.0286291495785353,-0.0666992297731388),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_11_1_shape = chrono.ChObjShapeFile() 
body_11_1_shape.SetFilename(shapes_dir +'body_11_1.obj') 
body_11_1_level = chrono.ChAssetLevel() 
body_11_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_11_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_11_1_level.GetAssets().push_back(body_11_1_shape) 
body_72.GetAssets().push_back(body_11_1_level) 

exported_items.append(body_72)



# Rigid body part
body_73= chrono.ChBodyAuxRef()
body_73.SetName('M-410iB-300 -1/M-410iB-300-06-1')
body_73.SetPos(chrono.ChVectorD(1.44321244386273,2.75811166841885,0.29079375534754))
body_73.SetRot(chrono.ChQuaternionD(0.886426582844683,-0.0190440063218605,0.0366164450839609,-0.461025460250217))
body_73.SetMass(57.487443257986)
body_73.SetInertiaXX(chrono.ChVectorD(7.9742261479953,5.28772781730799,12.6893237121296))
body_73.SetInertiaXY(chrono.ChVectorD(-5.71514273781038,-0.673403451868731,-0.929928236179133))
body_73.SetFrame_COG_to_REF(chrono.ChFrameD(chrono.ChVectorD(0.216990574023306,0.112589145111018,-0.097224117310279),chrono.ChQuaternionD(1,0,0,0)))

# Visualization shape 
body_5_1_shape = chrono.ChObjShapeFile() 
body_5_1_shape.SetFilename(shapes_dir +'body_5_1.obj') 
body_5_1_level = chrono.ChAssetLevel() 
body_5_1_level.GetFrame().SetPos(chrono.ChVectorD(0,0,0)) 
body_5_1_level.GetFrame().SetRot(chrono.ChQuaternionD(1,0,0,0)) 
body_5_1_level.GetAssets().push_back(body_5_1_shape) 
body_73.GetAssets().push_back(body_5_1_level) 

# Auxiliary marker (coordinate system feature)
marker_73_1 =chrono.ChMarker()
marker_73_1.SetName('marker_M3_A')
body_73.AddMarker(marker_73_1)
marker_73_1.Impose_Abs_Coord(chrono.ChCoordsysD(chrono.ChVectorD(1.43001641665603,2.75811166324713,0.131338856251638),chrono.ChQuaternionD(0.959076201512031,0.0115713379289103,0.0396174502701619,0.280123903774525)))

exported_items.append(body_73)




# Mate constraint: Coincident1 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_61 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_65 , SW name: M-410iB-300 -1/ArmBase-1 ,  SW ref.type:2 (2)

link_1 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.620670357955037,1.94456417249918,0.727403113437383)
cB = chrono.ChVectorD(-0.140670357955037,1.94456417249918,0.37740311343739)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
dB = chrono.ChVectorD(0,-1,0)
link_1.Initialize(body_61,body_65,False,cA,cB,dB)
link_1.SetDistance(0)
link_1.SetName("Coincident1")
exported_items.append(link_1)

link_2 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.620670357955037,1.94456417249918,0.727403113437383)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
cB = chrono.ChVectorD(-0.140670357955037,1.94456417249918,0.37740311343739)
dB = chrono.ChVectorD(0,-1,0)
link_2.SetFlipped(True)
link_2.Initialize(body_61,body_65,False,cA,cB,dA,dB)
link_2.SetName("Coincident1")
exported_items.append(link_2)


# Mate constraint: Distance1 [MateDistanceDim] type:5 align:0 flip:False
#   Entity 0: C::E name: body_65 , SW name: M-410iB-300 -1/ArmBase-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_61 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)

link_3 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.460670357955037,1.94456417249918,0.69740311343739)
cB = chrono.ChVectorD(-0.620670357955037,1.69456417249918,0.727403113437384)
dA = chrono.ChVectorD(0,0,1)
dB = chrono.ChVectorD(0,3.49148133884313e-15,1)
link_3.Initialize(body_65,body_61,False,cA,cB,dB)
link_3.SetDistance(-0.03)
link_3.SetName("Distance1")
exported_items.append(link_3)

link_4 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.460670357955037,1.94456417249918,0.69740311343739)
dA = chrono.ChVectorD(0,0,1)
cB = chrono.ChVectorD(-0.620670357955037,1.69456417249918,0.727403113437384)
dB = chrono.ChVectorD(0,3.49148133884313e-15,1)
link_4.Initialize(body_65,body_61,False,cA,cB,dA,dB)
link_4.SetName("Distance1")
exported_items.append(link_4)


# Mate constraint: Coincident3 [MateCoincident] type:0 align:2 flip:False
#   Entity 0: C::E name: body_61 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_65 , SW name: M-410iB-300 -1/ArmBase-1 ,  SW ref.type:1 (1)

link_5 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.179329642044963,1.69456417249918,0.727403113437384)
cB = chrono.ChVectorD(0.179329642044963,1.94456417249918,0.37740311343739)
dA = chrono.ChVectorD(1,5.53760424633245e-31,1.58603289232165e-16)
dB = chrono.ChVectorD(1,0,0)
link_5.Initialize(body_65,body_61,False,cB,cA,dA)
link_5.SetDistance(0)
link_5.SetName("Coincident3")
exported_items.append(link_5)


# ChLinkMateOrthogonal skipped because directions not orthogonal! 

# Mate constraint: Coincident4_issue [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_44 , SW name: M-410iB-300 -2/ArmBase-1 ,  SW ref.type:1 (1)
#   Entity 1: C::E name: body_61 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)

link_6 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.179329642044963,1.94456417249918,-1.07259688656261)
cB = chrono.ChVectorD(0.179329642044963,1.69456417249918,-0.722596886562616)
dA = chrono.ChVectorD(1,0,0)
dB = chrono.ChVectorD(1,5.53760424633245e-31,1.58603289232165e-16)
link_6.Initialize(body_44,body_61,False,cA,cB,dB)
link_6.SetDistance(0)
link_6.SetName("Coincident4_issue")
exported_items.append(link_6)


# ChLinkMateOrthogonal skipped because directions not orthogonal! 

# Mate constraint: Coincident5 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_61 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_44 , SW name: M-410iB-300 -2/ArmBase-1 ,  SW ref.type:2 (2)

link_7 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.620670357955037,1.94456417249918,-0.722596886562617)
cB = chrono.ChVectorD(-0.140670357955037,1.94456417249918,-1.07259688656261)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
dB = chrono.ChVectorD(0,-1,0)
link_7.Initialize(body_61,body_44,False,cA,cB,dB)
link_7.SetDistance(0)
link_7.SetName("Coincident5")
exported_items.append(link_7)

link_8 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.620670357955037,1.94456417249918,-0.722596886562617)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
cB = chrono.ChVectorD(-0.140670357955037,1.94456417249918,-1.07259688656261)
dB = chrono.ChVectorD(0,-1,0)
link_8.SetFlipped(True)
link_8.Initialize(body_61,body_44,False,cA,cB,dA,dB)
link_8.SetName("Coincident5")
exported_items.append(link_8)


# Mate constraint: Distance2 [MateDistanceDim] type:5 align:0 flip:False
#   Entity 0: C::E name: body_44 , SW name: M-410iB-300 -2/ArmBase-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_61 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)

link_9 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.460670357955037,1.94456417249918,-1.39259688656261)
cB = chrono.ChVectorD(-0.620670357955037,1.69456417249917,-1.42259688656262)
dA = chrono.ChVectorD(0,0,-1)
dB = chrono.ChVectorD(0,-3.49148133884313e-15,-1)
link_9.Initialize(body_44,body_61,False,cA,cB,dB)
link_9.SetDistance(-0.03)
link_9.SetName("Distance2")
exported_items.append(link_9)

link_10 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.460670357955037,1.94456417249918,-1.39259688656261)
dA = chrono.ChVectorD(0,0,-1)
cB = chrono.ChVectorD(-0.620670357955037,1.69456417249917,-1.42259688656262)
dB = chrono.ChVectorD(0,-3.49148133884313e-15,-1)
link_10.Initialize(body_44,body_61,False,cA,cB,dA,dB)
link_10.SetName("Distance2")
exported_items.append(link_10)


# Mate constraint: Coincident7 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_61 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_53 , SW name: M-410iB-300 -3/ArmBase-1 ,  SW ref.type:2 (2)

link_11 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.620670357955037,1.94456417249917,-2.17259688656262)
cB = chrono.ChVectorD(-0.140670357955037,1.94456417249918,-2.52259688656261)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
dB = chrono.ChVectorD(0,-1,0)
link_11.Initialize(body_61,body_53,False,cA,cB,dB)
link_11.SetDistance(0)
link_11.SetName("Coincident7")
exported_items.append(link_11)

link_12 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.620670357955037,1.94456417249917,-2.17259688656262)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
cB = chrono.ChVectorD(-0.140670357955037,1.94456417249918,-2.52259688656261)
dB = chrono.ChVectorD(0,-1,0)
link_12.SetFlipped(True)
link_12.Initialize(body_61,body_53,False,cA,cB,dA,dB)
link_12.SetName("Coincident7")
exported_items.append(link_12)


# Mate constraint: Distance3 [MateDistanceDim] type:5 align:0 flip:False
#   Entity 0: C::E name: body_53 , SW name: M-410iB-300 -3/ArmBase-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_61 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)

link_13 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.460670357955037,1.94456417249918,-2.84259688656261)
cB = chrono.ChVectorD(-0.620670357955037,1.69456417249917,-2.87259688656262)
dA = chrono.ChVectorD(0,0,-1)
dB = chrono.ChVectorD(0,-3.49148133884313e-15,-1)
link_13.Initialize(body_53,body_61,False,cA,cB,dB)
link_13.SetDistance(-0.03)
link_13.SetName("Distance3")
exported_items.append(link_13)

link_14 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.460670357955037,1.94456417249918,-2.84259688656261)
dA = chrono.ChVectorD(0,0,-1)
cB = chrono.ChVectorD(-0.620670357955037,1.69456417249917,-2.87259688656262)
dB = chrono.ChVectorD(0,-3.49148133884313e-15,-1)
link_14.Initialize(body_53,body_61,False,cA,cB,dA,dB)
link_14.SetName("Distance3")
exported_items.append(link_14)


# Mate constraint: Coincident9 [MateCoincident] type:0 align:2 flip:False
#   Entity 0: C::E name: body_61 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_53 , SW name: M-410iB-300 -3/ArmBase-1 ,  SW ref.type:1 (1)

link_15 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.179329642044963,1.69456417249917,-2.17259688656262)
cB = chrono.ChVectorD(0.179329642044963,1.94456417249918,-2.52259688656261)
dA = chrono.ChVectorD(1,5.53760424633245e-31,1.58603289232165e-16)
dB = chrono.ChVectorD(1,0,0)
link_15.Initialize(body_53,body_61,False,cB,cA,dA)
link_15.SetDistance(0)
link_15.SetName("Coincident9")
exported_items.append(link_15)


# ChLinkMateOrthogonal skipped because directions not orthogonal! 

# Mate constraint: Coincident11 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_61 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_17 , SW name: M-410iB-300 -7/ArmBase-1 ,  SW ref.type:2 (2)

link_16 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.82067035795504,1.69456417249917,-2.17259688656262)
cB = chrono.ChVectorD(-1.82067035795504,1.94456417249917,-2.20259688656262)
dA = chrono.ChVectorD(-1,-3.01405864546147e-31,-8.63260705973055e-17)
dB = chrono.ChVectorD(-1,-6.4208392745669e-17,-2.17109494630873e-16)
link_16.Initialize(body_61,body_17,False,cA,cB,dB)
link_16.SetDistance(0)
link_16.SetName("Coincident11")
exported_items.append(link_16)

link_17 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.82067035795504,1.69456417249917,-2.17259688656262)
dA = chrono.ChVectorD(-1,-3.01405864546147e-31,-8.63260705973055e-17)
cB = chrono.ChVectorD(-1.82067035795504,1.94456417249917,-2.20259688656262)
dB = chrono.ChVectorD(-1,-6.4208392745669e-17,-2.17109494630873e-16)
link_17.Initialize(body_61,body_17,False,cA,cB,dA,dB)
link_17.SetName("Coincident11")
exported_items.append(link_17)


# Mate constraint: Coincident12 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_61 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_32 , SW name: M-410iB-300 -8/ArmBase-1 ,  SW ref.type:2 (2)

link_18 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.02067035795504,1.94456417249918,-0.722596886562617)
cB = chrono.ChVectorD(-1.50067035795504,1.94456417249918,-1.07259688656262)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
dB = chrono.ChVectorD(-5.42136132923115e-17,-1,3.51853802391695e-15)
link_18.Initialize(body_61,body_32,False,cA,cB,dB)
link_18.SetDistance(0)
link_18.SetName("Coincident12")
exported_items.append(link_18)

link_19 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.02067035795504,1.94456417249918,-0.722596886562617)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
cB = chrono.ChVectorD(-1.50067035795504,1.94456417249918,-1.07259688656262)
dB = chrono.ChVectorD(-5.42136132923115e-17,-1,3.51853802391695e-15)
link_19.SetFlipped(True)
link_19.Initialize(body_61,body_32,False,cA,cB,dA,dB)
link_19.SetName("Coincident12")
exported_items.append(link_19)


# Mate constraint: Coincident14 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_61 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_2 , SW name: M-410iB-300 -9/ArmBase-1 ,  SW ref.type:2 (2)

link_20 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.02067035795504,1.94456417249918,0.727403113437383)
cB = chrono.ChVectorD(-1.50067035795504,1.94456417249918,0.377403113437383)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
dB = chrono.ChVectorD(6.21947280249299e-17,-1,3.55871276754624e-15)
link_20.Initialize(body_61,body_2,False,cA,cB,dB)
link_20.SetDistance(0)
link_20.SetName("Coincident14")
exported_items.append(link_20)

link_21 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.02067035795504,1.94456417249918,0.727403113437383)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
cB = chrono.ChVectorD(-1.50067035795504,1.94456417249918,0.377403113437383)
dB = chrono.ChVectorD(6.21947280249299e-17,-1,3.55871276754624e-15)
link_21.SetFlipped(True)
link_21.Initialize(body_61,body_2,False,cA,cB,dA,dB)
link_21.SetName("Coincident14")
exported_items.append(link_21)


# Mate constraint: Coincident16 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_61 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_2 , SW name: M-410iB-300 -9/ArmBase-1 ,  SW ref.type:2 (2)

link_22 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.82067035795504,1.69456417249918,0.727403113437384)
cB = chrono.ChVectorD(-1.82067035795504,1.94456417249918,0.697403113437383)
dA = chrono.ChVectorD(-1,-3.01405864546147e-31,-8.63260705973055e-17)
dB = chrono.ChVectorD(-1,-6.21947280249306e-17,-2.22044604925031e-16)
link_22.Initialize(body_61,body_2,False,cA,cB,dB)
link_22.SetDistance(0)
link_22.SetName("Coincident16")
exported_items.append(link_22)

link_23 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.82067035795504,1.69456417249918,0.727403113437384)
dA = chrono.ChVectorD(-1,-3.01405864546147e-31,-8.63260705973055e-17)
cB = chrono.ChVectorD(-1.82067035795504,1.94456417249918,0.697403113437383)
dB = chrono.ChVectorD(-1,-6.21947280249306e-17,-2.22044604925031e-16)
link_23.Initialize(body_61,body_2,False,cA,cB,dA,dB)
link_23.SetName("Coincident16")
exported_items.append(link_23)


# Mate constraint: Coincident17 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_61 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_17 , SW name: M-410iB-300 -7/ArmBase-1 ,  SW ref.type:2 (2)

link_24 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.02067035795504,1.94456417249917,-2.17259688656262)
cB = chrono.ChVectorD(-1.50067035795504,1.94456417249917,-2.52259688656262)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
dB = chrono.ChVectorD(6.42083927456682e-17,-1,3.44169137633798e-15)
link_24.Initialize(body_61,body_17,False,cA,cB,dB)
link_24.SetDistance(0)
link_24.SetName("Coincident17")
exported_items.append(link_24)

link_25 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.02067035795504,1.94456417249917,-2.17259688656262)
dA = chrono.ChVectorD(0,1,-3.49148133884313e-15)
cB = chrono.ChVectorD(-1.50067035795504,1.94456417249917,-2.52259688656262)
dB = chrono.ChVectorD(6.42083927456682e-17,-1,3.44169137633798e-15)
link_25.SetFlipped(True)
link_25.Initialize(body_61,body_17,False,cA,cB,dA,dB)
link_25.SetName("Coincident17")
exported_items.append(link_25)


# Mate constraint: Coincident18 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_61 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_32 , SW name: M-410iB-300 -8/ArmBase-1 ,  SW ref.type:2 (2)

link_26 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.82067035795504,1.69456417249918,-0.722596886562616)
cB = chrono.ChVectorD(-1.82067035795504,1.94456417249918,-0.752596886562616)
dA = chrono.ChVectorD(-1,-3.01405864546147e-31,-8.63260705973055e-17)
dB = chrono.ChVectorD(-1,3.54053086910991e-17,-1.2490009027033e-16)
link_26.Initialize(body_61,body_32,False,cA,cB,dB)
link_26.SetDistance(0)
link_26.SetName("Coincident18")
exported_items.append(link_26)

link_27 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.82067035795504,1.69456417249918,-0.722596886562616)
dA = chrono.ChVectorD(-1,-3.01405864546147e-31,-8.63260705973055e-17)
cB = chrono.ChVectorD(-1.82067035795504,1.94456417249918,-0.752596886562616)
dB = chrono.ChVectorD(-1,3.54053086910991e-17,-1.2490009027033e-16)
link_27.Initialize(body_61,body_32,False,cA,cB,dA,dB)
link_27.SetName("Coincident18")
exported_items.append(link_27)


# Mate constraint: Distance4 [MateDistanceDim] type:5 align:0 flip:True
#   Entity 0: C::E name: body_61 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_17 , SW name: M-410iB-300 -7/ArmBase-1 ,  SW ref.type:2 (2)

link_28 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.02067035795504,1.69456417249917,-2.87259688656262)
cB = chrono.ChVectorD(-1.18067035795504,1.94456417249917,-2.84259688656262)
dA = chrono.ChVectorD(2.44929359829471e-16,-3.49148133884313e-15,-1)
dB = chrono.ChVectorD(2.17109494630873e-16,-3.44169137633798e-15,-1)
link_28.Initialize(body_61,body_17,False,cA,cB,dB)
link_28.SetDistance(0.0300000000000003)
link_28.SetName("Distance4")
exported_items.append(link_28)

link_29 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.02067035795504,1.69456417249917,-2.87259688656262)
dA = chrono.ChVectorD(2.44929359829471e-16,-3.49148133884313e-15,-1)
cB = chrono.ChVectorD(-1.18067035795504,1.94456417249917,-2.84259688656262)
dB = chrono.ChVectorD(2.17109494630873e-16,-3.44169137633798e-15,-1)
link_29.Initialize(body_61,body_17,False,cA,cB,dA,dB)
link_29.SetName("Distance4")
exported_items.append(link_29)


# Mate constraint: Distance5 [MateDistanceDim] type:5 align:0 flip:True
#   Entity 0: C::E name: body_61 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_32 , SW name: M-410iB-300 -8/ArmBase-1 ,  SW ref.type:2 (2)

link_30 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.02067035795504,1.69456417249917,-1.42259688656262)
cB = chrono.ChVectorD(-1.18067035795504,1.94456417249917,-1.39259688656262)
dA = chrono.ChVectorD(2.44929359829471e-16,-3.49148133884313e-15,-1)
dB = chrono.ChVectorD(2.77555756156289e-16,-3.70712266049311e-15,-1)
link_30.Initialize(body_61,body_32,False,cA,cB,dB)
link_30.SetDistance(0.03)
link_30.SetName("Distance5")
exported_items.append(link_30)

link_31 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.02067035795504,1.69456417249917,-1.42259688656262)
dA = chrono.ChVectorD(2.44929359829471e-16,-3.49148133884313e-15,-1)
cB = chrono.ChVectorD(-1.18067035795504,1.94456417249917,-1.39259688656262)
dB = chrono.ChVectorD(2.77555756156289e-16,-3.70712266049311e-15,-1)
link_31.Initialize(body_61,body_32,False,cA,cB,dA,dB)
link_31.SetName("Distance5")
exported_items.append(link_31)


# Mate constraint: Distance6 [MateDistanceDim] type:5 align:0 flip:True
#   Entity 0: C::E name: body_61 , SW name: Part3^SPIDER_ROBOT-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_2 , SW name: M-410iB-300 -9/ArmBase-1 ,  SW ref.type:2 (2)

link_32 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.02067035795504,1.69456417249918,0.0274031134373841)
cB = chrono.ChVectorD(-1.18067035795504,1.94456417249918,0.0574031134373831)
dA = chrono.ChVectorD(2.44929359829471e-16,-3.49148133884313e-15,-1)
dB = chrono.ChVectorD(2.22044604925031e-16,-3.55871276754624e-15,-1)
link_32.Initialize(body_61,body_2,False,cA,cB,dB)
link_32.SetDistance(0.03)
link_32.SetName("Distance6")
exported_items.append(link_32)

link_33 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.02067035795504,1.69456417249918,0.0274031134373841)
dA = chrono.ChVectorD(2.44929359829471e-16,-3.49148133884313e-15,-1)
cB = chrono.ChVectorD(-1.18067035795504,1.94456417249918,0.0574031134373831)
dB = chrono.ChVectorD(2.22044604925031e-16,-3.55871276754624e-15,-1)
link_33.Initialize(body_61,body_2,False,cA,cB,dA,dB)
link_33.SetName("Distance6")
exported_items.append(link_33)


# Mate constraint: Coincident2_hinge [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_3 , SW name: M-410iB-300 -9/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_4 , SW name: M-410iB-300 -9/M-410iB-300-03-1 ,  SW ref.type:5 (2)

link_1 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.87878138328858,2.51550127212935,0.537132043923804)
dA = chrono.ChVectorD(0.0824751241424789,3.55158224497465e-15,0.996593123545252)
cB = chrono.ChVectorD(-1.89800452027346,2.51550127212935,0.304848111874134)
dB = chrono.ChVectorD(0.082475124142479,3.64289959343017e-15,0.996593123545252)
link_1.Initialize(body_3,body_4,False,cA,cB,dA,dB)
link_1.SetName("Coincident2_hinge")
exported_items.append(link_1)

link_2 = chrono.ChLinkMateGeneric()
link_2.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.87878138328858,2.51550127212935,0.537132043923804)
cB = chrono.ChVectorD(-1.89800452027346,2.51550127212935,0.304848111874134)
dA = chrono.ChVectorD(0.0824751241424789,3.55158224497465e-15,0.996593123545252)
dB = chrono.ChVectorD(0.082475124142479,3.64289959343017e-15,0.996593123545252)
link_2.Initialize(body_3,body_4,False,cA,cB,dA,dB)
link_2.SetName("Coincident2_hinge")
exported_items.append(link_2)


# Mate constraint: Distance2 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_3 , SW name: M-410iB-300 -9/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_4 , SW name: M-410iB-300 -9/M-410iB-300-03-1 ,  SW ref.type:2 (2)

link_3 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-2.11018861732807,2.84164228947283,0.311448508355134)
cB = chrono.ChVectorD(-2.73620448423209,2.54318522667954,0.366314165207712)
dA = chrono.ChVectorD(0.0824751241424789,3.55158224497465e-15,0.996593123545252)
dB = chrono.ChVectorD(-0.082475124142479,-3.64289959343017e-15,-0.996593123545252)
link_3.Initialize(body_3,body_4,False,cA,cB,dB)
link_3.SetDistance(0)
link_3.SetName("Distance2")
exported_items.append(link_3)

link_4 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.11018861732807,2.84164228947283,0.311448508355134)
dA = chrono.ChVectorD(0.0824751241424789,3.55158224497465e-15,0.996593123545252)
cB = chrono.ChVectorD(-2.73620448423209,2.54318522667954,0.366314165207712)
dB = chrono.ChVectorD(-0.082475124142479,-3.64289959343017e-15,-0.996593123545252)
link_4.SetFlipped(True)
link_4.Initialize(body_3,body_4,False,cA,cB,dA,dB)
link_4.SetName("Distance2")
exported_items.append(link_4)


# Mate constraint: Coincident3 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_3 , SW name: M-410iB-300 -9/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_6 , SW name: M-410iB-300 -9/M-410iB-300-04-1 ,  SW ref.type:5 (2)

link_5 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.90232652265115,2.78049690546384,0.252665289126617)
dA = chrono.ChVectorD(-0.0824751241424789,-3.55158224497465e-15,-0.996593123545252)
cB = chrono.ChVectorD(-1.90809982310587,2.78049690546385,0.182903265812622)
dB = chrono.ChVectorD(-0.0824751241424785,-3.61362613477307e-15,-0.996593123545253)
link_5.Initialize(body_3,body_6,False,cA,cB,dA,dB)
link_5.SetName("Coincident3")
exported_items.append(link_5)

link_6 = chrono.ChLinkMateGeneric()
link_6.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.90232652265115,2.78049690546384,0.252665289126617)
cB = chrono.ChVectorD(-1.90809982310587,2.78049690546385,0.182903265812622)
dA = chrono.ChVectorD(-0.0824751241424789,-3.55158224497465e-15,-0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424785,-3.61362613477307e-15,-0.996593123545253)
link_6.Initialize(body_3,body_6,False,cA,cB,dA,dB)
link_6.SetName("Coincident3")
exported_items.append(link_6)


# Mate constraint: Distance3 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_3 , SW name: M-410iB-300 -9/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_6 , SW name: M-410iB-300 -9/M-410iB-300-04-1 ,  SW ref.type:2 (2)

link_7 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.90600495189008,2.78049691677857,0.208216730897223)
cB = chrono.ChVectorD(-1.97739420838114,2.80967719196082,0.188637865914641)
dA = chrono.ChVectorD(-0.0824751241424789,-3.55158224497465e-15,-0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424785,3.61362613477307e-15,0.996593123545253)
link_7.Initialize(body_3,body_6,False,cA,cB,dB)
link_7.SetDistance(0)
link_7.SetName("Distance3")
exported_items.append(link_7)

link_8 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.90600495189008,2.78049691677857,0.208216730897223)
dA = chrono.ChVectorD(-0.0824751241424789,-3.55158224497465e-15,-0.996593123545252)
cB = chrono.ChVectorD(-1.97739420838114,2.80967719196082,0.188637865914641)
dB = chrono.ChVectorD(0.0824751241424785,3.61362613477307e-15,0.996593123545253)
link_8.SetFlipped(True)
link_8.Initialize(body_3,body_6,False,cA,cB,dA,dB)
link_8.SetName("Distance3")
exported_items.append(link_8)


# Mate constraint: Coincident4 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_6 , SW name: M-410iB-300 -9/M-410iB-300-04-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_7 , SW name: M-410iB-300 -9/M-410iB-300-05-1 ,  SW ref.type:5 (2)

link_9 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.71143288244182,2.76544912375641,0.2208395036847)
dA = chrono.ChVectorD(0.996418499736232,0.0187192635196771,-0.0824606727881726)
cB = chrono.ChVectorD(-3.00015381681411,2.76002505419568,0.24473320146598)
dB = chrono.ChVectorD(0.996418499736232,0.0187192635196772,-0.0824606727881727)
link_9.Initialize(body_6,body_7,False,cA,cB,dA,dB)
link_9.SetName("Coincident4")
exported_items.append(link_9)

link_10 = chrono.ChLinkMateGeneric()
link_10.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-2.71143288244182,2.76544912375641,0.2208395036847)
cB = chrono.ChVectorD(-3.00015381681411,2.76002505419568,0.24473320146598)
dA = chrono.ChVectorD(0.996418499736232,0.0187192635196771,-0.0824606727881726)
dB = chrono.ChVectorD(0.996418499736232,0.0187192635196772,-0.0824606727881727)
link_10.Initialize(body_6,body_7,False,cA,cB,dA,dB)
link_10.SetName("Coincident4")
exported_items.append(link_10)


# Mate constraint: Coincident5 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_4 , SW name: M-410iB-300 -9/M-410iB-300-03-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_7 , SW name: M-410iB-300 -9/M-410iB-300-05-1 ,  SW ref.type:5 (2)

link_11 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.08956446048187,2.75811166841886,0.40345811797401)
dA = chrono.ChVectorD(0.082475124142479,3.64289959343017e-15,0.996593123545252)
cB = chrono.ChVectorD(-3.09911590513996,2.75811166841887,0.288042661918732)
dB = chrono.ChVectorD(0.0824751241424786,3.36978906618108e-15,0.996593123545253)
link_11.Initialize(body_4,body_7,False,cA,cB,dA,dB)
link_11.SetName("Coincident5")
exported_items.append(link_11)

link_12 = chrono.ChLinkMateGeneric()
link_12.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.08956446048187,2.75811166841886,0.40345811797401)
cB = chrono.ChVectorD(-3.09911590513996,2.75811166841887,0.288042661918732)
dA = chrono.ChVectorD(0.082475124142479,3.64289959343017e-15,0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424786,3.36978906618108e-15,0.996593123545253)
link_12.Initialize(body_4,body_7,False,cA,cB,dA,dB)
link_12.SetName("Coincident5")
exported_items.append(link_12)


# Mate constraint: Coincident6 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_4 , SW name: M-410iB-300 -9/M-410iB-300-03-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_5 , SW name: M-410iB-300 -9/M-410iB-300-06-1 ,  SW ref.type:5 (2)

link_13 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.06708905223563,2.75811166841886,0.675041065437937)
dA = chrono.ChVectorD(0.082475124142479,3.64289959343017e-15,0.996593123545252)
cB = chrono.ChVectorD(-3.069707637427,2.75811166841885,0.643399233765363)
dB = chrono.ChVectorD(-0.0824751241424783,-4.53761033121952e-15,-0.996593123545253)
link_13.SetFlipped(True)
link_13.Initialize(body_4,body_5,False,cA,cB,dA,dB)
link_13.SetName("Coincident6")
exported_items.append(link_13)

link_14 = chrono.ChLinkMateGeneric()
link_14.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.06708905223563,2.75811166841886,0.675041065437937)
cB = chrono.ChVectorD(-3.069707637427,2.75811166841885,0.643399233765363)
dA = chrono.ChVectorD(0.082475124142479,3.64289959343017e-15,0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424783,-4.53761033121952e-15,-0.996593123545253)
link_14.Initialize(body_4,body_5,False,cA,cB,dA,dB)
link_14.SetName("Coincident6")
exported_items.append(link_14)


# Mate constraint: Distance4 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_4 , SW name: M-410iB-300 -9/M-410iB-300-03-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_5 , SW name: M-410iB-300 -9/M-410iB-300-06-1 ,  SW ref.type:2 (2)

link_15 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-2.88223000352087,2.91434507456169,0.659742672712353)
cB = chrono.ChVectorD(-2.96321003072938,2.58269164685798,0.634585804166313)
dA = chrono.ChVectorD(-0.082475124142479,-3.64289959343017e-15,-0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424783,4.53761033121952e-15,0.996593123545253)
link_15.Initialize(body_4,body_5,False,cA,cB,dB)
link_15.SetDistance(0)
link_15.SetName("Distance4")
exported_items.append(link_15)

link_16 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.88223000352087,2.91434507456169,0.659742672712353)
dA = chrono.ChVectorD(-0.082475124142479,-3.64289959343017e-15,-0.996593123545252)
cB = chrono.ChVectorD(-2.96321003072938,2.58269164685798,0.634585804166313)
dB = chrono.ChVectorD(0.0824751241424783,4.53761033121952e-15,0.996593123545253)
link_16.SetFlipped(True)
link_16.Initialize(body_4,body_5,False,cA,cB,dA,dB)
link_16.SetName("Distance4")
exported_items.append(link_16)


# Mate constraint: Coincident7 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_3 , SW name: M-410iB-300 -9/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_11 , SW name: M-410iB-300 -9/M-410iB-300-07-1 ,  SW ref.type:5 (2)

link_17 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.90558579863488,2.51550127212935,0.213239278771608)
dA = chrono.ChVectorD(0.0824751241424789,3.55158224497465e-15,0.996593123545252)
cB = chrono.ChVectorD(-1.88095452717193,2.51550127212936,0.510872729092269)
dB = chrono.ChVectorD(-0.0824751241424795,-3.44202403592292e-15,-0.996593123545252)
link_17.SetFlipped(True)
link_17.Initialize(body_3,body_11,False,cA,cB,dA,dB)
link_17.SetName("Coincident7")
exported_items.append(link_17)

link_18 = chrono.ChLinkMateGeneric()
link_18.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.90558579863488,2.51550127212935,0.213239278771608)
cB = chrono.ChVectorD(-1.88095452717193,2.51550127212936,0.510872729092269)
dA = chrono.ChVectorD(0.0824751241424789,3.55158224497465e-15,0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424795,-3.44202403592292e-15,-0.996593123545252)
link_18.Initialize(body_3,body_11,False,cA,cB,dA,dB)
link_18.SetName("Coincident7")
exported_items.append(link_18)


# Mate constraint: Coincident8 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_5 , SW name: M-410iB-300 -9/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_11 , SW name: M-410iB-300 -9/M-410iB-300-07-1 ,  SW ref.type:2 (2)

link_19 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-2.60711943253554,3.10515332885273,0.494740753062384)
cB = chrono.ChVectorD(-1.56768836286924,3.00995602354016,0.408720486132075)
dA = chrono.ChVectorD(0.0824751241424783,4.53761033121952e-15,0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424795,3.44202403592292e-15,0.996593123545252)
link_19.Initialize(body_5,body_11,False,cA,cB,dB)
link_19.SetDistance(0)
link_19.SetName("Coincident8")
exported_items.append(link_19)

link_20 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.60711943253554,3.10515332885273,0.494740753062384)
dA = chrono.ChVectorD(0.0824751241424783,4.53761033121952e-15,0.996593123545253)
cB = chrono.ChVectorD(-1.56768836286924,3.00995602354016,0.408720486132075)
dB = chrono.ChVectorD(0.0824751241424795,3.44202403592292e-15,0.996593123545252)
link_20.Initialize(body_5,body_11,False,cA,cB,dA,dB)
link_20.SetName("Coincident8")
exported_items.append(link_20)


# Mate constraint: Distance5 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_5 , SW name: M-410iB-300 -9/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_9 , SW name: M-410iB-300 -9/M-410iB-300-08-1 ,  SW ref.type:2 (2)

link_21 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-2.60711943253554,3.10515332885273,0.494740753062384)
cB = chrono.ChVectorD(-1.57268463047211,3.01604196029194,0.431307505105991)
dA = chrono.ChVectorD(0.0824751241424783,4.53761033121952e-15,0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424792,-3.92284059436593e-15,-0.996593123545252)
link_21.Initialize(body_5,body_9,False,cA,cB,dB)
link_21.SetDistance(0)
link_21.SetName("Distance5")
exported_items.append(link_21)

link_22 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.60711943253554,3.10515332885273,0.494740753062384)
dA = chrono.ChVectorD(0.0824751241424783,4.53761033121952e-15,0.996593123545253)
cB = chrono.ChVectorD(-1.57268463047211,3.01604196029194,0.431307505105991)
dB = chrono.ChVectorD(-0.0824751241424792,-3.92284059436593e-15,-0.996593123545252)
link_22.SetFlipped(True)
link_22.Initialize(body_5,body_9,False,cA,cB,dA,dB)
link_22.SetName("Distance5")
exported_items.append(link_22)


# Mate constraint: Coincident9 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_5 , SW name: M-410iB-300 -9/M-410iB-300-06-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_9 , SW name: M-410iB-300 -9/M-410iB-300-08-1 ,  SW ref.type:5 (2)

link_23 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.76251640195861,3.2550226500217,0.507600950510807)
dA = chrono.ChVectorD(0.0824751241424783,4.53761033121952e-15,0.996593123545253)
cB = chrono.ChVectorD(-2.76029584171647,3.25502265002173,0.534433223769161)
dB = chrono.ChVectorD(0.0824751241424792,3.92284059436593e-15,0.996593123545252)
link_23.Initialize(body_5,body_9,False,cA,cB,dA,dB)
link_23.SetName("Coincident9")
exported_items.append(link_23)

link_24 = chrono.ChLinkMateGeneric()
link_24.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-2.76251640195861,3.2550226500217,0.507600950510807)
cB = chrono.ChVectorD(-2.76029584171647,3.25502265002173,0.534433223769161)
dA = chrono.ChVectorD(0.0824751241424783,4.53761033121952e-15,0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424792,3.92284059436593e-15,0.996593123545252)
link_24.Initialize(body_5,body_9,False,cA,cB,dA,dB)
link_24.SetName("Coincident9")
exported_items.append(link_24)


# Mate constraint: Coincident10 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_8 , SW name: M-410iB-300 -9/M-410iB-300-09-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_5 , SW name: M-410iB-300 -9/M-410iB-300-06-1 ,  SW ref.type:5 (2)

link_25 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.05620029367895,2.75811166841881,0.806616034423221)
dA = chrono.ChVectorD(-0.0824751241424789,-3.55959220900182e-15,-0.996593123545253)
cB = chrono.ChVectorD(-3.06207868844382,2.75811166841885,0.735584097693298)
dB = chrono.ChVectorD(-0.0824751241424783,-4.53761033121952e-15,-0.996593123545253)
link_25.Initialize(body_8,body_5,False,cA,cB,dA,dB)
link_25.SetName("Coincident10")
exported_items.append(link_25)

link_26 = chrono.ChLinkMateGeneric()
link_26.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.05620029367895,2.75811166841881,0.806616034423221)
cB = chrono.ChVectorD(-3.06207868844382,2.75811166841885,0.735584097693298)
dA = chrono.ChVectorD(-0.0824751241424789,-3.55959220900182e-15,-0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424783,-4.53761033121952e-15,-0.996593123545253)
link_26.Initialize(body_8,body_5,False,cA,cB,dA,dB)
link_26.SetName("Coincident10")
exported_items.append(link_26)


# Mate constraint: Coincident11 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_3 , SW name: M-410iB-300 -9/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_8 , SW name: M-410iB-300 -9/M-410iB-300-09-1 ,  SW ref.type:2 (2)

link_27 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.51318598779731,2.72491052060182,0.672548988128633)
cB = chrono.ChVectorD(-3.05641325164597,3.21365467148157,0.800261950579347)
dA = chrono.ChVectorD(0.0824751241424789,3.55158224497465e-15,0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424789,3.55959220900182e-15,0.996593123545253)
link_27.Initialize(body_3,body_8,False,cA,cB,dB)
link_27.SetDistance(0)
link_27.SetName("Coincident11")
exported_items.append(link_27)

link_28 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.51318598779731,2.72491052060182,0.672548988128633)
dA = chrono.ChVectorD(0.0824751241424789,3.55158224497465e-15,0.996593123545252)
cB = chrono.ChVectorD(-3.05641325164597,3.21365467148157,0.800261950579347)
dB = chrono.ChVectorD(0.0824751241424789,3.55959220900182e-15,0.996593123545253)
link_28.Initialize(body_3,body_8,False,cA,cB,dA,dB)
link_28.SetName("Coincident11")
exported_items.append(link_28)


# Mate constraint: Coincident12 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_8 , SW name: M-410iB-300 -9/M-410iB-300-09-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_10 , SW name: M-410iB-300 -9/M-410iB-300-10-1 ,  SW ref.type:5 (2)

link_29 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.55781544031584,3.03081076163701,0.752627750357551)
dA = chrono.ChVectorD(-0.0824751241424789,-3.55959220900182e-15,-0.996593123545253)
cB = chrono.ChVectorD(-2.55350413567701,3.03081076163707,0.804723659297806)
dB = chrono.ChVectorD(-0.0824751241424783,-3.93682680239099e-15,-0.996593123545252)
link_29.Initialize(body_8,body_10,False,cA,cB,dA,dB)
link_29.SetName("Coincident12")
exported_items.append(link_29)

link_30 = chrono.ChLinkMateGeneric()
link_30.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-2.55781544031584,3.03081076163701,0.752627750357551)
cB = chrono.ChVectorD(-2.55350413567701,3.03081076163707,0.804723659297806)
dA = chrono.ChVectorD(-0.0824751241424789,-3.55959220900182e-15,-0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424783,-3.93682680239099e-15,-0.996593123545252)
link_30.Initialize(body_8,body_10,False,cA,cB,dA,dB)
link_30.SetName("Coincident12")
exported_items.append(link_30)


# Mate constraint: Distance7 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_8 , SW name: M-410iB-300 -9/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_10 , SW name: M-410iB-300 -9/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_31 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.05641325164597,3.21365467148157,0.800261950579347)
cB = chrono.ChVectorD(-2.55704033909974,3.03081076163707,0.761993732532679)
dA = chrono.ChVectorD(0.0824751241424789,3.55959220900182e-15,0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424783,-3.93682680239099e-15,-0.996593123545252)
link_31.Initialize(body_8,body_10,False,cA,cB,dB)
link_31.SetDistance(0)
link_31.SetName("Distance7")
exported_items.append(link_31)

link_32 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.05641325164597,3.21365467148157,0.800261950579347)
dA = chrono.ChVectorD(0.0824751241424789,3.55959220900182e-15,0.996593123545253)
cB = chrono.ChVectorD(-2.55704033909974,3.03081076163707,0.761993732532679)
dB = chrono.ChVectorD(-0.0824751241424783,-3.93682680239099e-15,-0.996593123545252)
link_32.SetFlipped(True)
link_32.Initialize(body_8,body_10,False,cA,cB,dA,dB)
link_32.SetName("Distance7")
exported_items.append(link_32)


# Mate constraint: Coincident13 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_3 , SW name: M-410iB-300 -9/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_10 , SW name: M-410iB-300 -9/M-410iB-300-10-1 ,  SW ref.type:5 (2)

link_33 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.36587439836585,2.78749692402102,0.660357913015888)
dA = chrono.ChVectorD(-0.0824751241424789,-3.55158224497465e-15,-0.996593123545252)
cB = chrono.ChVectorD(-1.36522498923852,2.78749692402103,0.668205087270699)
dB = chrono.ChVectorD(0.0824751241424783,3.93682680239099e-15,0.996593123545252)
link_33.SetFlipped(True)
link_33.Initialize(body_3,body_10,False,cA,cB,dA,dB)
link_33.SetName("Coincident13")
exported_items.append(link_33)

link_34 = chrono.ChLinkMateGeneric()
link_34.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.36587439836585,2.78749692402102,0.660357913015888)
cB = chrono.ChVectorD(-1.36522498923852,2.78749692402103,0.668205087270699)
dA = chrono.ChVectorD(-0.0824751241424789,-3.55158224497465e-15,-0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424783,3.93682680239099e-15,0.996593123545252)
link_34.Initialize(body_3,body_10,False,cA,cB,dA,dB)
link_34.SetName("Coincident13")
exported_items.append(link_34)


# Mate constraint: Coincident14 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_8 , SW name: M-410iB-300 -9/M-410iB-300-09-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_12 , SW name: M-410iB-300 -9/M-410iB-300-11-1 ,  SW ref.type:5 (2)

link_35 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.55579644633163,3.02764258400496,0.835217731582974)
dA = chrono.ChVectorD(-0.0824751241424789,-3.55959220900182e-15,-0.996593123545253)
cB = chrono.ChVectorD(-3.56428066235258,3.02764258400503,0.732698196963912)
dB = chrono.ChVectorD(0.0824751241424785,4.759085730004e-15,0.996593123545252)
link_35.SetFlipped(True)
link_35.Initialize(body_8,body_12,False,cA,cB,dA,dB)
link_35.SetName("Coincident14")
exported_items.append(link_35)

link_36 = chrono.ChLinkMateGeneric()
link_36.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.55579644633163,3.02764258400496,0.835217731582974)
cB = chrono.ChVectorD(-3.56428066235258,3.02764258400503,0.732698196963912)
dA = chrono.ChVectorD(-0.0824751241424789,-3.55959220900182e-15,-0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424785,4.759085730004e-15,0.996593123545252)
link_36.Initialize(body_8,body_12,False,cA,cB,dA,dB)
link_36.SetName("Coincident14")
exported_items.append(link_36)


# Mate constraint: Distance8 [MateDistanceDim] type:5 align:1 flip:True
#   Entity 0: C::E name: body_8 , SW name: M-410iB-300 -9/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_12 , SW name: M-410iB-300 -9/M-410iB-300-11-1 ,  SW ref.type:2 (2)

link_37 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.06037255245555,3.21365467148157,0.752419501090434)
cB = chrono.ChVectorD(-3.55910633801413,3.02764258400503,0.795222456348894)
dA = chrono.ChVectorD(-0.0824751241424789,-3.55959220900182e-15,-0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424785,4.759085730004e-15,0.996593123545253)
link_37.Initialize(body_8,body_12,False,cA,cB,dB)
link_37.SetDistance(0)
link_37.SetName("Distance8")
exported_items.append(link_37)

link_38 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.06037255245555,3.21365467148157,0.752419501090434)
dA = chrono.ChVectorD(-0.0824751241424789,-3.55959220900182e-15,-0.996593123545253)
cB = chrono.ChVectorD(-3.55910633801413,3.02764258400503,0.795222456348894)
dB = chrono.ChVectorD(0.0824751241424785,4.759085730004e-15,0.996593123545253)
link_38.SetFlipped(True)
link_38.Initialize(body_8,body_12,False,cA,cB,dA,dB)
link_38.SetName("Distance8")
exported_items.append(link_38)


# Mate constraint: Coincident15 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_5 , SW name: M-410iB-300 -9/M-410iB-300-06-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_1 , SW name: M-410iB-300 -9/M-410iB-300-12-1 ,  SW ref.type:5 (2)

link_39 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.8152555108213,1.69376904051649,0.685030218736848)
dA = chrono.ChVectorD(-0.0824751241424783,-4.53761033121952e-15,-0.996593123545253)
cB = chrono.ChVectorD(-3.81422770582411,1.69376904051647,0.697449762242457)
dB = chrono.ChVectorD(0.0824751241424788,4.52631154697786e-15,0.996593123545253)
link_39.SetFlipped(True)
link_39.Initialize(body_5,body_1,False,cA,cB,dA,dB)
link_39.SetName("Coincident15")
exported_items.append(link_39)

link_40 = chrono.ChLinkMateGeneric()
link_40.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.8152555108213,1.69376904051649,0.685030218736848)
cB = chrono.ChVectorD(-3.81422770582411,1.69376904051647,0.697449762242457)
dA = chrono.ChVectorD(-0.0824751241424783,-4.53761033121952e-15,-0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424788,4.52631154697786e-15,0.996593123545253)
link_40.Initialize(body_5,body_1,False,cA,cB,dA,dB)
link_40.SetName("Coincident15")
exported_items.append(link_40)


# Mate constraint: Distance9 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_5 , SW name: M-410iB-300 -9/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_1 , SW name: M-410iB-300 -9/M-410iB-300-12-1 ,  SW ref.type:2 (2)

link_41 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.18827765327671,2.27955349819168,0.49266477680645)
cB = chrono.ChVectorD(-3.82784946227773,1.69376904051647,0.532850448771477)
dA = chrono.ChVectorD(-0.0824751241424783,-4.53761033121952e-15,-0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424788,4.52631154697786e-15,0.996593123545253)
link_41.Initialize(body_5,body_1,False,cA,cB,dB)
link_41.SetDistance(0)
link_41.SetName("Distance9")
exported_items.append(link_41)

link_42 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.18827765327671,2.27955349819168,0.49266477680645)
dA = chrono.ChVectorD(-0.0824751241424783,-4.53761033121952e-15,-0.996593123545253)
cB = chrono.ChVectorD(-3.82784946227773,1.69376904051647,0.532850448771477)
dB = chrono.ChVectorD(0.0824751241424788,4.52631154697786e-15,0.996593123545253)
link_42.SetFlipped(True)
link_42.Initialize(body_5,body_1,False,cA,cB,dA,dB)
link_42.SetName("Distance9")
exported_items.append(link_42)


# Mate constraint: Coincident16 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_12 , SW name: M-410iB-300 -9/M-410iB-300-11-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_1 , SW name: M-410iB-300 -9/M-410iB-300-12-1 ,  SW ref.type:5 (2)

link_43 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-4.30817905100364,1.96329996858997,0.794261045937959)
dA = chrono.ChVectorD(0.0824751241424785,4.759085730004e-15,0.996593123545252)
cB = chrono.ChVectorD(-4.31277644214501,1.96329996858992,0.738708193539744)
dB = chrono.ChVectorD(0.0824751241424788,4.52631154697786e-15,0.996593123545253)
link_43.Initialize(body_12,body_1,False,cA,cB,dA,dB)
link_43.SetName("Coincident16")
exported_items.append(link_43)

link_44 = chrono.ChLinkMateGeneric()
link_44.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-4.30817905100364,1.96329996858997,0.794261045937959)
cB = chrono.ChVectorD(-4.31277644214501,1.96329996858992,0.738708193539744)
dA = chrono.ChVectorD(0.0824751241424785,4.759085730004e-15,0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424788,4.52631154697786e-15,0.996593123545253)
link_44.Initialize(body_12,body_1,False,cA,cB,dA,dB)
link_44.SetName("Coincident16")
exported_items.append(link_44)


# Mate constraint: Coincident17 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_11 , SW name: M-410iB-300 -9/M-410iB-300-07-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_9 , SW name: M-410iB-300 -9/M-410iB-300-08-1 ,  SW ref.type:5 (2)

link_45 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.56037999469361,3.00995602354016,0.49703159258879)
dA = chrono.ChVectorD(-0.0824751241424795,-3.44202403592292e-15,-0.996593123545252)
cB = chrono.ChVectorD(-1.56546780262695,3.00995602354017,0.435552759390413)
dB = chrono.ChVectorD(0.0824751241424792,3.92284059436593e-15,0.996593123545252)
link_45.SetFlipped(True)
link_45.Initialize(body_11,body_9,False,cA,cB,dA,dB)
link_45.SetName("Coincident17")
exported_items.append(link_45)

link_46 = chrono.ChLinkMateGeneric()
link_46.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.56037999469361,3.00995602354016,0.49703159258879)
cB = chrono.ChVectorD(-1.56546780262695,3.00995602354017,0.435552759390413)
dA = chrono.ChVectorD(-0.0824751241424795,-3.44202403592292e-15,-0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424792,3.92284059436593e-15,0.996593123545252)
link_46.Initialize(body_11,body_9,False,cA,cB,dA,dB)
link_46.SetName("Coincident17")
exported_items.append(link_46)


# Mate constraint: Coincident18 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_3 , SW name: M-410iB-300 -9/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_2 , SW name: M-410iB-300 -9/ArmBase-1 ,  SW ref.type:2 (2)

link_47 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.50067035795504,2.04602671615662,0.377403113437383)
cB = chrono.ChVectorD(-1.25867129241134,2.04602671615662,0.377403113437383)
dA = chrono.ChVectorD(1.94491773090787e-16,-1,3.54762784160808e-15)
dB = chrono.ChVectorD(-6.21947280249299e-17,1,-3.55871276754624e-15)
link_47.Initialize(body_3,body_2,False,cA,cB,dB)
link_47.SetDistance(0)
link_47.SetName("Coincident18")
exported_items.append(link_47)

link_48 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.50067035795504,2.04602671615662,0.377403113437383)
dA = chrono.ChVectorD(1.94491773090787e-16,-1,3.54762784160808e-15)
cB = chrono.ChVectorD(-1.25867129241134,2.04602671615662,0.377403113437383)
dB = chrono.ChVectorD(-6.21947280249299e-17,1,-3.55871276754624e-15)
link_48.SetFlipped(True)
link_48.Initialize(body_3,body_2,False,cA,cB,dA,dB)
link_48.SetName("Coincident18")
exported_items.append(link_48)


# Mate constraint: Concentric1 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_3 , SW name: M-410iB-300 -9/M-410iB-300-02-1 ,  SW ref.type:1 (1)
#   Entity 1: C::E name: body_2 , SW name: M-410iB-300 -9/ArmBase-1 ,  SW ref.type:1 (1)

link_49 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.50067035795504,2.04755071615662,0.377403113437383)
dA = chrono.ChVectorD(-1.94491773090787e-16,1,-3.54762784160808e-15)
cB = chrono.ChVectorD(-1.50067035795504,2.04602671615662,0.377403113437383)
dB = chrono.ChVectorD(-6.21947280249299e-17,1,-3.55871276754624e-15)
link_49.Initialize(body_3,body_2,False,cA,cB,dA,dB)
link_49.SetName("Concentric1")
exported_items.append(link_49)

link_50 = chrono.ChLinkMateGeneric()
link_50.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.50067035795504,2.04755071615662,0.377403113437383)
cB = chrono.ChVectorD(-1.50067035795504,2.04602671615662,0.377403113437383)
dA = chrono.ChVectorD(-1.94491773090787e-16,1,-3.54762784160808e-15)
dB = chrono.ChVectorD(-6.21947280249299e-17,1,-3.55871276754624e-15)
link_50.Initialize(body_3,body_2,False,cA,cB,dA,dB)
link_50.SetName("Concentric1")
exported_items.append(link_50)


# Mate constraint: Coincident2_hinge [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_18 , SW name: M-410iB-300 -7/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_16 , SW name: M-410iB-300 -7/M-410iB-300-03-1 ,  SW ref.type:5 (2)

link_1 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.87878138328858,2.51550127212934,-2.36286795607619)
dA = chrono.ChVectorD(0.0824751241424789,3.43512560843663e-15,0.996593123545252)
cB = chrono.ChVectorD(-1.89800452027346,2.51550127212934,-2.59515188812587)
dB = chrono.ChVectorD(0.082475124142479,3.52644295689215e-15,0.996593123545252)
link_1.Initialize(body_18,body_16,False,cA,cB,dA,dB)
link_1.SetName("Coincident2_hinge")
exported_items.append(link_1)

link_2 = chrono.ChLinkMateGeneric()
link_2.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.87878138328858,2.51550127212934,-2.36286795607619)
cB = chrono.ChVectorD(-1.89800452027346,2.51550127212934,-2.59515188812587)
dA = chrono.ChVectorD(0.0824751241424789,3.43512560843663e-15,0.996593123545252)
dB = chrono.ChVectorD(0.082475124142479,3.52644295689215e-15,0.996593123545252)
link_2.Initialize(body_18,body_16,False,cA,cB,dA,dB)
link_2.SetName("Coincident2_hinge")
exported_items.append(link_2)


# Mate constraint: Distance2 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_18 , SW name: M-410iB-300 -7/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_16 , SW name: M-410iB-300 -7/M-410iB-300-03-1 ,  SW ref.type:2 (2)

link_3 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-2.11018861732807,2.84164228947283,-2.58855149164487)
cB = chrono.ChVectorD(-2.73620448423209,2.54318522667953,-2.53368583479229)
dA = chrono.ChVectorD(0.0824751241424789,3.43512560843663e-15,0.996593123545252)
dB = chrono.ChVectorD(-0.082475124142479,-3.52644295689215e-15,-0.996593123545252)
link_3.Initialize(body_18,body_16,False,cA,cB,dB)
link_3.SetDistance(0)
link_3.SetName("Distance2")
exported_items.append(link_3)

link_4 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.11018861732807,2.84164228947283,-2.58855149164487)
dA = chrono.ChVectorD(0.0824751241424789,3.43512560843663e-15,0.996593123545252)
cB = chrono.ChVectorD(-2.73620448423209,2.54318522667953,-2.53368583479229)
dB = chrono.ChVectorD(-0.082475124142479,-3.52644295689215e-15,-0.996593123545252)
link_4.SetFlipped(True)
link_4.Initialize(body_18,body_16,False,cA,cB,dA,dB)
link_4.SetName("Distance2")
exported_items.append(link_4)


# Mate constraint: Coincident3 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_18 , SW name: M-410iB-300 -7/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_14 , SW name: M-410iB-300 -7/M-410iB-300-04-1 ,  SW ref.type:5 (2)

link_5 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.90232652265115,2.78049690546383,-2.64733471087338)
dA = chrono.ChVectorD(-0.0824751241424789,-3.43512560843663e-15,-0.996593123545252)
cB = chrono.ChVectorD(-1.90809982310578,2.78049690546384,-2.71709673418738)
dB = chrono.ChVectorD(-0.0824751241424785,-3.49716949823504e-15,-0.996593123545253)
link_5.Initialize(body_18,body_14,False,cA,cB,dA,dB)
link_5.SetName("Coincident3")
exported_items.append(link_5)

link_6 = chrono.ChLinkMateGeneric()
link_6.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.90232652265115,2.78049690546383,-2.64733471087338)
cB = chrono.ChVectorD(-1.90809982310578,2.78049690546384,-2.71709673418738)
dA = chrono.ChVectorD(-0.0824751241424789,-3.43512560843663e-15,-0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424785,-3.49716949823504e-15,-0.996593123545253)
link_6.Initialize(body_18,body_14,False,cA,cB,dA,dB)
link_6.SetName("Coincident3")
exported_items.append(link_6)


# Mate constraint: Distance3 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_18 , SW name: M-410iB-300 -7/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_14 , SW name: M-410iB-300 -7/M-410iB-300-04-1 ,  SW ref.type:2 (2)

link_7 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.90600495189008,2.78049691677856,-2.69178326910278)
cB = chrono.ChVectorD(-1.97739420838105,2.80967719196081,-2.71136213408536)
dA = chrono.ChVectorD(-0.0824751241424789,-3.43512560843663e-15,-0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424785,3.49716949823504e-15,0.996593123545253)
link_7.Initialize(body_18,body_14,False,cA,cB,dB)
link_7.SetDistance(0)
link_7.SetName("Distance3")
exported_items.append(link_7)

link_8 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.90600495189008,2.78049691677856,-2.69178326910278)
dA = chrono.ChVectorD(-0.0824751241424789,-3.43512560843663e-15,-0.996593123545252)
cB = chrono.ChVectorD(-1.97739420838105,2.80967719196081,-2.71136213408536)
dB = chrono.ChVectorD(0.0824751241424785,3.49716949823504e-15,0.996593123545253)
link_8.SetFlipped(True)
link_8.Initialize(body_18,body_14,False,cA,cB,dA,dB)
link_8.SetName("Distance3")
exported_items.append(link_8)


# Mate constraint: Coincident4 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_14 , SW name: M-410iB-300 -7/M-410iB-300-04-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_22 , SW name: M-410iB-300 -7/M-410iB-300-05-1 ,  SW ref.type:5 (2)

link_9 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.71143288244173,2.76544912375639,-2.6791604963153)
dA = chrono.ChVectorD(0.996418499736232,0.0187192635196771,-0.0824606727881726)
cB = chrono.ChVectorD(-3.00015381681405,2.76002505419567,-2.65526679853402)
dB = chrono.ChVectorD(0.996418499736232,0.0187192635196772,-0.0824606727881727)
link_9.Initialize(body_14,body_22,False,cA,cB,dA,dB)
link_9.SetName("Coincident4")
exported_items.append(link_9)

link_10 = chrono.ChLinkMateGeneric()
link_10.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-2.71143288244173,2.76544912375639,-2.6791604963153)
cB = chrono.ChVectorD(-3.00015381681405,2.76002505419567,-2.65526679853402)
dA = chrono.ChVectorD(0.996418499736232,0.0187192635196771,-0.0824606727881726)
dB = chrono.ChVectorD(0.996418499736232,0.0187192635196772,-0.0824606727881727)
link_10.Initialize(body_14,body_22,False,cA,cB,dA,dB)
link_10.SetName("Coincident4")
exported_items.append(link_10)


# Mate constraint: Coincident5 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_16 , SW name: M-410iB-300 -7/M-410iB-300-03-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_22 , SW name: M-410iB-300 -7/M-410iB-300-05-1 ,  SW ref.type:5 (2)

link_11 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.08956446048187,2.75811166841885,-2.49654188202599)
dA = chrono.ChVectorD(0.082475124142479,3.52644295689215e-15,0.996593123545252)
cB = chrono.ChVectorD(-3.09911590513989,2.75811166841886,-2.61195733808127)
dB = chrono.ChVectorD(0.0824751241424786,3.25333242964305e-15,0.996593123545253)
link_11.Initialize(body_16,body_22,False,cA,cB,dA,dB)
link_11.SetName("Coincident5")
exported_items.append(link_11)

link_12 = chrono.ChLinkMateGeneric()
link_12.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.08956446048187,2.75811166841885,-2.49654188202599)
cB = chrono.ChVectorD(-3.09911590513989,2.75811166841886,-2.61195733808127)
dA = chrono.ChVectorD(0.082475124142479,3.52644295689215e-15,0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424786,3.25333242964305e-15,0.996593123545253)
link_12.Initialize(body_16,body_22,False,cA,cB,dA,dB)
link_12.SetName("Coincident5")
exported_items.append(link_12)


# Mate constraint: Coincident6 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_16 , SW name: M-410iB-300 -7/M-410iB-300-03-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_13 , SW name: M-410iB-300 -7/M-410iB-300-06-1 ,  SW ref.type:5 (2)

link_13 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.06708905223563,2.75811166841885,-2.22495893456206)
dA = chrono.ChVectorD(0.082475124142479,3.52644295689215e-15,0.996593123545252)
cB = chrono.ChVectorD(-3.06970763742717,2.75811166841884,-2.25660076623462)
dB = chrono.ChVectorD(-0.0824751241424783,-4.4211536946815e-15,-0.996593123545253)
link_13.SetFlipped(True)
link_13.Initialize(body_16,body_13,False,cA,cB,dA,dB)
link_13.SetName("Coincident6")
exported_items.append(link_13)

link_14 = chrono.ChLinkMateGeneric()
link_14.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.06708905223563,2.75811166841885,-2.22495893456206)
cB = chrono.ChVectorD(-3.06970763742717,2.75811166841884,-2.25660076623462)
dA = chrono.ChVectorD(0.082475124142479,3.52644295689215e-15,0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424783,-4.4211536946815e-15,-0.996593123545253)
link_14.Initialize(body_16,body_13,False,cA,cB,dA,dB)
link_14.SetName("Coincident6")
exported_items.append(link_14)


# Mate constraint: Distance4 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_16 , SW name: M-410iB-300 -7/M-410iB-300-03-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_13 , SW name: M-410iB-300 -7/M-410iB-300-06-1 ,  SW ref.type:2 (2)

link_15 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-2.88223000352087,2.91434507456168,-2.24025732728765)
cB = chrono.ChVectorD(-2.96321003072955,2.58269164685797,-2.26541419583367)
dA = chrono.ChVectorD(-0.082475124142479,-3.52644295689215e-15,-0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424783,4.4211536946815e-15,0.996593123545253)
link_15.Initialize(body_16,body_13,False,cA,cB,dB)
link_15.SetDistance(0)
link_15.SetName("Distance4")
exported_items.append(link_15)

link_16 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.88223000352087,2.91434507456168,-2.24025732728765)
dA = chrono.ChVectorD(-0.082475124142479,-3.52644295689215e-15,-0.996593123545252)
cB = chrono.ChVectorD(-2.96321003072955,2.58269164685797,-2.26541419583367)
dB = chrono.ChVectorD(0.0824751241424783,4.4211536946815e-15,0.996593123545253)
link_16.SetFlipped(True)
link_16.Initialize(body_16,body_13,False,cA,cB,dA,dB)
link_16.SetName("Distance4")
exported_items.append(link_16)


# Mate constraint: Coincident7 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_18 , SW name: M-410iB-300 -7/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_19 , SW name: M-410iB-300 -7/M-410iB-300-07-1 ,  SW ref.type:5 (2)

link_17 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.90558579863488,2.51550127212934,-2.68676072122839)
dA = chrono.ChVectorD(0.0824751241424789,3.43512560843663e-15,0.996593123545252)
cB = chrono.ChVectorD(-1.88095452717193,2.51550127212935,-2.38912727090773)
dB = chrono.ChVectorD(-0.0824751241424795,-3.3255673993849e-15,-0.996593123545252)
link_17.SetFlipped(True)
link_17.Initialize(body_18,body_19,False,cA,cB,dA,dB)
link_17.SetName("Coincident7")
exported_items.append(link_17)

link_18 = chrono.ChLinkMateGeneric()
link_18.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.90558579863488,2.51550127212934,-2.68676072122839)
cB = chrono.ChVectorD(-1.88095452717193,2.51550127212935,-2.38912727090773)
dA = chrono.ChVectorD(0.0824751241424789,3.43512560843663e-15,0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424795,-3.3255673993849e-15,-0.996593123545252)
link_18.Initialize(body_18,body_19,False,cA,cB,dA,dB)
link_18.SetName("Coincident7")
exported_items.append(link_18)


# Mate constraint: Coincident8 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_13 , SW name: M-410iB-300 -7/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_19 , SW name: M-410iB-300 -7/M-410iB-300-07-1 ,  SW ref.type:2 (2)

link_19 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-2.6071194325357,3.10515332885272,-2.4052592469376)
cB = chrono.ChVectorD(-1.56768836286924,3.00995602354015,-2.49127951386792)
dA = chrono.ChVectorD(0.0824751241424783,4.4211536946815e-15,0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424795,3.3255673993849e-15,0.996593123545252)
link_19.Initialize(body_13,body_19,False,cA,cB,dB)
link_19.SetDistance(0)
link_19.SetName("Coincident8")
exported_items.append(link_19)

link_20 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.6071194325357,3.10515332885272,-2.4052592469376)
dA = chrono.ChVectorD(0.0824751241424783,4.4211536946815e-15,0.996593123545253)
cB = chrono.ChVectorD(-1.56768836286924,3.00995602354015,-2.49127951386792)
dB = chrono.ChVectorD(0.0824751241424795,3.3255673993849e-15,0.996593123545252)
link_20.Initialize(body_13,body_19,False,cA,cB,dA,dB)
link_20.SetName("Coincident8")
exported_items.append(link_20)


# Mate constraint: Distance5 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_13 , SW name: M-410iB-300 -7/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_23 , SW name: M-410iB-300 -7/M-410iB-300-08-1 ,  SW ref.type:2 (2)

link_21 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-2.6071194325357,3.10515332885272,-2.4052592469376)
cB = chrono.ChVectorD(-1.57268463047198,3.01604196029193,-2.46869249489401)
dA = chrono.ChVectorD(0.0824751241424783,4.4211536946815e-15,0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424792,-3.80638395782791e-15,-0.996593123545252)
link_21.Initialize(body_13,body_23,False,cA,cB,dB)
link_21.SetDistance(0)
link_21.SetName("Distance5")
exported_items.append(link_21)

link_22 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.6071194325357,3.10515332885272,-2.4052592469376)
dA = chrono.ChVectorD(0.0824751241424783,4.4211536946815e-15,0.996593123545253)
cB = chrono.ChVectorD(-1.57268463047198,3.01604196029193,-2.46869249489401)
dB = chrono.ChVectorD(-0.0824751241424792,-3.80638395782791e-15,-0.996593123545252)
link_22.SetFlipped(True)
link_22.Initialize(body_13,body_23,False,cA,cB,dA,dB)
link_22.SetName("Distance5")
exported_items.append(link_22)


# Mate constraint: Coincident9 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_13 , SW name: M-410iB-300 -7/M-410iB-300-06-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_23 , SW name: M-410iB-300 -7/M-410iB-300-08-1 ,  SW ref.type:5 (2)

link_23 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.76251640195878,3.25502265002169,-2.39239904948918)
dA = chrono.ChVectorD(0.0824751241424783,4.4211536946815e-15,0.996593123545253)
cB = chrono.ChVectorD(-2.76029584171634,3.25502265002172,-2.36556677623084)
dB = chrono.ChVectorD(0.0824751241424792,3.80638395782791e-15,0.996593123545252)
link_23.Initialize(body_13,body_23,False,cA,cB,dA,dB)
link_23.SetName("Coincident9")
exported_items.append(link_23)

link_24 = chrono.ChLinkMateGeneric()
link_24.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-2.76251640195878,3.25502265002169,-2.39239904948918)
cB = chrono.ChVectorD(-2.76029584171634,3.25502265002172,-2.36556677623084)
dA = chrono.ChVectorD(0.0824751241424783,4.4211536946815e-15,0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424792,3.80638395782791e-15,0.996593123545252)
link_24.Initialize(body_13,body_23,False,cA,cB,dA,dB)
link_24.SetName("Coincident9")
exported_items.append(link_24)


# Mate constraint: Coincident10 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_20 , SW name: M-410iB-300 -7/M-410iB-300-09-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_13 , SW name: M-410iB-300 -7/M-410iB-300-06-1 ,  SW ref.type:5 (2)

link_25 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.05620029367942,2.75811166841881,-2.09338396557674)
dA = chrono.ChVectorD(-0.0824751241424789,-3.4431355724638e-15,-0.996593123545253)
cB = chrono.ChVectorD(-3.06207868844399,2.75811166841884,-2.16441590230669)
dB = chrono.ChVectorD(-0.0824751241424783,-4.4211536946815e-15,-0.996593123545253)
link_25.Initialize(body_20,body_13,False,cA,cB,dA,dB)
link_25.SetName("Coincident10")
exported_items.append(link_25)

link_26 = chrono.ChLinkMateGeneric()
link_26.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.05620029367942,2.75811166841881,-2.09338396557674)
cB = chrono.ChVectorD(-3.06207868844399,2.75811166841884,-2.16441590230669)
dA = chrono.ChVectorD(-0.0824751241424789,-3.4431355724638e-15,-0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424783,-4.4211536946815e-15,-0.996593123545253)
link_26.Initialize(body_20,body_13,False,cA,cB,dA,dB)
link_26.SetName("Coincident10")
exported_items.append(link_26)


# Mate constraint: Coincident11 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_18 , SW name: M-410iB-300 -7/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_20 , SW name: M-410iB-300 -7/M-410iB-300-09-1 ,  SW ref.type:2 (2)

link_27 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.51318598779731,2.72491052060181,-2.22745101187137)
cB = chrono.ChVectorD(-3.05641325164644,3.21365467148157,-2.09973804942061)
dA = chrono.ChVectorD(0.0824751241424789,3.43512560843663e-15,0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424789,3.4431355724638e-15,0.996593123545253)
link_27.Initialize(body_18,body_20,False,cA,cB,dB)
link_27.SetDistance(0)
link_27.SetName("Coincident11")
exported_items.append(link_27)

link_28 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.51318598779731,2.72491052060181,-2.22745101187137)
dA = chrono.ChVectorD(0.0824751241424789,3.43512560843663e-15,0.996593123545252)
cB = chrono.ChVectorD(-3.05641325164644,3.21365467148157,-2.09973804942061)
dB = chrono.ChVectorD(0.0824751241424789,3.4431355724638e-15,0.996593123545253)
link_28.Initialize(body_18,body_20,False,cA,cB,dA,dB)
link_28.SetName("Coincident11")
exported_items.append(link_28)


# Mate constraint: Coincident12 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_20 , SW name: M-410iB-300 -7/M-410iB-300-09-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_24 , SW name: M-410iB-300 -7/M-410iB-300-10-1 ,  SW ref.type:5 (2)

link_29 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.55781544031632,3.030810761637,-2.14737224964241)
dA = chrono.ChVectorD(-0.0824751241424789,-3.4431355724638e-15,-0.996593123545253)
cB = chrono.ChVectorD(-2.55350413567683,3.03081076163706,-2.09527634070221)
dB = chrono.ChVectorD(-0.0824751241424783,-3.82037016585297e-15,-0.996593123545252)
link_29.Initialize(body_20,body_24,False,cA,cB,dA,dB)
link_29.SetName("Coincident12")
exported_items.append(link_29)

link_30 = chrono.ChLinkMateGeneric()
link_30.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-2.55781544031632,3.030810761637,-2.14737224964241)
cB = chrono.ChVectorD(-2.55350413567683,3.03081076163706,-2.09527634070221)
dA = chrono.ChVectorD(-0.0824751241424789,-3.4431355724638e-15,-0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424783,-3.82037016585297e-15,-0.996593123545252)
link_30.Initialize(body_20,body_24,False,cA,cB,dA,dB)
link_30.SetName("Coincident12")
exported_items.append(link_30)


# Mate constraint: Distance7 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_20 , SW name: M-410iB-300 -7/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_24 , SW name: M-410iB-300 -7/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_31 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.05641325164644,3.21365467148157,-2.09973804942061)
cB = chrono.ChVectorD(-2.55704033909956,3.03081076163706,-2.13800626746733)
dA = chrono.ChVectorD(0.0824751241424789,3.4431355724638e-15,0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424783,-3.82037016585297e-15,-0.996593123545252)
link_31.Initialize(body_20,body_24,False,cA,cB,dB)
link_31.SetDistance(0)
link_31.SetName("Distance7")
exported_items.append(link_31)

link_32 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.05641325164644,3.21365467148157,-2.09973804942061)
dA = chrono.ChVectorD(0.0824751241424789,3.4431355724638e-15,0.996593123545253)
cB = chrono.ChVectorD(-2.55704033909956,3.03081076163706,-2.13800626746733)
dB = chrono.ChVectorD(-0.0824751241424783,-3.82037016585297e-15,-0.996593123545252)
link_32.SetFlipped(True)
link_32.Initialize(body_20,body_24,False,cA,cB,dA,dB)
link_32.SetName("Distance7")
exported_items.append(link_32)


# Mate constraint: Coincident13 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_18 , SW name: M-410iB-300 -7/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_24 , SW name: M-410iB-300 -7/M-410iB-300-10-1 ,  SW ref.type:5 (2)

link_33 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.36587439836585,2.78749692402101,-2.23964208698411)
dA = chrono.ChVectorD(-0.0824751241424789,-3.43512560843663e-15,-0.996593123545252)
cB = chrono.ChVectorD(-1.36522498923834,2.78749692402101,-2.23179491272931)
dB = chrono.ChVectorD(0.0824751241424783,3.82037016585297e-15,0.996593123545252)
link_33.SetFlipped(True)
link_33.Initialize(body_18,body_24,False,cA,cB,dA,dB)
link_33.SetName("Coincident13")
exported_items.append(link_33)

link_34 = chrono.ChLinkMateGeneric()
link_34.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.36587439836585,2.78749692402101,-2.23964208698411)
cB = chrono.ChVectorD(-1.36522498923834,2.78749692402101,-2.23179491272931)
dA = chrono.ChVectorD(-0.0824751241424789,-3.43512560843663e-15,-0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424783,3.82037016585297e-15,0.996593123545252)
link_34.Initialize(body_18,body_24,False,cA,cB,dA,dB)
link_34.SetName("Coincident13")
exported_items.append(link_34)


# Mate constraint: Coincident14 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_20 , SW name: M-410iB-300 -7/M-410iB-300-09-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_21 , SW name: M-410iB-300 -7/M-410iB-300-11-1 ,  SW ref.type:5 (2)

link_35 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.5557964463321,3.02764258400496,-2.06478226841699)
dA = chrono.ChVectorD(-0.0824751241424789,-3.4431355724638e-15,-0.996593123545253)
cB = chrono.ChVectorD(-3.56428066235258,3.02764258400502,-2.16730180303609)
dB = chrono.ChVectorD(0.0824751241424785,4.64262909346598e-15,0.996593123545252)
link_35.SetFlipped(True)
link_35.Initialize(body_20,body_21,False,cA,cB,dA,dB)
link_35.SetName("Coincident14")
exported_items.append(link_35)

link_36 = chrono.ChLinkMateGeneric()
link_36.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.5557964463321,3.02764258400496,-2.06478226841699)
cB = chrono.ChVectorD(-3.56428066235258,3.02764258400502,-2.16730180303609)
dA = chrono.ChVectorD(-0.0824751241424789,-3.4431355724638e-15,-0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424785,4.64262909346598e-15,0.996593123545252)
link_36.Initialize(body_20,body_21,False,cA,cB,dA,dB)
link_36.SetName("Coincident14")
exported_items.append(link_36)


# Mate constraint: Distance8 [MateDistanceDim] type:5 align:1 flip:True
#   Entity 0: C::E name: body_20 , SW name: M-410iB-300 -7/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_21 , SW name: M-410iB-300 -7/M-410iB-300-11-1 ,  SW ref.type:2 (2)

link_37 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.06037255245603,3.21365467148157,-2.14758049890953)
cB = chrono.ChVectorD(-3.55910633801413,3.02764258400502,-2.10477754365111)
dA = chrono.ChVectorD(-0.0824751241424789,-3.4431355724638e-15,-0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424785,4.64262909346598e-15,0.996593123545253)
link_37.Initialize(body_20,body_21,False,cA,cB,dB)
link_37.SetDistance(0)
link_37.SetName("Distance8")
exported_items.append(link_37)

link_38 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.06037255245603,3.21365467148157,-2.14758049890953)
dA = chrono.ChVectorD(-0.0824751241424789,-3.4431355724638e-15,-0.996593123545253)
cB = chrono.ChVectorD(-3.55910633801413,3.02764258400502,-2.10477754365111)
dB = chrono.ChVectorD(0.0824751241424785,4.64262909346598e-15,0.996593123545253)
link_38.SetFlipped(True)
link_38.Initialize(body_20,body_21,False,cA,cB,dA,dB)
link_38.SetName("Distance8")
exported_items.append(link_38)


# Mate constraint: Coincident15 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_13 , SW name: M-410iB-300 -7/M-410iB-300-06-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_15 , SW name: M-410iB-300 -7/M-410iB-300-12-1 ,  SW ref.type:5 (2)

link_39 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.81525551082147,1.69376904051648,-2.21496978126314)
dA = chrono.ChVectorD(-0.0824751241424783,-4.4211536946815e-15,-0.996593123545253)
cB = chrono.ChVectorD(-3.8142277058244,1.69376904051648,-2.20255023775752)
dB = chrono.ChVectorD(0.0824751241424788,4.40985491043984e-15,0.996593123545253)
link_39.SetFlipped(True)
link_39.Initialize(body_13,body_15,False,cA,cB,dA,dB)
link_39.SetName("Coincident15")
exported_items.append(link_39)

link_40 = chrono.ChLinkMateGeneric()
link_40.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.81525551082147,1.69376904051648,-2.21496978126314)
cB = chrono.ChVectorD(-3.8142277058244,1.69376904051648,-2.20255023775752)
dA = chrono.ChVectorD(-0.0824751241424783,-4.4211536946815e-15,-0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424788,4.40985491043984e-15,0.996593123545253)
link_40.Initialize(body_13,body_15,False,cA,cB,dA,dB)
link_40.SetName("Coincident15")
exported_items.append(link_40)


# Mate constraint: Distance9 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_13 , SW name: M-410iB-300 -7/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_15 , SW name: M-410iB-300 -7/M-410iB-300-12-1 ,  SW ref.type:2 (2)

link_41 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.18827765327687,2.27955349819167,-2.40733522319354)
cB = chrono.ChVectorD(-3.82784946227802,1.69376904051647,-2.36714955122849)
dA = chrono.ChVectorD(-0.0824751241424783,-4.4211536946815e-15,-0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424788,4.40985491043984e-15,0.996593123545253)
link_41.Initialize(body_13,body_15,False,cA,cB,dB)
link_41.SetDistance(0)
link_41.SetName("Distance9")
exported_items.append(link_41)

link_42 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.18827765327687,2.27955349819167,-2.40733522319354)
dA = chrono.ChVectorD(-0.0824751241424783,-4.4211536946815e-15,-0.996593123545253)
cB = chrono.ChVectorD(-3.82784946227802,1.69376904051647,-2.36714955122849)
dB = chrono.ChVectorD(0.0824751241424788,4.40985491043984e-15,0.996593123545253)
link_42.SetFlipped(True)
link_42.Initialize(body_13,body_15,False,cA,cB,dA,dB)
link_42.SetName("Distance9")
exported_items.append(link_42)


# Mate constraint: Coincident16 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_21 , SW name: M-410iB-300 -7/M-410iB-300-11-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_15 , SW name: M-410iB-300 -7/M-410iB-300-12-1 ,  SW ref.type:5 (2)

link_43 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-4.30817905100364,1.96329996858996,-2.10573895406204)
dA = chrono.ChVectorD(0.0824751241424785,4.64262909346598e-15,0.996593123545252)
cB = chrono.ChVectorD(-4.3127764421453,1.96329996858992,-2.16129180646023)
dB = chrono.ChVectorD(0.0824751241424788,4.40985491043984e-15,0.996593123545253)
link_43.Initialize(body_21,body_15,False,cA,cB,dA,dB)
link_43.SetName("Coincident16")
exported_items.append(link_43)

link_44 = chrono.ChLinkMateGeneric()
link_44.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-4.30817905100364,1.96329996858996,-2.10573895406204)
cB = chrono.ChVectorD(-4.3127764421453,1.96329996858992,-2.16129180646023)
dA = chrono.ChVectorD(0.0824751241424785,4.64262909346598e-15,0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424788,4.40985491043984e-15,0.996593123545253)
link_44.Initialize(body_21,body_15,False,cA,cB,dA,dB)
link_44.SetName("Coincident16")
exported_items.append(link_44)


# Mate constraint: Coincident17 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_19 , SW name: M-410iB-300 -7/M-410iB-300-07-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_23 , SW name: M-410iB-300 -7/M-410iB-300-08-1 ,  SW ref.type:5 (2)

link_45 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.56037999469361,3.00995602354015,-2.40296840741121)
dA = chrono.ChVectorD(-0.0824751241424795,-3.3255673993849e-15,-0.996593123545252)
cB = chrono.ChVectorD(-1.56546780262682,3.00995602354015,-2.46444724060959)
dB = chrono.ChVectorD(0.0824751241424792,3.80638395782791e-15,0.996593123545252)
link_45.SetFlipped(True)
link_45.Initialize(body_19,body_23,False,cA,cB,dA,dB)
link_45.SetName("Coincident17")
exported_items.append(link_45)

link_46 = chrono.ChLinkMateGeneric()
link_46.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.56037999469361,3.00995602354015,-2.40296840741121)
cB = chrono.ChVectorD(-1.56546780262682,3.00995602354015,-2.46444724060959)
dA = chrono.ChVectorD(-0.0824751241424795,-3.3255673993849e-15,-0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424792,3.80638395782791e-15,0.996593123545252)
link_46.Initialize(body_19,body_23,False,cA,cB,dA,dB)
link_46.SetName("Coincident17")
exported_items.append(link_46)


# Mate constraint: Coincident18 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_18 , SW name: M-410iB-300 -7/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_17 , SW name: M-410iB-300 -7/ArmBase-1 ,  SW ref.type:2 (2)

link_47 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.50067035795504,2.04602671615661,-2.52259688656262)
cB = chrono.ChVectorD(-1.25867129241134,2.04602671615662,-2.52259688656262)
dA = chrono.ChVectorD(1.96505437811525e-16,-1,3.43060645039982e-15)
dB = chrono.ChVectorD(-6.42083927456682e-17,1,-3.44169137633798e-15)
link_47.Initialize(body_18,body_17,False,cA,cB,dB)
link_47.SetDistance(0)
link_47.SetName("Coincident18")
exported_items.append(link_47)

link_48 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.50067035795504,2.04602671615661,-2.52259688656262)
dA = chrono.ChVectorD(1.96505437811525e-16,-1,3.43060645039982e-15)
cB = chrono.ChVectorD(-1.25867129241134,2.04602671615662,-2.52259688656262)
dB = chrono.ChVectorD(-6.42083927456682e-17,1,-3.44169137633798e-15)
link_48.SetFlipped(True)
link_48.Initialize(body_18,body_17,False,cA,cB,dA,dB)
link_48.SetName("Coincident18")
exported_items.append(link_48)


# Mate constraint: Concentric1 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_18 , SW name: M-410iB-300 -7/M-410iB-300-02-1 ,  SW ref.type:1 (1)
#   Entity 1: C::E name: body_17 , SW name: M-410iB-300 -7/ArmBase-1 ,  SW ref.type:1 (1)

link_49 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.50067035795504,2.04755071615662,-2.52259688656262)
dA = chrono.ChVectorD(-1.96505437811525e-16,1,-3.43060645039982e-15)
cB = chrono.ChVectorD(-1.50067035795504,2.04602671615662,-2.52259688656262)
dB = chrono.ChVectorD(-6.42083927456682e-17,1,-3.44169137633798e-15)
link_49.Initialize(body_18,body_17,False,cA,cB,dA,dB)
link_49.SetName("Concentric1")
exported_items.append(link_49)

link_50 = chrono.ChLinkMateGeneric()
link_50.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.50067035795504,2.04755071615662,-2.52259688656262)
cB = chrono.ChVectorD(-1.50067035795504,2.04602671615662,-2.52259688656262)
dA = chrono.ChVectorD(-1.96505437811525e-16,1,-3.43060645039982e-15)
dB = chrono.ChVectorD(-6.42083927456682e-17,1,-3.44169137633798e-15)
link_50.Initialize(body_18,body_17,False,cA,cB,dA,dB)
link_50.SetName("Concentric1")
exported_items.append(link_50)


# Mate constraint: Coincident2_hinge [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_25 , SW name: M-410iB-300 -8/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_30 , SW name: M-410iB-300 -8/M-410iB-300-03-1 ,  SW ref.type:5 (2)

link_1 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.87878138328858,2.51550127212935,-0.912867956076194)
dA = chrono.ChVectorD(0.0824751241424792,3.31865507908476e-15,0.996593123545253)
cB = chrono.ChVectorD(-1.89800452027346,2.51550127212935,-1.14515188812587)
dB = chrono.ChVectorD(0.0824751241424793,3.40997242754028e-15,0.996593123545253)
link_1.Initialize(body_25,body_30,False,cA,cB,dA,dB)
link_1.SetName("Coincident2_hinge")
exported_items.append(link_1)

link_2 = chrono.ChLinkMateGeneric()
link_2.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.87878138328858,2.51550127212935,-0.912867956076194)
cB = chrono.ChVectorD(-1.89800452027346,2.51550127212935,-1.14515188812587)
dA = chrono.ChVectorD(0.0824751241424792,3.31865507908476e-15,0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424793,3.40997242754028e-15,0.996593123545253)
link_2.Initialize(body_25,body_30,False,cA,cB,dA,dB)
link_2.SetName("Coincident2_hinge")
exported_items.append(link_2)


# Mate constraint: Distance2 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_25 , SW name: M-410iB-300 -8/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_30 , SW name: M-410iB-300 -8/M-410iB-300-03-1 ,  SW ref.type:2 (2)

link_3 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-2.11018861732807,2.84164228947283,-1.13855149164486)
cB = chrono.ChVectorD(-2.73620448423209,2.54318522667954,-1.08368583479229)
dA = chrono.ChVectorD(0.0824751241424792,3.31865507908476e-15,0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424793,-3.40997242754028e-15,-0.996593123545253)
link_3.Initialize(body_25,body_30,False,cA,cB,dB)
link_3.SetDistance(0)
link_3.SetName("Distance2")
exported_items.append(link_3)

link_4 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.11018861732807,2.84164228947283,-1.13855149164486)
dA = chrono.ChVectorD(0.0824751241424792,3.31865507908476e-15,0.996593123545253)
cB = chrono.ChVectorD(-2.73620448423209,2.54318522667954,-1.08368583479229)
dB = chrono.ChVectorD(-0.0824751241424793,-3.40997242754028e-15,-0.996593123545253)
link_4.SetFlipped(True)
link_4.Initialize(body_25,body_30,False,cA,cB,dA,dB)
link_4.SetName("Distance2")
exported_items.append(link_4)


# Mate constraint: Coincident3 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_25 , SW name: M-410iB-300 -8/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_27 , SW name: M-410iB-300 -8/M-410iB-300-04-1 ,  SW ref.type:5 (2)

link_5 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.90232652265115,2.78049690546384,-1.19733471087338)
dA = chrono.ChVectorD(-0.0824751241424792,-3.31865507908476e-15,-0.996593123545253)
cB = chrono.ChVectorD(-1.90809982310578,2.78049690546384,-1.26709673418738)
dB = chrono.ChVectorD(-0.0824751241424787,-3.38069896888317e-15,-0.996593123545253)
link_5.Initialize(body_25,body_27,False,cA,cB,dA,dB)
link_5.SetName("Coincident3")
exported_items.append(link_5)

link_6 = chrono.ChLinkMateGeneric()
link_6.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.90232652265115,2.78049690546384,-1.19733471087338)
cB = chrono.ChVectorD(-1.90809982310578,2.78049690546384,-1.26709673418738)
dA = chrono.ChVectorD(-0.0824751241424792,-3.31865507908476e-15,-0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424787,-3.38069896888317e-15,-0.996593123545253)
link_6.Initialize(body_25,body_27,False,cA,cB,dA,dB)
link_6.SetName("Coincident3")
exported_items.append(link_6)


# Mate constraint: Distance3 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_25 , SW name: M-410iB-300 -8/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_27 , SW name: M-410iB-300 -8/M-410iB-300-04-1 ,  SW ref.type:2 (2)

link_7 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.90600495189008,2.78049691677857,-1.24178326910278)
cB = chrono.ChVectorD(-1.97739420838105,2.80967719196082,-1.26136213408536)
dA = chrono.ChVectorD(-0.0824751241424792,-3.31865507908476e-15,-0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424787,3.38069896888317e-15,0.996593123545253)
link_7.Initialize(body_25,body_27,False,cA,cB,dB)
link_7.SetDistance(0)
link_7.SetName("Distance3")
exported_items.append(link_7)

link_8 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.90600495189008,2.78049691677857,-1.24178326910278)
dA = chrono.ChVectorD(-0.0824751241424792,-3.31865507908476e-15,-0.996593123545253)
cB = chrono.ChVectorD(-1.97739420838105,2.80967719196082,-1.26136213408536)
dB = chrono.ChVectorD(0.0824751241424787,3.38069896888317e-15,0.996593123545253)
link_8.SetFlipped(True)
link_8.Initialize(body_25,body_27,False,cA,cB,dA,dB)
link_8.SetName("Distance3")
exported_items.append(link_8)


# Mate constraint: Coincident4 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_27 , SW name: M-410iB-300 -8/M-410iB-300-04-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_31 , SW name: M-410iB-300 -8/M-410iB-300-05-1 ,  SW ref.type:5 (2)

link_9 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.71143288244173,2.7654491237564,-1.2291604963153)
dA = chrono.ChVectorD(0.996418499736232,0.018719263519677,-0.082460672788173)
cB = chrono.ChVectorD(-3.00015381681404,2.76002505419568,-1.20526679853402)
dB = chrono.ChVectorD(0.996418499736232,0.0187192635196771,-0.0824606727881731)
link_9.Initialize(body_27,body_31,False,cA,cB,dA,dB)
link_9.SetName("Coincident4")
exported_items.append(link_9)

link_10 = chrono.ChLinkMateGeneric()
link_10.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-2.71143288244173,2.7654491237564,-1.2291604963153)
cB = chrono.ChVectorD(-3.00015381681404,2.76002505419568,-1.20526679853402)
dA = chrono.ChVectorD(0.996418499736232,0.018719263519677,-0.082460672788173)
dB = chrono.ChVectorD(0.996418499736232,0.0187192635196771,-0.0824606727881731)
link_10.Initialize(body_27,body_31,False,cA,cB,dA,dB)
link_10.SetName("Coincident4")
exported_items.append(link_10)


# Mate constraint: Coincident5 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_30 , SW name: M-410iB-300 -8/M-410iB-300-03-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_31 , SW name: M-410iB-300 -8/M-410iB-300-05-1 ,  SW ref.type:5 (2)

link_11 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.08956446048187,2.75811166841885,-1.04654188202599)
dA = chrono.ChVectorD(0.0824751241424793,3.40997242754028e-15,0.996593123545253)
cB = chrono.ChVectorD(-3.09911590513989,2.75811166841886,-1.16195733808127)
dB = chrono.ChVectorD(0.0824751241424788,3.13686190029118e-15,0.996593123545253)
link_11.Initialize(body_30,body_31,False,cA,cB,dA,dB)
link_11.SetName("Coincident5")
exported_items.append(link_11)

link_12 = chrono.ChLinkMateGeneric()
link_12.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.08956446048187,2.75811166841885,-1.04654188202599)
cB = chrono.ChVectorD(-3.09911590513989,2.75811166841886,-1.16195733808127)
dA = chrono.ChVectorD(0.0824751241424793,3.40997242754028e-15,0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424788,3.13686190029118e-15,0.996593123545253)
link_12.Initialize(body_30,body_31,False,cA,cB,dA,dB)
link_12.SetName("Coincident5")
exported_items.append(link_12)


# Mate constraint: Coincident6 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_30 , SW name: M-410iB-300 -8/M-410iB-300-03-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_33 , SW name: M-410iB-300 -8/M-410iB-300-06-1 ,  SW ref.type:5 (2)

link_13 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.06708905223563,2.75811166841885,-0.774958934562061)
dA = chrono.ChVectorD(0.0824751241424793,3.40997242754028e-15,0.996593123545253)
cB = chrono.ChVectorD(-3.06970763742717,2.75811166841884,-0.806600766234622)
dB = chrono.ChVectorD(-0.0824751241424786,-4.30468316532963e-15,-0.996593123545253)
link_13.SetFlipped(True)
link_13.Initialize(body_30,body_33,False,cA,cB,dA,dB)
link_13.SetName("Coincident6")
exported_items.append(link_13)

link_14 = chrono.ChLinkMateGeneric()
link_14.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.06708905223563,2.75811166841885,-0.774958934562061)
cB = chrono.ChVectorD(-3.06970763742717,2.75811166841884,-0.806600766234622)
dA = chrono.ChVectorD(0.0824751241424793,3.40997242754028e-15,0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424786,-4.30468316532963e-15,-0.996593123545253)
link_14.Initialize(body_30,body_33,False,cA,cB,dA,dB)
link_14.SetName("Coincident6")
exported_items.append(link_14)


# Mate constraint: Distance4 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_30 , SW name: M-410iB-300 -8/M-410iB-300-03-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_33 , SW name: M-410iB-300 -8/M-410iB-300-06-1 ,  SW ref.type:2 (2)

link_15 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-2.88223000352087,2.91434507456168,-0.790257327287645)
cB = chrono.ChVectorD(-2.96321003072955,2.58269164685797,-0.815414195833671)
dA = chrono.ChVectorD(-0.0824751241424793,-3.40997242754028e-15,-0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424786,4.30468316532963e-15,0.996593123545253)
link_15.Initialize(body_30,body_33,False,cA,cB,dB)
link_15.SetDistance(0)
link_15.SetName("Distance4")
exported_items.append(link_15)

link_16 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.88223000352087,2.91434507456168,-0.790257327287645)
dA = chrono.ChVectorD(-0.0824751241424793,-3.40997242754028e-15,-0.996593123545253)
cB = chrono.ChVectorD(-2.96321003072955,2.58269164685797,-0.815414195833671)
dB = chrono.ChVectorD(0.0824751241424786,4.30468316532963e-15,0.996593123545253)
link_16.SetFlipped(True)
link_16.Initialize(body_30,body_33,False,cA,cB,dA,dB)
link_16.SetName("Distance4")
exported_items.append(link_16)


# Mate constraint: Coincident7 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_25 , SW name: M-410iB-300 -8/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_28 , SW name: M-410iB-300 -8/M-410iB-300-07-1 ,  SW ref.type:5 (2)

link_17 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.90558579863488,2.51550127212935,-1.23676072122839)
dA = chrono.ChVectorD(0.0824751241424792,3.31865507908476e-15,0.996593123545253)
cB = chrono.ChVectorD(-1.88095452717194,2.51550127212934,-0.939127270907728)
dB = chrono.ChVectorD(-0.0824751241424798,-3.20909687003303e-15,-0.996593123545253)
link_17.SetFlipped(True)
link_17.Initialize(body_25,body_28,False,cA,cB,dA,dB)
link_17.SetName("Coincident7")
exported_items.append(link_17)

link_18 = chrono.ChLinkMateGeneric()
link_18.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.90558579863488,2.51550127212935,-1.23676072122839)
cB = chrono.ChVectorD(-1.88095452717194,2.51550127212934,-0.939127270907728)
dA = chrono.ChVectorD(0.0824751241424792,3.31865507908476e-15,0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424798,-3.20909687003303e-15,-0.996593123545253)
link_18.Initialize(body_25,body_28,False,cA,cB,dA,dB)
link_18.SetName("Coincident7")
exported_items.append(link_18)


# Mate constraint: Coincident8 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_33 , SW name: M-410iB-300 -8/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_28 , SW name: M-410iB-300 -8/M-410iB-300-07-1 ,  SW ref.type:2 (2)

link_19 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-2.6071194325357,3.10515332885272,-0.9552592469376)
cB = chrono.ChVectorD(-1.56768836286925,3.00995602354015,-1.04127951386792)
dA = chrono.ChVectorD(0.0824751241424786,4.30468316532963e-15,0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424798,3.20909687003303e-15,0.996593123545253)
link_19.Initialize(body_33,body_28,False,cA,cB,dB)
link_19.SetDistance(0)
link_19.SetName("Coincident8")
exported_items.append(link_19)

link_20 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.6071194325357,3.10515332885272,-0.9552592469376)
dA = chrono.ChVectorD(0.0824751241424786,4.30468316532963e-15,0.996593123545253)
cB = chrono.ChVectorD(-1.56768836286925,3.00995602354015,-1.04127951386792)
dB = chrono.ChVectorD(0.0824751241424798,3.20909687003303e-15,0.996593123545253)
link_20.Initialize(body_33,body_28,False,cA,cB,dA,dB)
link_20.SetName("Coincident8")
exported_items.append(link_20)


# Mate constraint: Distance5 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_33 , SW name: M-410iB-300 -8/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_26 , SW name: M-410iB-300 -8/M-410iB-300-08-1 ,  SW ref.type:2 (2)

link_21 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-2.6071194325357,3.10515332885272,-0.9552592469376)
cB = chrono.ChVectorD(-1.57268463047197,3.01604196029193,-1.01869249489401)
dA = chrono.ChVectorD(0.0824751241424786,4.30468316532963e-15,0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424794,-3.68991342847604e-15,-0.996593123545253)
link_21.Initialize(body_33,body_26,False,cA,cB,dB)
link_21.SetDistance(0)
link_21.SetName("Distance5")
exported_items.append(link_21)

link_22 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.6071194325357,3.10515332885272,-0.9552592469376)
dA = chrono.ChVectorD(0.0824751241424786,4.30468316532963e-15,0.996593123545253)
cB = chrono.ChVectorD(-1.57268463047197,3.01604196029193,-1.01869249489401)
dB = chrono.ChVectorD(-0.0824751241424794,-3.68991342847604e-15,-0.996593123545253)
link_22.SetFlipped(True)
link_22.Initialize(body_33,body_26,False,cA,cB,dA,dB)
link_22.SetName("Distance5")
exported_items.append(link_22)


# Mate constraint: Coincident9 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_33 , SW name: M-410iB-300 -8/M-410iB-300-06-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_26 , SW name: M-410iB-300 -8/M-410iB-300-08-1 ,  SW ref.type:5 (2)

link_23 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.76251640195878,3.25502265002169,-0.942399049489177)
dA = chrono.ChVectorD(0.0824751241424786,4.30468316532963e-15,0.996593123545253)
cB = chrono.ChVectorD(-2.76029584171633,3.25502265002172,-0.915566776230843)
dB = chrono.ChVectorD(0.0824751241424794,3.68991342847604e-15,0.996593123545253)
link_23.Initialize(body_33,body_26,False,cA,cB,dA,dB)
link_23.SetName("Coincident9")
exported_items.append(link_23)

link_24 = chrono.ChLinkMateGeneric()
link_24.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-2.76251640195878,3.25502265002169,-0.942399049489177)
cB = chrono.ChVectorD(-2.76029584171633,3.25502265002172,-0.915566776230843)
dA = chrono.ChVectorD(0.0824751241424786,4.30468316532963e-15,0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424794,3.68991342847604e-15,0.996593123545253)
link_24.Initialize(body_33,body_26,False,cA,cB,dA,dB)
link_24.SetName("Coincident9")
exported_items.append(link_24)


# Mate constraint: Coincident10 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_34 , SW name: M-410iB-300 -8/M-410iB-300-09-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_33 , SW name: M-410iB-300 -8/M-410iB-300-06-1 ,  SW ref.type:5 (2)

link_25 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.05620029367942,2.75811166841881,-0.643383965576739)
dA = chrono.ChVectorD(-0.0824751241424791,-3.32666504311193e-15,-0.996593123545253)
cB = chrono.ChVectorD(-3.06207868844399,2.75811166841884,-0.714415902306687)
dB = chrono.ChVectorD(-0.0824751241424786,-4.30468316532963e-15,-0.996593123545253)
link_25.Initialize(body_34,body_33,False,cA,cB,dA,dB)
link_25.SetName("Coincident10")
exported_items.append(link_25)

link_26 = chrono.ChLinkMateGeneric()
link_26.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.05620029367942,2.75811166841881,-0.643383965576739)
cB = chrono.ChVectorD(-3.06207868844399,2.75811166841884,-0.714415902306687)
dA = chrono.ChVectorD(-0.0824751241424791,-3.32666504311193e-15,-0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424786,-4.30468316532963e-15,-0.996593123545253)
link_26.Initialize(body_34,body_33,False,cA,cB,dA,dB)
link_26.SetName("Coincident10")
exported_items.append(link_26)


# Mate constraint: Coincident11 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_25 , SW name: M-410iB-300 -8/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_34 , SW name: M-410iB-300 -8/M-410iB-300-09-1 ,  SW ref.type:2 (2)

link_27 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.51318598779731,2.72491052060182,-0.777451011871366)
cB = chrono.ChVectorD(-3.05641325164644,3.21365467148157,-0.649738049420612)
dA = chrono.ChVectorD(0.0824751241424792,3.31865507908476e-15,0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424791,3.32666504311193e-15,0.996593123545253)
link_27.Initialize(body_25,body_34,False,cA,cB,dB)
link_27.SetDistance(0)
link_27.SetName("Coincident11")
exported_items.append(link_27)

link_28 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.51318598779731,2.72491052060182,-0.777451011871366)
dA = chrono.ChVectorD(0.0824751241424792,3.31865507908476e-15,0.996593123545253)
cB = chrono.ChVectorD(-3.05641325164644,3.21365467148157,-0.649738049420612)
dB = chrono.ChVectorD(0.0824751241424791,3.32666504311193e-15,0.996593123545253)
link_28.Initialize(body_25,body_34,False,cA,cB,dA,dB)
link_28.SetName("Coincident11")
exported_items.append(link_28)


# Mate constraint: Coincident12 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_34 , SW name: M-410iB-300 -8/M-410iB-300-09-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_35 , SW name: M-410iB-300 -8/M-410iB-300-10-1 ,  SW ref.type:5 (2)

link_29 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-2.55781544031631,3.03081076163701,-0.697372249642408)
dA = chrono.ChVectorD(-0.0824751241424791,-3.32666504311193e-15,-0.996593123545253)
cB = chrono.ChVectorD(-2.55350413567683,3.03081076163706,-0.645276340702206)
dB = chrono.ChVectorD(-0.0824751241424785,-3.7038996365011e-15,-0.996593123545253)
link_29.Initialize(body_34,body_35,False,cA,cB,dA,dB)
link_29.SetName("Coincident12")
exported_items.append(link_29)

link_30 = chrono.ChLinkMateGeneric()
link_30.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-2.55781544031631,3.03081076163701,-0.697372249642408)
cB = chrono.ChVectorD(-2.55350413567683,3.03081076163706,-0.645276340702206)
dA = chrono.ChVectorD(-0.0824751241424791,-3.32666504311193e-15,-0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424785,-3.7038996365011e-15,-0.996593123545253)
link_30.Initialize(body_34,body_35,False,cA,cB,dA,dB)
link_30.SetName("Coincident12")
exported_items.append(link_30)


# Mate constraint: Distance7 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_34 , SW name: M-410iB-300 -8/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_35 , SW name: M-410iB-300 -8/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_31 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.05641325164644,3.21365467148157,-0.649738049420612)
cB = chrono.ChVectorD(-2.55704033909956,3.03081076163706,-0.688006267467332)
dA = chrono.ChVectorD(0.0824751241424791,3.32666504311193e-15,0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424785,-3.7038996365011e-15,-0.996593123545253)
link_31.Initialize(body_34,body_35,False,cA,cB,dB)
link_31.SetDistance(0)
link_31.SetName("Distance7")
exported_items.append(link_31)

link_32 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.05641325164644,3.21365467148157,-0.649738049420612)
dA = chrono.ChVectorD(0.0824751241424791,3.32666504311193e-15,0.996593123545253)
cB = chrono.ChVectorD(-2.55704033909956,3.03081076163706,-0.688006267467332)
dB = chrono.ChVectorD(-0.0824751241424785,-3.7038996365011e-15,-0.996593123545253)
link_32.SetFlipped(True)
link_32.Initialize(body_34,body_35,False,cA,cB,dA,dB)
link_32.SetName("Distance7")
exported_items.append(link_32)


# Mate constraint: Coincident13 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_25 , SW name: M-410iB-300 -8/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_35 , SW name: M-410iB-300 -8/M-410iB-300-10-1 ,  SW ref.type:5 (2)

link_33 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.36587439836585,2.78749692402101,-0.789642086984111)
dA = chrono.ChVectorD(-0.0824751241424792,-3.31865507908476e-15,-0.996593123545253)
cB = chrono.ChVectorD(-1.36522498923834,2.78749692402102,-0.781794912729313)
dB = chrono.ChVectorD(0.0824751241424785,3.7038996365011e-15,0.996593123545253)
link_33.SetFlipped(True)
link_33.Initialize(body_25,body_35,False,cA,cB,dA,dB)
link_33.SetName("Coincident13")
exported_items.append(link_33)

link_34 = chrono.ChLinkMateGeneric()
link_34.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.36587439836585,2.78749692402101,-0.789642086984111)
cB = chrono.ChVectorD(-1.36522498923834,2.78749692402102,-0.781794912729313)
dA = chrono.ChVectorD(-0.0824751241424792,-3.31865507908476e-15,-0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424785,3.7038996365011e-15,0.996593123545253)
link_34.Initialize(body_25,body_35,False,cA,cB,dA,dB)
link_34.SetName("Coincident13")
exported_items.append(link_34)


# Mate constraint: Coincident14 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_34 , SW name: M-410iB-300 -8/M-410iB-300-09-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_36 , SW name: M-410iB-300 -8/M-410iB-300-11-1 ,  SW ref.type:5 (2)

link_35 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.5557964463321,3.02764258400496,-0.614782268416985)
dA = chrono.ChVectorD(-0.0824751241424791,-3.32666504311193e-15,-0.996593123545253)
cB = chrono.ChVectorD(-3.56428066235258,3.02764258400502,-0.717301803036086)
dB = chrono.ChVectorD(0.0824751241424787,4.52615856411411e-15,0.996593123545253)
link_35.SetFlipped(True)
link_35.Initialize(body_34,body_36,False,cA,cB,dA,dB)
link_35.SetName("Coincident14")
exported_items.append(link_35)

link_36 = chrono.ChLinkMateGeneric()
link_36.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.5557964463321,3.02764258400496,-0.614782268416985)
cB = chrono.ChVectorD(-3.56428066235258,3.02764258400502,-0.717301803036086)
dA = chrono.ChVectorD(-0.0824751241424791,-3.32666504311193e-15,-0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424787,4.52615856411411e-15,0.996593123545253)
link_36.Initialize(body_34,body_36,False,cA,cB,dA,dB)
link_36.SetName("Coincident14")
exported_items.append(link_36)


# Mate constraint: Distance8 [MateDistanceDim] type:5 align:1 flip:True
#   Entity 0: C::E name: body_34 , SW name: M-410iB-300 -8/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_36 , SW name: M-410iB-300 -8/M-410iB-300-11-1 ,  SW ref.type:2 (2)

link_37 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.06037255245602,3.21365467148157,-0.697580498909526)
cB = chrono.ChVectorD(-3.55910633801413,3.02764258400502,-0.654777543651104)
dA = chrono.ChVectorD(-0.0824751241424791,-3.32666504311193e-15,-0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424788,4.52615856411411e-15,0.996593123545253)
link_37.Initialize(body_34,body_36,False,cA,cB,dB)
link_37.SetDistance(0)
link_37.SetName("Distance8")
exported_items.append(link_37)

link_38 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.06037255245602,3.21365467148157,-0.697580498909526)
dA = chrono.ChVectorD(-0.0824751241424791,-3.32666504311193e-15,-0.996593123545253)
cB = chrono.ChVectorD(-3.55910633801413,3.02764258400502,-0.654777543651104)
dB = chrono.ChVectorD(0.0824751241424788,4.52615856411411e-15,0.996593123545253)
link_38.SetFlipped(True)
link_38.Initialize(body_34,body_36,False,cA,cB,dA,dB)
link_38.SetName("Distance8")
exported_items.append(link_38)


# Mate constraint: Coincident15 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_33 , SW name: M-410iB-300 -8/M-410iB-300-06-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_29 , SW name: M-410iB-300 -8/M-410iB-300-12-1 ,  SW ref.type:5 (2)

link_39 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.81525551082147,1.69376904051648,-0.764969781263137)
dA = chrono.ChVectorD(-0.0824751241424786,-4.30468316532963e-15,-0.996593123545253)
cB = chrono.ChVectorD(-3.8142277058244,1.69376904051649,-0.752550237757514)
dB = chrono.ChVectorD(0.0824751241424791,4.29335628141093e-15,0.996593123545253)
link_39.SetFlipped(True)
link_39.Initialize(body_33,body_29,False,cA,cB,dA,dB)
link_39.SetName("Coincident15")
exported_items.append(link_39)

link_40 = chrono.ChLinkMateGeneric()
link_40.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-3.81525551082147,1.69376904051648,-0.764969781263137)
cB = chrono.ChVectorD(-3.8142277058244,1.69376904051649,-0.752550237757514)
dA = chrono.ChVectorD(-0.0824751241424786,-4.30468316532963e-15,-0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424791,4.29335628141093e-15,0.996593123545253)
link_40.Initialize(body_33,body_29,False,cA,cB,dA,dB)
link_40.SetName("Coincident15")
exported_items.append(link_40)


# Mate constraint: Distance9 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_33 , SW name: M-410iB-300 -8/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_29 , SW name: M-410iB-300 -8/M-410iB-300-12-1 ,  SW ref.type:2 (2)

link_41 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-3.18827765327687,2.27955349819167,-0.957335223193534)
cB = chrono.ChVectorD(-3.82784946227802,1.69376904051649,-0.917149551228494)
dA = chrono.ChVectorD(-0.0824751241424786,-4.30468316532963e-15,-0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424791,4.29335628141093e-15,0.996593123545253)
link_41.Initialize(body_33,body_29,False,cA,cB,dB)
link_41.SetDistance(0)
link_41.SetName("Distance9")
exported_items.append(link_41)

link_42 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-3.18827765327687,2.27955349819167,-0.957335223193534)
dA = chrono.ChVectorD(-0.0824751241424786,-4.30468316532963e-15,-0.996593123545253)
cB = chrono.ChVectorD(-3.82784946227802,1.69376904051649,-0.917149551228494)
dB = chrono.ChVectorD(0.0824751241424791,4.29335628141093e-15,0.996593123545253)
link_42.SetFlipped(True)
link_42.Initialize(body_33,body_29,False,cA,cB,dA,dB)
link_42.SetName("Distance9")
exported_items.append(link_42)


# Mate constraint: Coincident16 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_36 , SW name: M-410iB-300 -8/M-410iB-300-11-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_29 , SW name: M-410iB-300 -8/M-410iB-300-12-1 ,  SW ref.type:5 (2)

link_43 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-4.30817905100364,1.96329996858996,-0.655738954062039)
dA = chrono.ChVectorD(0.0824751241424787,4.52615856411411e-15,0.996593123545253)
cB = chrono.ChVectorD(-4.3127764421453,1.96329996858994,-0.711291806460227)
dB = chrono.ChVectorD(0.0824751241424791,4.29335628141093e-15,0.996593123545253)
link_43.Initialize(body_36,body_29,False,cA,cB,dA,dB)
link_43.SetName("Coincident16")
exported_items.append(link_43)

link_44 = chrono.ChLinkMateGeneric()
link_44.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-4.30817905100364,1.96329996858996,-0.655738954062039)
cB = chrono.ChVectorD(-4.3127764421453,1.96329996858994,-0.711291806460227)
dA = chrono.ChVectorD(0.0824751241424787,4.52615856411411e-15,0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424791,4.29335628141093e-15,0.996593123545253)
link_44.Initialize(body_36,body_29,False,cA,cB,dA,dB)
link_44.SetName("Coincident16")
exported_items.append(link_44)


# Mate constraint: Coincident17 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_28 , SW name: M-410iB-300 -8/M-410iB-300-07-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_26 , SW name: M-410iB-300 -8/M-410iB-300-08-1 ,  SW ref.type:5 (2)

link_45 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.56037999469362,3.00995602354015,-0.952968407411207)
dA = chrono.ChVectorD(-0.0824751241424798,-3.20909687003303e-15,-0.996593123545253)
cB = chrono.ChVectorD(-1.56546780262682,3.00995602354016,-1.01444724060959)
dB = chrono.ChVectorD(0.0824751241424794,3.68991342847604e-15,0.996593123545253)
link_45.SetFlipped(True)
link_45.Initialize(body_28,body_26,False,cA,cB,dA,dB)
link_45.SetName("Coincident17")
exported_items.append(link_45)

link_46 = chrono.ChLinkMateGeneric()
link_46.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.56037999469362,3.00995602354015,-0.952968407411207)
cB = chrono.ChVectorD(-1.56546780262682,3.00995602354016,-1.01444724060959)
dA = chrono.ChVectorD(-0.0824751241424798,-3.20909687003303e-15,-0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424794,3.68991342847604e-15,0.996593123545253)
link_46.Initialize(body_28,body_26,False,cA,cB,dA,dB)
link_46.SetName("Coincident17")
exported_items.append(link_46)


# Mate constraint: Coincident18 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_25 , SW name: M-410iB-300 -8/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_32 , SW name: M-410iB-300 -8/ArmBase-1 ,  SW ref.type:2 (2)

link_47 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-1.50067035795504,2.04602671615662,-1.07259688656262)
cB = chrono.ChVectorD(-1.25867129241134,2.04602671615662,-1.07259688656262)
dA = chrono.ChVectorD(1.1570004097597e-16,-1,3.13028382482648e-15)
dB = chrono.ChVectorD(5.42136132923115e-17,1,-3.51853802391695e-15)
link_47.Initialize(body_25,body_32,False,cA,cB,dB)
link_47.SetDistance(0)
link_47.SetName("Coincident18")
exported_items.append(link_47)

link_48 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.50067035795504,2.04602671615662,-1.07259688656262)
dA = chrono.ChVectorD(1.1570004097597e-16,-1,3.13028382482648e-15)
cB = chrono.ChVectorD(-1.25867129241134,2.04602671615662,-1.07259688656262)
dB = chrono.ChVectorD(5.42136132923115e-17,1,-3.51853802391695e-15)
link_48.SetFlipped(True)
link_48.Initialize(body_25,body_32,False,cA,cB,dA,dB)
link_48.SetName("Coincident18")
exported_items.append(link_48)


# Mate constraint: Concentric1 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_25 , SW name: M-410iB-300 -8/M-410iB-300-02-1 ,  SW ref.type:1 (1)
#   Entity 1: C::E name: body_32 , SW name: M-410iB-300 -8/ArmBase-1 ,  SW ref.type:1 (1)

link_49 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-1.50067035795504,2.04755071615662,-1.07259688656262)
dA = chrono.ChVectorD(-1.1570004097597e-16,1,-3.13028382482648e-15)
cB = chrono.ChVectorD(-1.50067035795504,2.04602671615662,-1.07259688656262)
dB = chrono.ChVectorD(5.42136132923115e-17,1,-3.51853802391695e-15)
link_49.Initialize(body_25,body_32,False,cA,cB,dA,dB)
link_49.SetName("Concentric1")
exported_items.append(link_49)

link_50 = chrono.ChLinkMateGeneric()
link_50.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-1.50067035795504,2.04755071615662,-1.07259688656262)
cB = chrono.ChVectorD(-1.50067035795504,2.04602671615662,-1.07259688656262)
dA = chrono.ChVectorD(-1.1570004097597e-16,1,-3.13028382482648e-15)
dB = chrono.ChVectorD(5.42136132923115e-17,1,-3.51853802391695e-15)
link_50.Initialize(body_25,body_32,False,cA,cB,dA,dB)
link_50.SetName("Concentric1")
exported_items.append(link_50)


# Mate constraint: Coincident2_hinge [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_45 , SW name: M-410iB-300 -2/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_47 , SW name: M-410iB-300 -2/M-410iB-300-03-1 ,  SW ref.type:5 (2)

link_1 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.237440667378504,2.51550127212935,-1.23232581704903)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
cB = chrono.ChVectorD(0.256663804363385,2.51550127212935,-1.00004188499936)
dB = chrono.ChVectorD(-0.0824751241424792,9.11814027060309e-17,-0.996593123545252)
link_1.Initialize(body_45,body_47,False,cA,cB,dA,dB)
link_1.SetName("Coincident2_hinge")
exported_items.append(link_1)

link_2 = chrono.ChLinkMateGeneric()
link_2.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.237440667378504,2.51550127212935,-1.23232581704903)
cB = chrono.ChVectorD(0.256663804363385,2.51550127212935,-1.00004188499936)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424792,9.11814027060309e-17,-0.996593123545252)
link_2.Initialize(body_45,body_47,False,cA,cB,dA,dB)
link_2.SetName("Coincident2_hinge")
exported_items.append(link_2)


# Mate constraint: Distance2 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_45 , SW name: M-410iB-300 -2/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_47 , SW name: M-410iB-300 -2/M-410iB-300-03-1 ,  SW ref.type:2 (2)

link_3 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.468847901417992,2.84164228947283,-1.00664228148036)
cB = chrono.ChVectorD(1.09486376832202,2.54318522667954,-1.06150793833294)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424792,-9.11814027060309e-17,0.996593123545252)
link_3.Initialize(body_45,body_47,False,cA,cB,dB)
link_3.SetDistance(0)
link_3.SetName("Distance2")
exported_items.append(link_3)

link_4 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.468847901417992,2.84164228947283,-1.00664228148036)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
cB = chrono.ChVectorD(1.09486376832202,2.54318522667954,-1.06150793833294)
dB = chrono.ChVectorD(0.0824751241424792,-9.11814027060309e-17,0.996593123545252)
link_4.SetFlipped(True)
link_4.Initialize(body_45,body_47,False,cA,cB,dA,dB)
link_4.SetName("Distance2")
exported_items.append(link_4)


# Mate constraint: Coincident3 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_45 , SW name: M-410iB-300 -2/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_41 , SW name: M-410iB-300 -2/M-410iB-300-04-1 ,  SW ref.type:5 (2)

link_5 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.260985806741079,2.78049690546384,-0.947859062251846)
dA = chrono.ChVectorD(0.0824751241424792,1.35945749492389e-19,0.996593123545252)
cB = chrono.ChVectorD(0.266759107195709,2.78049690546384,-0.87809703893785)
dB = chrono.ChVectorD(0.0824751241424787,-6.19079440489223e-17,0.996593123545253)
link_5.Initialize(body_45,body_41,False,cA,cB,dA,dB)
link_5.SetName("Coincident3")
exported_items.append(link_5)

link_6 = chrono.ChLinkMateGeneric()
link_6.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.260985806741079,2.78049690546384,-0.947859062251846)
cB = chrono.ChVectorD(0.266759107195709,2.78049690546384,-0.87809703893785)
dA = chrono.ChVectorD(0.0824751241424792,1.35945749492389e-19,0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424787,-6.19079440489223e-17,0.996593123545253)
link_6.Initialize(body_45,body_41,False,cA,cB,dA,dB)
link_6.SetName("Coincident3")
exported_items.append(link_6)


# Mate constraint: Distance3 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_45 , SW name: M-410iB-300 -2/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_41 , SW name: M-410iB-300 -2/M-410iB-300-04-1 ,  SW ref.type:2 (2)

link_7 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.264664235980002,2.78049691677857,-0.903410504022453)
cB = chrono.ChVectorD(0.336053492470973,2.80967719196082,-0.883831639039869)
dA = chrono.ChVectorD(0.0824751241424792,1.35945749492389e-19,0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424787,6.19079440489223e-17,-0.996593123545253)
link_7.Initialize(body_45,body_41,False,cA,cB,dB)
link_7.SetDistance(0)
link_7.SetName("Distance3")
exported_items.append(link_7)

link_8 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.264664235980002,2.78049691677857,-0.903410504022453)
dA = chrono.ChVectorD(0.0824751241424792,1.35945749492389e-19,0.996593123545252)
cB = chrono.ChVectorD(0.336053492470973,2.80967719196082,-0.883831639039869)
dB = chrono.ChVectorD(-0.0824751241424787,6.19079440489223e-17,-0.996593123545253)
link_8.SetFlipped(True)
link_8.Initialize(body_45,body_41,False,cA,cB,dA,dB)
link_8.SetName("Distance3")
exported_items.append(link_8)


# Mate constraint: Coincident4 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_41 , SW name: M-410iB-300 -2/M-410iB-300-04-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_40 , SW name: M-410iB-300 -2/M-410iB-300-05-1 ,  SW ref.type:5 (2)

link_9 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.07009216653166,2.7654491237564,-0.916033276809927)
dA = chrono.ChVectorD(-0.996418499736232,0.0187192635196773,0.0824606727881728)
cB = chrono.ChVectorD(1.35881310090397,2.76002505419567,-0.939926974591204)
dB = chrono.ChVectorD(-0.996418499736232,0.0187192635196774,0.0824606727881729)
link_9.Initialize(body_41,body_40,False,cA,cB,dA,dB)
link_9.SetName("Coincident4")
exported_items.append(link_9)

link_10 = chrono.ChLinkMateGeneric()
link_10.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.07009216653166,2.7654491237564,-0.916033276809927)
cB = chrono.ChVectorD(1.35881310090397,2.76002505419567,-0.939926974591204)
dA = chrono.ChVectorD(-0.996418499736232,0.0187192635196773,0.0824606727881728)
dB = chrono.ChVectorD(-0.996418499736232,0.0187192635196774,0.0824606727881729)
link_10.Initialize(body_41,body_40,False,cA,cB,dA,dB)
link_10.SetName("Coincident4")
exported_items.append(link_10)


# Mate constraint: Coincident5 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_47 , SW name: M-410iB-300 -2/M-410iB-300-03-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_40 , SW name: M-410iB-300 -2/M-410iB-300-05-1 ,  SW ref.type:5 (2)

link_11 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.44822374457179,2.75811166841886,-1.09865189109924)
dA = chrono.ChVectorD(-0.0824751241424792,9.11814027060309e-17,-0.996593123545252)
cB = chrono.ChVectorD(1.45777518922982,2.75811166841886,-0.983236435043956)
dB = chrono.ChVectorD(-0.0824751241424788,-1.81929124543068e-16,-0.996593123545253)
link_11.Initialize(body_47,body_40,False,cA,cB,dA,dB)
link_11.SetName("Coincident5")
exported_items.append(link_11)

link_12 = chrono.ChLinkMateGeneric()
link_12.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.44822374457179,2.75811166841886,-1.09865189109924)
cB = chrono.ChVectorD(1.45777518922982,2.75811166841886,-0.983236435043956)
dA = chrono.ChVectorD(-0.0824751241424792,9.11814027060309e-17,-0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424788,-1.81929124543068e-16,-0.996593123545253)
link_12.Initialize(body_47,body_40,False,cA,cB,dA,dB)
link_12.SetName("Coincident5")
exported_items.append(link_12)


# Mate constraint: Coincident6 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_47 , SW name: M-410iB-300 -2/M-410iB-300-03-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_48 , SW name: M-410iB-300 -2/M-410iB-300-06-1 ,  SW ref.type:5 (2)

link_13 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.42574833632556,2.75811166841886,-1.37023483856317)
dA = chrono.ChVectorD(-0.0824751241424792,9.11814027060309e-17,-0.996593123545252)
cB = chrono.ChVectorD(1.42836692151708,2.75811166841885,-1.3385930068906)
dB = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
link_13.SetFlipped(True)
link_13.Initialize(body_47,body_48,False,cA,cB,dA,dB)
link_13.SetName("Coincident6")
exported_items.append(link_13)

link_14 = chrono.ChLinkMateGeneric()
link_14.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.42574833632556,2.75811166841886,-1.37023483856317)
cB = chrono.ChVectorD(1.42836692151708,2.75811166841885,-1.3385930068906)
dA = chrono.ChVectorD(-0.0824751241424792,9.11814027060309e-17,-0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
link_14.Initialize(body_47,body_48,False,cA,cB,dA,dB)
link_14.SetName("Coincident6")
exported_items.append(link_14)


# Mate constraint: Distance4 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_47 , SW name: M-410iB-300 -2/M-410iB-300-03-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_48 , SW name: M-410iB-300 -2/M-410iB-300-06-1 ,  SW ref.type:2 (2)

link_15 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.24088928761079,2.91434507456169,-1.35493644583758)
cB = chrono.ChVectorD(1.32186931481946,2.58269164685799,-1.32977957729156)
dA = chrono.ChVectorD(0.0824751241424792,-9.11814027060309e-17,0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
link_15.Initialize(body_47,body_48,False,cA,cB,dB)
link_15.SetDistance(0)
link_15.SetName("Distance4")
exported_items.append(link_15)

link_16 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.24088928761079,2.91434507456169,-1.35493644583758)
dA = chrono.ChVectorD(0.0824751241424792,-9.11814027060309e-17,0.996593123545252)
cB = chrono.ChVectorD(1.32186931481946,2.58269164685799,-1.32977957729156)
dB = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
link_16.SetFlipped(True)
link_16.Initialize(body_47,body_48,False,cA,cB,dA,dB)
link_16.SetName("Distance4")
exported_items.append(link_16)


# Mate constraint: Coincident7 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_45 , SW name: M-410iB-300 -2/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_42 , SW name: M-410iB-300 -2/M-410iB-300-07-1 ,  SW ref.type:5 (2)

link_17 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.264245082724809,2.51550127212935,-0.908433051896836)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
cB = chrono.ChVectorD(0.23961381126185,2.51550127212935,-1.20606650221749)
dB = chrono.ChVectorD(0.0824751241424797,1.09694154801221e-16,0.996593123545252)
link_17.SetFlipped(True)
link_17.Initialize(body_45,body_42,False,cA,cB,dA,dB)
link_17.SetName("Coincident7")
exported_items.append(link_17)

link_18 = chrono.ChLinkMateGeneric()
link_18.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.264245082724809,2.51550127212935,-0.908433051896836)
cB = chrono.ChVectorD(0.23961381126185,2.51550127212935,-1.20606650221749)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424797,1.09694154801221e-16,0.996593123545252)
link_18.Initialize(body_45,body_42,False,cA,cB,dA,dB)
link_18.SetName("Coincident7")
exported_items.append(link_18)


# Mate constraint: Coincident8 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_48 , SW name: M-410iB-300 -2/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_42 , SW name: M-410iB-300 -2/M-410iB-300-07-1 ,  SW ref.type:2 (2)

link_19 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.965778716625616,3.10515332885273,-1.18993452618763)
cB = chrono.ChVectorD(-0.0736523530408371,3.00995602354016,-1.1039142592573)
dA = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424797,-1.09694154801221e-16,-0.996593123545252)
link_19.Initialize(body_48,body_42,False,cA,cB,dB)
link_19.SetDistance(0)
link_19.SetName("Coincident8")
exported_items.append(link_19)

link_20 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.965778716625616,3.10515332885273,-1.18993452618763)
dA = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
cB = chrono.ChVectorD(-0.0736523530408371,3.00995602354016,-1.1039142592573)
dB = chrono.ChVectorD(-0.0824751241424797,-1.09694154801221e-16,-0.996593123545252)
link_20.Initialize(body_48,body_42,False,cA,cB,dA,dB)
link_20.SetName("Coincident8")
exported_items.append(link_20)


# Mate constraint: Distance5 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_48 , SW name: M-410iB-300 -2/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_43 , SW name: M-410iB-300 -2/M-410iB-300-08-1 ,  SW ref.type:2 (2)

link_21 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.965778716625616,3.10515332885273,-1.18993452618763)
cB = chrono.ChVectorD(-0.0686560854381103,3.01604196029193,-1.12650127823121)
dA = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424794,-3.71122403641788e-16,0.996593123545252)
link_21.Initialize(body_48,body_43,False,cA,cB,dB)
link_21.SetDistance(0)
link_21.SetName("Distance5")
exported_items.append(link_21)

link_22 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.965778716625616,3.10515332885273,-1.18993452618763)
dA = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
cB = chrono.ChVectorD(-0.0686560854381103,3.01604196029193,-1.12650127823121)
dB = chrono.ChVectorD(0.0824751241424794,-3.71122403641788e-16,0.996593123545252)
link_22.SetFlipped(True)
link_22.Initialize(body_48,body_43,False,cA,cB,dA,dB)
link_22.SetName("Distance5")
exported_items.append(link_22)


# Mate constraint: Coincident9 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_48 , SW name: M-410iB-300 -2/M-410iB-300-06-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_43 , SW name: M-410iB-300 -2/M-410iB-300-08-1 ,  SW ref.type:5 (2)

link_23 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.12117568604869,3.25502265002171,-1.20279472363605)
dA = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
cB = chrono.ChVectorD(1.11895512580625,3.25502265002172,-1.22962699689438)
dB = chrono.ChVectorD(-0.0824751241424794,3.71122403641788e-16,-0.996593123545252)
link_23.Initialize(body_48,body_43,False,cA,cB,dA,dB)
link_23.SetName("Coincident9")
exported_items.append(link_23)

link_24 = chrono.ChLinkMateGeneric()
link_24.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.12117568604869,3.25502265002171,-1.20279472363605)
cB = chrono.ChVectorD(1.11895512580625,3.25502265002172,-1.22962699689438)
dA = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424794,3.71122403641788e-16,-0.996593123545252)
link_24.Initialize(body_48,body_43,False,cA,cB,dA,dB)
link_24.SetName("Coincident9")
exported_items.append(link_24)


# Mate constraint: Coincident10 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_38 , SW name: M-410iB-300 -2/M-410iB-300-09-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_48 , SW name: M-410iB-300 -2/M-410iB-300-06-1 ,  SW ref.type:5 (2)

link_25 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.41485957776935,2.75811166841883,-1.50180980754849)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
cB = chrono.ChVectorD(1.4207379725339,2.75811166841885,-1.43077787081854)
dB = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
link_25.Initialize(body_38,body_48,False,cA,cB,dA,dB)
link_25.SetName("Coincident10")
exported_items.append(link_25)

link_26 = chrono.ChLinkMateGeneric()
link_26.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.41485957776935,2.75811166841883,-1.50180980754849)
cB = chrono.ChVectorD(1.4207379725339,2.75811166841885,-1.43077787081854)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
link_26.Initialize(body_38,body_48,False,cA,cB,dA,dB)
link_26.SetName("Coincident10")
exported_items.append(link_26)


# Mate constraint: Coincident11 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_45 , SW name: M-410iB-300 -2/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_38 , SW name: M-410iB-300 -2/M-410iB-300-09-1 ,  SW ref.type:2 (2)

link_27 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.128154728112769,2.72491052060182,-1.36774276125386)
cB = chrono.ChVectorD(1.41507253573637,3.21365467148159,-1.49545572370462)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424791,7.87401827767598e-18,-0.996593123545253)
link_27.Initialize(body_45,body_38,False,cA,cB,dB)
link_27.SetDistance(0)
link_27.SetName("Coincident11")
exported_items.append(link_27)

link_28 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.128154728112769,2.72491052060182,-1.36774276125386)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
cB = chrono.ChVectorD(1.41507253573637,3.21365467148159,-1.49545572370462)
dB = chrono.ChVectorD(-0.0824751241424791,7.87401827767598e-18,-0.996593123545253)
link_28.Initialize(body_45,body_38,False,cA,cB,dA,dB)
link_28.SetName("Coincident11")
exported_items.append(link_28)


# Mate constraint: Coincident12 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_38 , SW name: M-410iB-300 -2/M-410iB-300-09-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_39 , SW name: M-410iB-300 -2/M-410iB-300-10-1 ,  SW ref.type:5 (2)

link_29 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.916474724406245,3.03081076163703,-1.44782152348282)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
cB = chrono.ChVectorD(0.912163419766749,3.03081076163706,-1.49991743242302)
dB = chrono.ChVectorD(0.0824751241424785,-3.85108611666851e-16,0.996593123545252)
link_29.Initialize(body_38,body_39,False,cA,cB,dA,dB)
link_29.SetName("Coincident12")
exported_items.append(link_29)

link_30 = chrono.ChLinkMateGeneric()
link_30.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.916474724406245,3.03081076163703,-1.44782152348282)
cB = chrono.ChVectorD(0.912163419766749,3.03081076163706,-1.49991743242302)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424785,-3.85108611666851e-16,0.996593123545252)
link_30.Initialize(body_38,body_39,False,cA,cB,dA,dB)
link_30.SetName("Coincident12")
exported_items.append(link_30)


# Mate constraint: Distance7 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_38 , SW name: M-410iB-300 -2/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_39 , SW name: M-410iB-300 -2/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_31 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.41507253573637,3.21365467148159,-1.49545572370462)
cB = chrono.ChVectorD(0.915699623189482,3.03081076163706,-1.45718750565789)
dA = chrono.ChVectorD(-0.0824751241424791,7.87401827767598e-18,-0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424785,-3.85108611666851e-16,0.996593123545252)
link_31.Initialize(body_38,body_39,False,cA,cB,dB)
link_31.SetDistance(0)
link_31.SetName("Distance7")
exported_items.append(link_31)

link_32 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.41507253573637,3.21365467148159,-1.49545572370462)
dA = chrono.ChVectorD(-0.0824751241424791,7.87401827767598e-18,-0.996593123545253)
cB = chrono.ChVectorD(0.915699623189482,3.03081076163706,-1.45718750565789)
dB = chrono.ChVectorD(0.0824751241424785,-3.85108611666851e-16,0.996593123545252)
link_32.SetFlipped(True)
link_32.Initialize(body_38,body_39,False,cA,cB,dA,dB)
link_32.SetName("Distance7")
exported_items.append(link_32)


# Mate constraint: Coincident13 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_45 , SW name: M-410iB-300 -2/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_39 , SW name: M-410iB-300 -2/M-410iB-300-10-1 ,  SW ref.type:5 (2)

link_33 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.275466317544226,2.78749692402101,-1.35555168614112)
dA = chrono.ChVectorD(0.0824751241424792,1.35945749492389e-19,0.996593123545252)
cB = chrono.ChVectorD(-0.276115726671744,2.78749692402101,-1.36339886039591)
dB = chrono.ChVectorD(-0.0824751241424785,3.85108611666851e-16,-0.996593123545252)
link_33.SetFlipped(True)
link_33.Initialize(body_45,body_39,False,cA,cB,dA,dB)
link_33.SetName("Coincident13")
exported_items.append(link_33)

link_34 = chrono.ChLinkMateGeneric()
link_34.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-0.275466317544226,2.78749692402101,-1.35555168614112)
cB = chrono.ChVectorD(-0.276115726671744,2.78749692402101,-1.36339886039591)
dA = chrono.ChVectorD(0.0824751241424792,1.35945749492389e-19,0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424785,3.85108611666851e-16,-0.996593123545252)
link_34.Initialize(body_45,body_39,False,cA,cB,dA,dB)
link_34.SetName("Coincident13")
exported_items.append(link_34)


# Mate constraint: Coincident14 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_38 , SW name: M-410iB-300 -2/M-410iB-300-09-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_37 , SW name: M-410iB-300 -2/M-410iB-300-11-1 ,  SW ref.type:5 (2)

link_35 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.91445573042203,3.02764258400498,-1.53041150470824)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
cB = chrono.ChVectorD(1.9229399464425,3.02764258400502,-1.42789197008914)
dB = chrono.ChVectorD(-0.0824751241424787,1.20736753927986e-15,-0.996593123545252)
link_35.SetFlipped(True)
link_35.Initialize(body_38,body_37,False,cA,cB,dA,dB)
link_35.SetName("Coincident14")
exported_items.append(link_35)

link_36 = chrono.ChLinkMateGeneric()
link_36.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.91445573042203,3.02764258400498,-1.53041150470824)
cB = chrono.ChVectorD(1.9229399464425,3.02764258400502,-1.42789197008914)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424787,1.20736753927986e-15,-0.996593123545252)
link_36.Initialize(body_38,body_37,False,cA,cB,dA,dB)
link_36.SetName("Coincident14")
exported_items.append(link_36)


# Mate constraint: Distance8 [MateDistanceDim] type:5 align:1 flip:True
#   Entity 0: C::E name: body_38 , SW name: M-410iB-300 -2/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_37 , SW name: M-410iB-300 -2/M-410iB-300-11-1 ,  SW ref.type:2 (2)

link_37 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.41903183654595,3.21365467148159,-1.4476132742157)
cB = chrono.ChVectorD(1.91776562210405,3.02764258400502,-1.49041622947412)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424787,1.20736753927986e-15,-0.996593123545253)
link_37.Initialize(body_38,body_37,False,cA,cB,dB)
link_37.SetDistance(0)
link_37.SetName("Distance8")
exported_items.append(link_37)

link_38 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.41903183654595,3.21365467148159,-1.4476132742157)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
cB = chrono.ChVectorD(1.91776562210405,3.02764258400502,-1.49041622947412)
dB = chrono.ChVectorD(-0.0824751241424787,1.20736753927986e-15,-0.996593123545253)
link_38.SetFlipped(True)
link_38.Initialize(body_38,body_37,False,cA,cB,dA,dB)
link_38.SetName("Distance8")
exported_items.append(link_38)


# Mate constraint: Coincident15 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_48 , SW name: M-410iB-300 -2/M-410iB-300-06-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_46 , SW name: M-410iB-300 -2/M-410iB-300-12-1 ,  SW ref.type:5 (2)

link_39 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(2.17391479491138,1.6937690405165,-1.38022399186209)
dA = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
cB = chrono.ChVectorD(2.17288698991433,1.69376904051649,-1.39264353536771)
dB = chrono.ChVectorD(-0.082475124142479,9.74593356253719e-16,-0.996593123545253)
link_39.SetFlipped(True)
link_39.Initialize(body_48,body_46,False,cA,cB,dA,dB)
link_39.SetName("Coincident15")
exported_items.append(link_39)

link_40 = chrono.ChLinkMateGeneric()
link_40.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(2.17391479491138,1.6937690405165,-1.38022399186209)
cB = chrono.ChVectorD(2.17288698991433,1.69376904051649,-1.39264353536771)
dA = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
dB = chrono.ChVectorD(-0.082475124142479,9.74593356253719e-16,-0.996593123545253)
link_40.Initialize(body_48,body_46,False,cA,cB,dA,dB)
link_40.SetName("Coincident15")
exported_items.append(link_40)


# Mate constraint: Distance9 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_48 , SW name: M-410iB-300 -2/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_46 , SW name: M-410iB-300 -2/M-410iB-300-12-1 ,  SW ref.type:2 (2)

link_41 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.54693693736679,2.27955349819168,-1.18785854993169)
cB = chrono.ChVectorD(2.18650874636795,1.69376904051649,-1.22804422189673)
dA = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
dB = chrono.ChVectorD(-0.082475124142479,9.74593356253719e-16,-0.996593123545253)
link_41.Initialize(body_48,body_46,False,cA,cB,dB)
link_41.SetDistance(0)
link_41.SetName("Distance9")
exported_items.append(link_41)

link_42 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.54693693736679,2.27955349819168,-1.18785854993169)
dA = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
cB = chrono.ChVectorD(2.18650874636795,1.69376904051649,-1.22804422189673)
dB = chrono.ChVectorD(-0.082475124142479,9.74593356253719e-16,-0.996593123545253)
link_42.SetFlipped(True)
link_42.Initialize(body_48,body_46,False,cA,cB,dA,dB)
link_42.SetName("Distance9")
exported_items.append(link_42)


# Mate constraint: Coincident16 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_37 , SW name: M-410iB-300 -2/M-410iB-300-11-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_46 , SW name: M-410iB-300 -2/M-410iB-300-12-1 ,  SW ref.type:5 (2)

link_43 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(2.66683833509356,1.96329996858996,-1.48945481906318)
dA = chrono.ChVectorD(-0.0824751241424787,1.20736753927986e-15,-0.996593123545252)
cB = chrono.ChVectorD(2.67143572623522,1.96329996858993,-1.43390196666499)
dB = chrono.ChVectorD(-0.082475124142479,9.74593356253719e-16,-0.996593123545253)
link_43.Initialize(body_37,body_46,False,cA,cB,dA,dB)
link_43.SetName("Coincident16")
exported_items.append(link_43)

link_44 = chrono.ChLinkMateGeneric()
link_44.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(2.66683833509356,1.96329996858996,-1.48945481906318)
cB = chrono.ChVectorD(2.67143572623522,1.96329996858993,-1.43390196666499)
dA = chrono.ChVectorD(-0.0824751241424787,1.20736753927986e-15,-0.996593123545252)
dB = chrono.ChVectorD(-0.082475124142479,9.74593356253719e-16,-0.996593123545253)
link_44.Initialize(body_37,body_46,False,cA,cB,dA,dB)
link_44.SetName("Coincident16")
exported_items.append(link_44)


# Mate constraint: Coincident17 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_42 , SW name: M-410iB-300 -2/M-410iB-300-07-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_43 , SW name: M-410iB-300 -2/M-410iB-300-08-1 ,  SW ref.type:5 (2)

link_45 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.0809607212164747,3.00995602354016,-1.19222536571402)
dA = chrono.ChVectorD(0.0824751241424797,1.09694154801221e-16,0.996593123545252)
cB = chrono.ChVectorD(-0.0758729132832662,3.00995602354016,-1.13074653251563)
dB = chrono.ChVectorD(-0.0824751241424794,3.71122403641788e-16,-0.996593123545252)
link_45.SetFlipped(True)
link_45.Initialize(body_42,body_43,False,cA,cB,dA,dB)
link_45.SetName("Coincident17")
exported_items.append(link_45)

link_46 = chrono.ChLinkMateGeneric()
link_46.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-0.0809607212164747,3.00995602354016,-1.19222536571402)
cB = chrono.ChVectorD(-0.0758729132832662,3.00995602354016,-1.13074653251563)
dA = chrono.ChVectorD(0.0824751241424797,1.09694154801221e-16,0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424794,3.71122403641788e-16,-0.996593123545252)
link_46.Initialize(body_42,body_43,False,cA,cB,dA,dB)
link_46.SetName("Coincident17")
exported_items.append(link_46)


# Mate constraint: Coincident18 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_45 , SW name: M-410iB-300 -2/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_44 , SW name: M-410iB-300 -2/ArmBase-1 ,  SW ref.type:2 (2)

link_47 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.140670357955037,2.04602671615662,-1.07259688656261)
cB = chrono.ChVectorD(-0.382669423498732,2.04602671615662,-1.07259688656261)
dA = chrono.ChVectorD(-1.32297045065857e-16,-1,1.10849259381635e-17)
dB = chrono.ChVectorD(0,1,0)
link_47.Initialize(body_45,body_44,False,cA,cB,dB)
link_47.SetDistance(0)
link_47.SetName("Coincident18")
exported_items.append(link_47)

link_48 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.140670357955037,2.04602671615662,-1.07259688656261)
dA = chrono.ChVectorD(-1.32297045065857e-16,-1,1.10849259381635e-17)
cB = chrono.ChVectorD(-0.382669423498732,2.04602671615662,-1.07259688656261)
dB = chrono.ChVectorD(0,1,0)
link_48.SetFlipped(True)
link_48.Initialize(body_45,body_44,False,cA,cB,dA,dB)
link_48.SetName("Coincident18")
exported_items.append(link_48)


# Mate constraint: Concentric1 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_45 , SW name: M-410iB-300 -2/M-410iB-300-02-1 ,  SW ref.type:1 (1)
#   Entity 1: C::E name: body_44 , SW name: M-410iB-300 -2/ArmBase-1 ,  SW ref.type:1 (1)

link_49 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.140670357955037,2.04755071615662,-1.07259688656261)
dA = chrono.ChVectorD(1.32297045065857e-16,1,-1.10849259381635e-17)
cB = chrono.ChVectorD(-0.140670357955037,2.04602671615662,-1.07259688656261)
dB = chrono.ChVectorD(0,1,0)
link_49.Initialize(body_45,body_44,False,cA,cB,dA,dB)
link_49.SetName("Concentric1")
exported_items.append(link_49)

link_50 = chrono.ChLinkMateGeneric()
link_50.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-0.140670357955037,2.04755071615662,-1.07259688656261)
cB = chrono.ChVectorD(-0.140670357955037,2.04602671615662,-1.07259688656261)
dA = chrono.ChVectorD(1.32297045065857e-16,1,-1.10849259381635e-17)
dB = chrono.ChVectorD(0,1,0)
link_50.Initialize(body_45,body_44,False,cA,cB,dA,dB)
link_50.SetName("Concentric1")
exported_items.append(link_50)


# Mate constraint: Coincident2_hinge [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_54 , SW name: M-410iB-300 -3/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_55 , SW name: M-410iB-300 -3/M-410iB-300-03-1 ,  SW ref.type:5 (2)

link_1 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.237440667378504,2.51550127212935,-2.68232581704903)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
cB = chrono.ChVectorD(0.256663804363393,2.51550127212935,-2.45004188499936)
dB = chrono.ChVectorD(-0.0824751241424792,9.11814027060309e-17,-0.996593123545252)
link_1.Initialize(body_54,body_55,False,cA,cB,dA,dB)
link_1.SetName("Coincident2_hinge")
exported_items.append(link_1)

link_2 = chrono.ChLinkMateGeneric()
link_2.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.237440667378504,2.51550127212935,-2.68232581704903)
cB = chrono.ChVectorD(0.256663804363393,2.51550127212935,-2.45004188499936)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424792,9.11814027060309e-17,-0.996593123545252)
link_2.Initialize(body_54,body_55,False,cA,cB,dA,dB)
link_2.SetName("Coincident2_hinge")
exported_items.append(link_2)


# Mate constraint: Distance2 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_54 , SW name: M-410iB-300 -3/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_55 , SW name: M-410iB-300 -3/M-410iB-300-03-1 ,  SW ref.type:2 (2)

link_3 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.468847901417993,2.84164228947283,-2.45664228148036)
cB = chrono.ChVectorD(1.09486376832203,2.54318522667954,-2.51150793833294)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424792,-9.11814027060309e-17,0.996593123545252)
link_3.Initialize(body_54,body_55,False,cA,cB,dB)
link_3.SetDistance(0)
link_3.SetName("Distance2")
exported_items.append(link_3)

link_4 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.468847901417993,2.84164228947283,-2.45664228148036)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
cB = chrono.ChVectorD(1.09486376832203,2.54318522667954,-2.51150793833294)
dB = chrono.ChVectorD(0.0824751241424792,-9.11814027060309e-17,0.996593123545252)
link_4.SetFlipped(True)
link_4.Initialize(body_54,body_55,False,cA,cB,dA,dB)
link_4.SetName("Distance2")
exported_items.append(link_4)


# Mate constraint: Coincident3 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_54 , SW name: M-410iB-300 -3/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_51 , SW name: M-410iB-300 -3/M-410iB-300-04-1 ,  SW ref.type:5 (2)

link_5 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.260985806741079,2.78049690546384,-2.39785906225185)
dA = chrono.ChVectorD(0.0824751241424792,1.35945749492389e-19,0.996593123545252)
cB = chrono.ChVectorD(0.266759107195717,2.78049690546384,-2.32809703893785)
dB = chrono.ChVectorD(0.0824751241424787,-6.19079440489223e-17,0.996593123545253)
link_5.Initialize(body_54,body_51,False,cA,cB,dA,dB)
link_5.SetName("Coincident3")
exported_items.append(link_5)

link_6 = chrono.ChLinkMateGeneric()
link_6.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.260985806741079,2.78049690546384,-2.39785906225185)
cB = chrono.ChVectorD(0.266759107195717,2.78049690546384,-2.32809703893785)
dA = chrono.ChVectorD(0.0824751241424792,1.35945749492389e-19,0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424787,-6.19079440489223e-17,0.996593123545253)
link_6.Initialize(body_54,body_51,False,cA,cB,dA,dB)
link_6.SetName("Coincident3")
exported_items.append(link_6)


# Mate constraint: Distance3 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_54 , SW name: M-410iB-300 -3/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_51 , SW name: M-410iB-300 -3/M-410iB-300-04-1 ,  SW ref.type:2 (2)

link_7 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.264664235980002,2.78049691677857,-2.35341050402245)
cB = chrono.ChVectorD(0.336053492470982,2.80967719196082,-2.33383163903987)
dA = chrono.ChVectorD(0.0824751241424792,1.35945749492389e-19,0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424787,6.19079440489223e-17,-0.996593123545253)
link_7.Initialize(body_54,body_51,False,cA,cB,dB)
link_7.SetDistance(0)
link_7.SetName("Distance3")
exported_items.append(link_7)

link_8 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.264664235980002,2.78049691677857,-2.35341050402245)
dA = chrono.ChVectorD(0.0824751241424792,1.35945749492389e-19,0.996593123545252)
cB = chrono.ChVectorD(0.336053492470982,2.80967719196082,-2.33383163903987)
dB = chrono.ChVectorD(-0.0824751241424787,6.19079440489223e-17,-0.996593123545253)
link_8.SetFlipped(True)
link_8.Initialize(body_54,body_51,False,cA,cB,dA,dB)
link_8.SetName("Distance3")
exported_items.append(link_8)


# Mate constraint: Coincident4 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_51 , SW name: M-410iB-300 -3/M-410iB-300-04-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_56 , SW name: M-410iB-300 -3/M-410iB-300-05-1 ,  SW ref.type:5 (2)

link_9 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.07009216653166,2.7654491237564,-2.36603327680993)
dA = chrono.ChVectorD(-0.996418499736232,0.0187192635196773,0.0824606727881728)
cB = chrono.ChVectorD(1.35881310090398,2.76002505419567,-2.38992697459121)
dB = chrono.ChVectorD(-0.996418499736232,0.0187192635196774,0.0824606727881729)
link_9.Initialize(body_51,body_56,False,cA,cB,dA,dB)
link_9.SetName("Coincident4")
exported_items.append(link_9)

link_10 = chrono.ChLinkMateGeneric()
link_10.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.07009216653166,2.7654491237564,-2.36603327680993)
cB = chrono.ChVectorD(1.35881310090398,2.76002505419567,-2.38992697459121)
dA = chrono.ChVectorD(-0.996418499736232,0.0187192635196773,0.0824606727881728)
dB = chrono.ChVectorD(-0.996418499736232,0.0187192635196774,0.0824606727881729)
link_10.Initialize(body_51,body_56,False,cA,cB,dA,dB)
link_10.SetName("Coincident4")
exported_items.append(link_10)


# Mate constraint: Coincident5 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_55 , SW name: M-410iB-300 -3/M-410iB-300-03-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_56 , SW name: M-410iB-300 -3/M-410iB-300-05-1 ,  SW ref.type:5 (2)

link_11 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.4482237445718,2.75811166841886,-2.54865189109924)
dA = chrono.ChVectorD(-0.0824751241424792,9.11814027060309e-17,-0.996593123545252)
cB = chrono.ChVectorD(1.45777518922983,2.75811166841886,-2.43323643504396)
dB = chrono.ChVectorD(-0.0824751241424788,-1.81929124543068e-16,-0.996593123545253)
link_11.Initialize(body_55,body_56,False,cA,cB,dA,dB)
link_11.SetName("Coincident5")
exported_items.append(link_11)

link_12 = chrono.ChLinkMateGeneric()
link_12.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.4482237445718,2.75811166841886,-2.54865189109924)
cB = chrono.ChVectorD(1.45777518922983,2.75811166841886,-2.43323643504396)
dA = chrono.ChVectorD(-0.0824751241424792,9.11814027060309e-17,-0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424788,-1.81929124543068e-16,-0.996593123545253)
link_12.Initialize(body_55,body_56,False,cA,cB,dA,dB)
link_12.SetName("Coincident5")
exported_items.append(link_12)


# Mate constraint: Coincident6 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_55 , SW name: M-410iB-300 -3/M-410iB-300-03-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_49 , SW name: M-410iB-300 -3/M-410iB-300-06-1 ,  SW ref.type:5 (2)

link_13 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.42574833632557,2.75811166841886,-2.82023483856317)
dA = chrono.ChVectorD(-0.0824751241424792,9.11814027060309e-17,-0.996593123545252)
cB = chrono.ChVectorD(1.42836692151708,2.75811166841885,-2.78859300689061)
dB = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
link_13.SetFlipped(True)
link_13.Initialize(body_55,body_49,False,cA,cB,dA,dB)
link_13.SetName("Coincident6")
exported_items.append(link_13)

link_14 = chrono.ChLinkMateGeneric()
link_14.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.42574833632557,2.75811166841886,-2.82023483856317)
cB = chrono.ChVectorD(1.42836692151708,2.75811166841885,-2.78859300689061)
dA = chrono.ChVectorD(-0.0824751241424792,9.11814027060309e-17,-0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
link_14.Initialize(body_55,body_49,False,cA,cB,dA,dB)
link_14.SetName("Coincident6")
exported_items.append(link_14)


# Mate constraint: Distance4 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_55 , SW name: M-410iB-300 -3/M-410iB-300-03-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_49 , SW name: M-410iB-300 -3/M-410iB-300-06-1 ,  SW ref.type:2 (2)

link_15 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.2408892876108,2.91434507456168,-2.80493644583758)
cB = chrono.ChVectorD(1.32186931481946,2.58269164685799,-2.77977957729156)
dA = chrono.ChVectorD(0.0824751241424792,-9.11814027060309e-17,0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
link_15.Initialize(body_55,body_49,False,cA,cB,dB)
link_15.SetDistance(0)
link_15.SetName("Distance4")
exported_items.append(link_15)

link_16 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.2408892876108,2.91434507456168,-2.80493644583758)
dA = chrono.ChVectorD(0.0824751241424792,-9.11814027060309e-17,0.996593123545252)
cB = chrono.ChVectorD(1.32186931481946,2.58269164685799,-2.77977957729156)
dB = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
link_16.SetFlipped(True)
link_16.Initialize(body_55,body_49,False,cA,cB,dA,dB)
link_16.SetName("Distance4")
exported_items.append(link_16)


# Mate constraint: Coincident7 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_54 , SW name: M-410iB-300 -3/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_50 , SW name: M-410iB-300 -3/M-410iB-300-07-1 ,  SW ref.type:5 (2)

link_17 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.264245082724809,2.51550127212935,-2.35843305189684)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
cB = chrono.ChVectorD(0.239613811261848,2.51550127212935,-2.65606650221749)
dB = chrono.ChVectorD(0.0824751241424797,1.09694154801221e-16,0.996593123545252)
link_17.SetFlipped(True)
link_17.Initialize(body_54,body_50,False,cA,cB,dA,dB)
link_17.SetName("Coincident7")
exported_items.append(link_17)

link_18 = chrono.ChLinkMateGeneric()
link_18.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.264245082724809,2.51550127212935,-2.35843305189684)
cB = chrono.ChVectorD(0.239613811261848,2.51550127212935,-2.65606650221749)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424797,1.09694154801221e-16,0.996593123545252)
link_18.Initialize(body_54,body_50,False,cA,cB,dA,dB)
link_18.SetName("Coincident7")
exported_items.append(link_18)


# Mate constraint: Coincident8 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_49 , SW name: M-410iB-300 -3/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_50 , SW name: M-410iB-300 -3/M-410iB-300-07-1 ,  SW ref.type:2 (2)

link_19 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.965778716625616,3.10515332885273,-2.63993452618763)
cB = chrono.ChVectorD(-0.0736523530408388,3.00995602354016,-2.5539142592573)
dA = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424797,-1.09694154801221e-16,-0.996593123545252)
link_19.Initialize(body_49,body_50,False,cA,cB,dB)
link_19.SetDistance(0)
link_19.SetName("Coincident8")
exported_items.append(link_19)

link_20 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.965778716625616,3.10515332885273,-2.63993452618763)
dA = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
cB = chrono.ChVectorD(-0.0736523530408388,3.00995602354016,-2.5539142592573)
dB = chrono.ChVectorD(-0.0824751241424797,-1.09694154801221e-16,-0.996593123545252)
link_20.Initialize(body_49,body_50,False,cA,cB,dA,dB)
link_20.SetName("Coincident8")
exported_items.append(link_20)


# Mate constraint: Distance5 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_49 , SW name: M-410iB-300 -3/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_60 , SW name: M-410iB-300 -3/M-410iB-300-08-1 ,  SW ref.type:2 (2)

link_21 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.965778716625616,3.10515332885273,-2.63993452618763)
cB = chrono.ChVectorD(-0.0686560854381126,3.01604196029193,-2.57650127823121)
dA = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424794,-3.71122403641788e-16,0.996593123545252)
link_21.Initialize(body_49,body_60,False,cA,cB,dB)
link_21.SetDistance(0)
link_21.SetName("Distance5")
exported_items.append(link_21)

link_22 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.965778716625616,3.10515332885273,-2.63993452618763)
dA = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
cB = chrono.ChVectorD(-0.0686560854381126,3.01604196029193,-2.57650127823121)
dB = chrono.ChVectorD(0.0824751241424794,-3.71122403641788e-16,0.996593123545252)
link_22.SetFlipped(True)
link_22.Initialize(body_49,body_60,False,cA,cB,dA,dB)
link_22.SetName("Distance5")
exported_items.append(link_22)


# Mate constraint: Coincident9 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_49 , SW name: M-410iB-300 -3/M-410iB-300-06-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_60 , SW name: M-410iB-300 -3/M-410iB-300-08-1 ,  SW ref.type:5 (2)

link_23 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.12117568604869,3.25502265002171,-2.65279472363605)
dA = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
cB = chrono.ChVectorD(1.11895512580625,3.25502265002172,-2.67962699689438)
dB = chrono.ChVectorD(-0.0824751241424794,3.71122403641788e-16,-0.996593123545252)
link_23.Initialize(body_49,body_60,False,cA,cB,dA,dB)
link_23.SetName("Coincident9")
exported_items.append(link_23)

link_24 = chrono.ChLinkMateGeneric()
link_24.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.12117568604869,3.25502265002171,-2.65279472363605)
cB = chrono.ChVectorD(1.11895512580625,3.25502265002172,-2.67962699689438)
dA = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424794,3.71122403641788e-16,-0.996593123545252)
link_24.Initialize(body_49,body_60,False,cA,cB,dA,dB)
link_24.SetName("Coincident9")
exported_items.append(link_24)


# Mate constraint: Coincident10 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_57 , SW name: M-410iB-300 -3/M-410iB-300-09-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_49 , SW name: M-410iB-300 -3/M-410iB-300-06-1 ,  SW ref.type:5 (2)

link_25 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.41485957776936,2.75811166841883,-2.95180980754849)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
cB = chrono.ChVectorD(1.42073797253391,2.75811166841885,-2.88077787081854)
dB = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
link_25.Initialize(body_57,body_49,False,cA,cB,dA,dB)
link_25.SetName("Coincident10")
exported_items.append(link_25)

link_26 = chrono.ChLinkMateGeneric()
link_26.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.41485957776936,2.75811166841883,-2.95180980754849)
cB = chrono.ChVectorD(1.42073797253391,2.75811166841885,-2.88077787081854)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
link_26.Initialize(body_57,body_49,False,cA,cB,dA,dB)
link_26.SetName("Coincident10")
exported_items.append(link_26)


# Mate constraint: Coincident11 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_54 , SW name: M-410iB-300 -3/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_57 , SW name: M-410iB-300 -3/M-410iB-300-09-1 ,  SW ref.type:2 (2)

link_27 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.128154728112769,2.72491052060182,-2.81774276125386)
cB = chrono.ChVectorD(1.41507253573638,3.21365467148159,-2.94545572370462)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424791,7.87401827767598e-18,-0.996593123545253)
link_27.Initialize(body_54,body_57,False,cA,cB,dB)
link_27.SetDistance(0)
link_27.SetName("Coincident11")
exported_items.append(link_27)

link_28 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.128154728112769,2.72491052060182,-2.81774276125386)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
cB = chrono.ChVectorD(1.41507253573638,3.21365467148159,-2.94545572370462)
dB = chrono.ChVectorD(-0.0824751241424791,7.87401827767598e-18,-0.996593123545253)
link_28.Initialize(body_54,body_57,False,cA,cB,dA,dB)
link_28.SetName("Coincident11")
exported_items.append(link_28)


# Mate constraint: Coincident12 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_57 , SW name: M-410iB-300 -3/M-410iB-300-09-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_59 , SW name: M-410iB-300 -3/M-410iB-300-10-1 ,  SW ref.type:5 (2)

link_29 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.916474724406251,3.03081076163703,-2.89782152348282)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
cB = chrono.ChVectorD(0.912163419766755,3.03081076163705,-2.94991743242302)
dB = chrono.ChVectorD(0.0824751241424785,-3.85108611666851e-16,0.996593123545252)
link_29.Initialize(body_57,body_59,False,cA,cB,dA,dB)
link_29.SetName("Coincident12")
exported_items.append(link_29)

link_30 = chrono.ChLinkMateGeneric()
link_30.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.916474724406251,3.03081076163703,-2.89782152348282)
cB = chrono.ChVectorD(0.912163419766755,3.03081076163705,-2.94991743242302)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424785,-3.85108611666851e-16,0.996593123545252)
link_30.Initialize(body_57,body_59,False,cA,cB,dA,dB)
link_30.SetName("Coincident12")
exported_items.append(link_30)


# Mate constraint: Distance7 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_57 , SW name: M-410iB-300 -3/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_59 , SW name: M-410iB-300 -3/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_31 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.41507253573638,3.21365467148159,-2.94545572370462)
cB = chrono.ChVectorD(0.915699623189488,3.03081076163705,-2.90718750565789)
dA = chrono.ChVectorD(-0.0824751241424791,7.87401827767598e-18,-0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424785,-3.85108611666851e-16,0.996593123545252)
link_31.Initialize(body_57,body_59,False,cA,cB,dB)
link_31.SetDistance(0)
link_31.SetName("Distance7")
exported_items.append(link_31)

link_32 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.41507253573638,3.21365467148159,-2.94545572370462)
dA = chrono.ChVectorD(-0.0824751241424791,7.87401827767598e-18,-0.996593123545253)
cB = chrono.ChVectorD(0.915699623189488,3.03081076163705,-2.90718750565789)
dB = chrono.ChVectorD(0.0824751241424785,-3.85108611666851e-16,0.996593123545252)
link_32.SetFlipped(True)
link_32.Initialize(body_57,body_59,False,cA,cB,dA,dB)
link_32.SetName("Distance7")
exported_items.append(link_32)


# Mate constraint: Coincident13 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_54 , SW name: M-410iB-300 -3/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_59 , SW name: M-410iB-300 -3/M-410iB-300-10-1 ,  SW ref.type:5 (2)

link_33 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.275466317544226,2.78749692402101,-2.80555168614112)
dA = chrono.ChVectorD(0.0824751241424792,1.35945749492389e-19,0.996593123545252)
cB = chrono.ChVectorD(-0.276115726671739,2.78749692402101,-2.81339886039591)
dB = chrono.ChVectorD(-0.0824751241424785,3.85108611666851e-16,-0.996593123545252)
link_33.SetFlipped(True)
link_33.Initialize(body_54,body_59,False,cA,cB,dA,dB)
link_33.SetName("Coincident13")
exported_items.append(link_33)

link_34 = chrono.ChLinkMateGeneric()
link_34.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-0.275466317544226,2.78749692402101,-2.80555168614112)
cB = chrono.ChVectorD(-0.276115726671739,2.78749692402101,-2.81339886039591)
dA = chrono.ChVectorD(0.0824751241424792,1.35945749492389e-19,0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424785,3.85108611666851e-16,-0.996593123545252)
link_34.Initialize(body_54,body_59,False,cA,cB,dA,dB)
link_34.SetName("Coincident13")
exported_items.append(link_34)


# Mate constraint: Coincident14 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_57 , SW name: M-410iB-300 -3/M-410iB-300-09-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_58 , SW name: M-410iB-300 -3/M-410iB-300-11-1 ,  SW ref.type:5 (2)

link_35 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.91445573042203,3.02764258400498,-2.98041150470824)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
cB = chrono.ChVectorD(1.9229399464425,3.02764258400503,-2.87789197008914)
dB = chrono.ChVectorD(-0.0824751241424787,1.20736753927986e-15,-0.996593123545252)
link_35.SetFlipped(True)
link_35.Initialize(body_57,body_58,False,cA,cB,dA,dB)
link_35.SetName("Coincident14")
exported_items.append(link_35)

link_36 = chrono.ChLinkMateGeneric()
link_36.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.91445573042203,3.02764258400498,-2.98041150470824)
cB = chrono.ChVectorD(1.9229399464425,3.02764258400503,-2.87789197008914)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424787,1.20736753927986e-15,-0.996593123545252)
link_36.Initialize(body_57,body_58,False,cA,cB,dA,dB)
link_36.SetName("Coincident14")
exported_items.append(link_36)


# Mate constraint: Distance8 [MateDistanceDim] type:5 align:1 flip:True
#   Entity 0: C::E name: body_57 , SW name: M-410iB-300 -3/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_58 , SW name: M-410iB-300 -3/M-410iB-300-11-1 ,  SW ref.type:2 (2)

link_37 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.41903183654596,3.21365467148159,-2.8976132742157)
cB = chrono.ChVectorD(1.91776562210405,3.02764258400503,-2.94041622947412)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424787,1.20736753927986e-15,-0.996593123545253)
link_37.Initialize(body_57,body_58,False,cA,cB,dB)
link_37.SetDistance(0)
link_37.SetName("Distance8")
exported_items.append(link_37)

link_38 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.41903183654596,3.21365467148159,-2.8976132742157)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
cB = chrono.ChVectorD(1.91776562210405,3.02764258400503,-2.94041622947412)
dB = chrono.ChVectorD(-0.0824751241424787,1.20736753927986e-15,-0.996593123545253)
link_38.SetFlipped(True)
link_38.Initialize(body_57,body_58,False,cA,cB,dA,dB)
link_38.SetName("Distance8")
exported_items.append(link_38)


# Mate constraint: Coincident15 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_49 , SW name: M-410iB-300 -3/M-410iB-300-06-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_52 , SW name: M-410iB-300 -3/M-410iB-300-12-1 ,  SW ref.type:5 (2)

link_39 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(2.17391479491138,1.6937690405165,-2.83022399186209)
dA = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
cB = chrono.ChVectorD(2.17288698991433,1.69376904051648,-2.84264353536771)
dB = chrono.ChVectorD(-0.082475124142479,9.74593356253719e-16,-0.996593123545253)
link_39.SetFlipped(True)
link_39.Initialize(body_49,body_52,False,cA,cB,dA,dB)
link_39.SetName("Coincident15")
exported_items.append(link_39)

link_40 = chrono.ChLinkMateGeneric()
link_40.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(2.17391479491138,1.6937690405165,-2.83022399186209)
cB = chrono.ChVectorD(2.17288698991433,1.69376904051648,-2.84264353536771)
dA = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
dB = chrono.ChVectorD(-0.082475124142479,9.74593356253719e-16,-0.996593123545253)
link_40.Initialize(body_49,body_52,False,cA,cB,dA,dB)
link_40.SetName("Coincident15")
exported_items.append(link_40)


# Mate constraint: Distance9 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_49 , SW name: M-410iB-300 -3/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_52 , SW name: M-410iB-300 -3/M-410iB-300-12-1 ,  SW ref.type:2 (2)

link_41 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.54693693736679,2.27955349819168,-2.63785854993169)
cB = chrono.ChVectorD(2.18650874636795,1.69376904051648,-2.67804422189673)
dA = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
dB = chrono.ChVectorD(-0.082475124142479,9.74593356253719e-16,-0.996593123545253)
link_41.Initialize(body_49,body_52,False,cA,cB,dB)
link_41.SetDistance(0)
link_41.SetName("Distance9")
exported_items.append(link_41)

link_42 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.54693693736679,2.27955349819168,-2.63785854993169)
dA = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
cB = chrono.ChVectorD(2.18650874636795,1.69376904051648,-2.67804422189673)
dB = chrono.ChVectorD(-0.082475124142479,9.74593356253719e-16,-0.996593123545253)
link_42.SetFlipped(True)
link_42.Initialize(body_49,body_52,False,cA,cB,dA,dB)
link_42.SetName("Distance9")
exported_items.append(link_42)


# Mate constraint: Coincident16 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_58 , SW name: M-410iB-300 -3/M-410iB-300-11-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_52 , SW name: M-410iB-300 -3/M-410iB-300-12-1 ,  SW ref.type:5 (2)

link_43 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(2.66683833509355,1.96329996858997,-2.93945481906318)
dA = chrono.ChVectorD(-0.0824751241424787,1.20736753927986e-15,-0.996593123545252)
cB = chrono.ChVectorD(2.67143572623523,1.96329996858993,-2.883901966665)
dB = chrono.ChVectorD(-0.082475124142479,9.74593356253719e-16,-0.996593123545253)
link_43.Initialize(body_58,body_52,False,cA,cB,dA,dB)
link_43.SetName("Coincident16")
exported_items.append(link_43)

link_44 = chrono.ChLinkMateGeneric()
link_44.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(2.66683833509355,1.96329996858997,-2.93945481906318)
cB = chrono.ChVectorD(2.67143572623523,1.96329996858993,-2.883901966665)
dA = chrono.ChVectorD(-0.0824751241424787,1.20736753927986e-15,-0.996593123545252)
dB = chrono.ChVectorD(-0.082475124142479,9.74593356253719e-16,-0.996593123545253)
link_44.Initialize(body_58,body_52,False,cA,cB,dA,dB)
link_44.SetName("Coincident16")
exported_items.append(link_44)


# Mate constraint: Coincident17 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_50 , SW name: M-410iB-300 -3/M-410iB-300-07-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_60 , SW name: M-410iB-300 -3/M-410iB-300-08-1 ,  SW ref.type:5 (2)

link_45 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.0809607212164763,3.00995602354016,-2.64222536571402)
dA = chrono.ChVectorD(0.0824751241424797,1.09694154801221e-16,0.996593123545252)
cB = chrono.ChVectorD(-0.0758729132832685,3.00995602354016,-2.58074653251563)
dB = chrono.ChVectorD(-0.0824751241424794,3.71122403641788e-16,-0.996593123545252)
link_45.SetFlipped(True)
link_45.Initialize(body_50,body_60,False,cA,cB,dA,dB)
link_45.SetName("Coincident17")
exported_items.append(link_45)

link_46 = chrono.ChLinkMateGeneric()
link_46.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-0.0809607212164763,3.00995602354016,-2.64222536571402)
cB = chrono.ChVectorD(-0.0758729132832685,3.00995602354016,-2.58074653251563)
dA = chrono.ChVectorD(0.0824751241424797,1.09694154801221e-16,0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424794,3.71122403641788e-16,-0.996593123545252)
link_46.Initialize(body_50,body_60,False,cA,cB,dA,dB)
link_46.SetName("Coincident17")
exported_items.append(link_46)


# Mate constraint: Coincident18 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_54 , SW name: M-410iB-300 -3/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_53 , SW name: M-410iB-300 -3/ArmBase-1 ,  SW ref.type:2 (2)

link_47 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.140670357955037,2.04602671615662,-2.52259688656261)
cB = chrono.ChVectorD(-0.382669423498731,2.04602671615662,-2.52259688656261)
dA = chrono.ChVectorD(-1.32297045065857e-16,-1,1.10849259381635e-17)
dB = chrono.ChVectorD(0,1,0)
link_47.Initialize(body_54,body_53,False,cA,cB,dB)
link_47.SetDistance(0)
link_47.SetName("Coincident18")
exported_items.append(link_47)

link_48 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.140670357955037,2.04602671615662,-2.52259688656261)
dA = chrono.ChVectorD(-1.32297045065857e-16,-1,1.10849259381635e-17)
cB = chrono.ChVectorD(-0.382669423498731,2.04602671615662,-2.52259688656261)
dB = chrono.ChVectorD(0,1,0)
link_48.SetFlipped(True)
link_48.Initialize(body_54,body_53,False,cA,cB,dA,dB)
link_48.SetName("Coincident18")
exported_items.append(link_48)


# Mate constraint: Concentric1 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_54 , SW name: M-410iB-300 -3/M-410iB-300-02-1 ,  SW ref.type:1 (1)
#   Entity 1: C::E name: body_53 , SW name: M-410iB-300 -3/ArmBase-1 ,  SW ref.type:1 (1)

link_49 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.140670357955037,2.04755071615662,-2.52259688656261)
dA = chrono.ChVectorD(1.32297045065857e-16,1,-1.10849259381635e-17)
cB = chrono.ChVectorD(-0.140670357955037,2.04602671615662,-2.52259688656261)
dB = chrono.ChVectorD(0,1,0)
link_49.Initialize(body_54,body_53,False,cA,cB,dA,dB)
link_49.SetName("Concentric1")
exported_items.append(link_49)

link_50 = chrono.ChLinkMateGeneric()
link_50.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-0.140670357955037,2.04755071615662,-2.52259688656261)
cB = chrono.ChVectorD(-0.140670357955037,2.04602671615662,-2.52259688656261)
dA = chrono.ChVectorD(1.32297045065857e-16,1,-1.10849259381635e-17)
dB = chrono.ChVectorD(0,1,0)
link_50.Initialize(body_54,body_53,False,cA,cB,dA,dB)
link_50.SetName("Concentric1")
exported_items.append(link_50)


# Mate constraint: Coincident2_hinge [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_63 , SW name: M-410iB-300 -1/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_64 , SW name: M-410iB-300 -1/M-410iB-300-03-1 ,  SW ref.type:5 (2)

link_1 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.237440667378504,2.51550127212935,0.217674182950967)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
cB = chrono.ChVectorD(0.256663804363386,2.51550127212935,0.449958115000638)
dB = chrono.ChVectorD(-0.0824751241424792,9.11814027060309e-17,-0.996593123545252)
link_1.Initialize(body_63,body_64,False,cA,cB,dA,dB)
link_1.SetName("Coincident2_hinge")
exported_items.append(link_1)

link_2 = chrono.ChLinkMateGeneric()
link_2.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.237440667378504,2.51550127212935,0.217674182950967)
cB = chrono.ChVectorD(0.256663804363386,2.51550127212935,0.449958115000638)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424792,9.11814027060309e-17,-0.996593123545252)
link_2.Initialize(body_63,body_64,False,cA,cB,dA,dB)
link_2.SetName("Coincident2_hinge")
exported_items.append(link_2)


# Mate constraint: Distance2 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_63 , SW name: M-410iB-300 -1/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_64 , SW name: M-410iB-300 -1/M-410iB-300-03-1 ,  SW ref.type:2 (2)

link_3 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.468847901417992,2.84164228947283,0.443357718519636)
cB = chrono.ChVectorD(1.09486376832202,2.54318522667954,0.388492061667059)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424792,-9.11814027060309e-17,0.996593123545252)
link_3.Initialize(body_63,body_64,False,cA,cB,dB)
link_3.SetDistance(0)
link_3.SetName("Distance2")
exported_items.append(link_3)

link_4 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.468847901417992,2.84164228947283,0.443357718519636)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
cB = chrono.ChVectorD(1.09486376832202,2.54318522667954,0.388492061667059)
dB = chrono.ChVectorD(0.0824751241424792,-9.11814027060309e-17,0.996593123545252)
link_4.SetFlipped(True)
link_4.Initialize(body_63,body_64,False,cA,cB,dA,dB)
link_4.SetName("Distance2")
exported_items.append(link_4)


# Mate constraint: Coincident3 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_63 , SW name: M-410iB-300 -1/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_68 , SW name: M-410iB-300 -1/M-410iB-300-04-1 ,  SW ref.type:5 (2)

link_5 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.260985806741079,2.78049690546384,0.502140937748153)
dA = chrono.ChVectorD(0.0824751241424792,1.35945749492389e-19,0.996593123545252)
cB = chrono.ChVectorD(0.266759107195717,2.78049690546384,0.571902961062149)
dB = chrono.ChVectorD(0.0824751241424787,-6.19079440489223e-17,0.996593123545253)
link_5.Initialize(body_63,body_68,False,cA,cB,dA,dB)
link_5.SetName("Coincident3")
exported_items.append(link_5)

link_6 = chrono.ChLinkMateGeneric()
link_6.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.260985806741079,2.78049690546384,0.502140937748153)
cB = chrono.ChVectorD(0.266759107195717,2.78049690546384,0.571902961062149)
dA = chrono.ChVectorD(0.0824751241424792,1.35945749492389e-19,0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424787,-6.19079440489223e-17,0.996593123545253)
link_6.Initialize(body_63,body_68,False,cA,cB,dA,dB)
link_6.SetName("Coincident3")
exported_items.append(link_6)


# Mate constraint: Distance3 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_63 , SW name: M-410iB-300 -1/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_68 , SW name: M-410iB-300 -1/M-410iB-300-04-1 ,  SW ref.type:2 (2)

link_7 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.264664235980002,2.78049691677857,0.546589495977547)
cB = chrono.ChVectorD(0.336053492470982,2.80967719196081,0.56616836096013)
dA = chrono.ChVectorD(0.0824751241424792,1.35945749492389e-19,0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424787,6.19079440489223e-17,-0.996593123545253)
link_7.Initialize(body_63,body_68,False,cA,cB,dB)
link_7.SetDistance(0)
link_7.SetName("Distance3")
exported_items.append(link_7)

link_8 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.264664235980002,2.78049691677857,0.546589495977547)
dA = chrono.ChVectorD(0.0824751241424792,1.35945749492389e-19,0.996593123545252)
cB = chrono.ChVectorD(0.336053492470982,2.80967719196081,0.56616836096013)
dB = chrono.ChVectorD(-0.0824751241424787,6.19079440489223e-17,-0.996593123545253)
link_8.SetFlipped(True)
link_8.Initialize(body_63,body_68,False,cA,cB,dA,dB)
link_8.SetName("Distance3")
exported_items.append(link_8)


# Mate constraint: Coincident4 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_68 , SW name: M-410iB-300 -1/M-410iB-300-04-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_67 , SW name: M-410iB-300 -1/M-410iB-300-05-1 ,  SW ref.type:5 (2)

link_9 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.07009216653166,2.7654491237564,0.533966723190072)
dA = chrono.ChVectorD(-0.996418499736232,0.0187192635196773,0.0824606727881728)
cB = chrono.ChVectorD(1.35881310090398,2.76002505419567,0.510073025408795)
dB = chrono.ChVectorD(-0.996418499736232,0.0187192635196774,0.0824606727881729)
link_9.Initialize(body_68,body_67,False,cA,cB,dA,dB)
link_9.SetName("Coincident4")
exported_items.append(link_9)

link_10 = chrono.ChLinkMateGeneric()
link_10.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.07009216653166,2.7654491237564,0.533966723190072)
cB = chrono.ChVectorD(1.35881310090398,2.76002505419567,0.510073025408795)
dA = chrono.ChVectorD(-0.996418499736232,0.0187192635196773,0.0824606727881728)
dB = chrono.ChVectorD(-0.996418499736232,0.0187192635196774,0.0824606727881729)
link_10.Initialize(body_68,body_67,False,cA,cB,dA,dB)
link_10.SetName("Coincident4")
exported_items.append(link_10)


# Mate constraint: Coincident5 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_64 , SW name: M-410iB-300 -1/M-410iB-300-03-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_67 , SW name: M-410iB-300 -1/M-410iB-300-05-1 ,  SW ref.type:5 (2)

link_11 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.44822374457179,2.75811166841886,0.35134810890076)
dA = chrono.ChVectorD(-0.0824751241424792,9.11814027060309e-17,-0.996593123545252)
cB = chrono.ChVectorD(1.45777518922983,2.75811166841886,0.466763564956043)
dB = chrono.ChVectorD(-0.0824751241424788,-1.81929124543068e-16,-0.996593123545253)
link_11.Initialize(body_64,body_67,False,cA,cB,dA,dB)
link_11.SetName("Coincident5")
exported_items.append(link_11)

link_12 = chrono.ChLinkMateGeneric()
link_12.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.44822374457179,2.75811166841886,0.35134810890076)
cB = chrono.ChVectorD(1.45777518922983,2.75811166841886,0.466763564956043)
dA = chrono.ChVectorD(-0.0824751241424792,9.11814027060309e-17,-0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424788,-1.81929124543068e-16,-0.996593123545253)
link_12.Initialize(body_64,body_67,False,cA,cB,dA,dB)
link_12.SetName("Coincident5")
exported_items.append(link_12)


# Mate constraint: Coincident6 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_64 , SW name: M-410iB-300 -1/M-410iB-300-03-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_73 , SW name: M-410iB-300 -1/M-410iB-300-06-1 ,  SW ref.type:5 (2)

link_13 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.42574833632556,2.75811166841886,0.0797651614368333)
dA = chrono.ChVectorD(-0.0824751241424792,9.11814027060309e-17,-0.996593123545252)
cB = chrono.ChVectorD(1.42836692151708,2.75811166841885,0.111406993109395)
dB = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
link_13.SetFlipped(True)
link_13.Initialize(body_64,body_73,False,cA,cB,dA,dB)
link_13.SetName("Coincident6")
exported_items.append(link_13)

link_14 = chrono.ChLinkMateGeneric()
link_14.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.42574833632556,2.75811166841886,0.0797651614368333)
cB = chrono.ChVectorD(1.42836692151708,2.75811166841885,0.111406993109395)
dA = chrono.ChVectorD(-0.0824751241424792,9.11814027060309e-17,-0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
link_14.Initialize(body_64,body_73,False,cA,cB,dA,dB)
link_14.SetName("Coincident6")
exported_items.append(link_14)


# Mate constraint: Distance4 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_64 , SW name: M-410iB-300 -1/M-410iB-300-03-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_73 , SW name: M-410iB-300 -1/M-410iB-300-06-1 ,  SW ref.type:2 (2)

link_15 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.24088928761079,2.91434507456169,0.0950635541624166)
cB = chrono.ChVectorD(1.32186931481946,2.58269164685799,0.120220422708444)
dA = chrono.ChVectorD(0.0824751241424792,-9.11814027060309e-17,0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
link_15.Initialize(body_64,body_73,False,cA,cB,dB)
link_15.SetDistance(0)
link_15.SetName("Distance4")
exported_items.append(link_15)

link_16 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.24088928761079,2.91434507456169,0.0950635541624166)
dA = chrono.ChVectorD(0.0824751241424792,-9.11814027060309e-17,0.996593123545252)
cB = chrono.ChVectorD(1.32186931481946,2.58269164685799,0.120220422708444)
dB = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
link_16.SetFlipped(True)
link_16.Initialize(body_64,body_73,False,cA,cB,dA,dB)
link_16.SetName("Distance4")
exported_items.append(link_16)


# Mate constraint: Coincident7 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_63 , SW name: M-410iB-300 -1/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_72 , SW name: M-410iB-300 -1/M-410iB-300-07-1 ,  SW ref.type:5 (2)

link_17 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.264245082724809,2.51550127212935,0.541566948103163)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
cB = chrono.ChVectorD(0.239613811261849,2.51550127212935,0.243933497782506)
dB = chrono.ChVectorD(0.0824751241424797,1.09694154801221e-16,0.996593123545252)
link_17.SetFlipped(True)
link_17.Initialize(body_63,body_72,False,cA,cB,dA,dB)
link_17.SetName("Coincident7")
exported_items.append(link_17)

link_18 = chrono.ChLinkMateGeneric()
link_18.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.264245082724809,2.51550127212935,0.541566948103163)
cB = chrono.ChVectorD(0.239613811261849,2.51550127212935,0.243933497782506)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
dB = chrono.ChVectorD(0.0824751241424797,1.09694154801221e-16,0.996593123545252)
link_18.Initialize(body_63,body_72,False,cA,cB,dA,dB)
link_18.SetName("Coincident7")
exported_items.append(link_18)


# Mate constraint: Coincident8 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_73 , SW name: M-410iB-300 -1/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_72 , SW name: M-410iB-300 -1/M-410iB-300-07-1 ,  SW ref.type:2 (2)

link_19 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.965778716625616,3.10515332885273,0.260065473812372)
cB = chrono.ChVectorD(-0.0736523530408381,3.00995602354016,0.346085740742698)
dA = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424797,-1.09694154801221e-16,-0.996593123545252)
link_19.Initialize(body_73,body_72,False,cA,cB,dB)
link_19.SetDistance(0)
link_19.SetName("Coincident8")
exported_items.append(link_19)

link_20 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.965778716625616,3.10515332885273,0.260065473812372)
dA = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
cB = chrono.ChVectorD(-0.0736523530408381,3.00995602354016,0.346085740742698)
dB = chrono.ChVectorD(-0.0824751241424797,-1.09694154801221e-16,-0.996593123545252)
link_20.Initialize(body_73,body_72,False,cA,cB,dA,dB)
link_20.SetName("Coincident8")
exported_items.append(link_20)


# Mate constraint: Distance5 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_73 , SW name: M-410iB-300 -1/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_70 , SW name: M-410iB-300 -1/M-410iB-300-08-1 ,  SW ref.type:2 (2)

link_21 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(0.965778716625616,3.10515332885273,0.260065473812372)
cB = chrono.ChVectorD(-0.0686560854381114,3.01604196029193,0.323498721768789)
dA = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424794,-3.71122403641788e-16,0.996593123545252)
link_21.Initialize(body_73,body_70,False,cA,cB,dB)
link_21.SetDistance(0)
link_21.SetName("Distance5")
exported_items.append(link_21)

link_22 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.965778716625616,3.10515332885273,0.260065473812372)
dA = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
cB = chrono.ChVectorD(-0.0686560854381114,3.01604196029193,0.323498721768789)
dB = chrono.ChVectorD(0.0824751241424794,-3.71122403641788e-16,0.996593123545252)
link_22.SetFlipped(True)
link_22.Initialize(body_73,body_70,False,cA,cB,dA,dB)
link_22.SetName("Distance5")
exported_items.append(link_22)


# Mate constraint: Coincident9 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_73 , SW name: M-410iB-300 -1/M-410iB-300-06-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_70 , SW name: M-410iB-300 -1/M-410iB-300-08-1 ,  SW ref.type:5 (2)

link_23 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.12117568604869,3.25502265002171,0.247205276363948)
dA = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
cB = chrono.ChVectorD(1.11895512580625,3.25502265002172,0.220373003105618)
dB = chrono.ChVectorD(-0.0824751241424794,3.71122403641788e-16,-0.996593123545252)
link_23.Initialize(body_73,body_70,False,cA,cB,dA,dB)
link_23.SetName("Coincident9")
exported_items.append(link_23)

link_24 = chrono.ChLinkMateGeneric()
link_24.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.12117568604869,3.25502265002171,0.247205276363948)
cB = chrono.ChVectorD(1.11895512580625,3.25502265002172,0.220373003105618)
dA = chrono.ChVectorD(-0.0824751241424786,9.85892140495381e-16,-0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424794,3.71122403641788e-16,-0.996593123545252)
link_24.Initialize(body_73,body_70,False,cA,cB,dA,dB)
link_24.SetName("Coincident9")
exported_items.append(link_24)


# Mate constraint: Coincident10 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_71 , SW name: M-410iB-300 -1/M-410iB-300-09-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_73 , SW name: M-410iB-300 -1/M-410iB-300-06-1 ,  SW ref.type:5 (2)

link_25 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.41485957776935,2.75811166841883,-0.0518098075484903)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
cB = chrono.ChVectorD(1.4207379725339,2.75811166841885,0.0192221291814594)
dB = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
link_25.Initialize(body_71,body_73,False,cA,cB,dA,dB)
link_25.SetName("Coincident10")
exported_items.append(link_25)

link_26 = chrono.ChLinkMateGeneric()
link_26.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.41485957776935,2.75811166841883,-0.0518098075484903)
cB = chrono.ChVectorD(1.4207379725339,2.75811166841885,0.0192221291814594)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
link_26.Initialize(body_71,body_73,False,cA,cB,dA,dB)
link_26.SetName("Coincident10")
exported_items.append(link_26)


# Mate constraint: Coincident11 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_63 , SW name: M-410iB-300 -1/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_71 , SW name: M-410iB-300 -1/M-410iB-300-09-1 ,  SW ref.type:2 (2)

link_27 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.128154728112769,2.72491052060182,0.0822572387461377)
cB = chrono.ChVectorD(1.41507253573637,3.21365467148159,-0.0454557237046183)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424791,7.87401827767598e-18,-0.996593123545253)
link_27.Initialize(body_63,body_71,False,cA,cB,dB)
link_27.SetDistance(0)
link_27.SetName("Coincident11")
exported_items.append(link_27)

link_28 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.128154728112769,2.72491052060182,0.0822572387461377)
dA = chrono.ChVectorD(-0.0824751241424792,-1.35945749492389e-19,-0.996593123545252)
cB = chrono.ChVectorD(1.41507253573637,3.21365467148159,-0.0454557237046183)
dB = chrono.ChVectorD(-0.0824751241424791,7.87401827767598e-18,-0.996593123545253)
link_28.Initialize(body_63,body_71,False,cA,cB,dA,dB)
link_28.SetName("Coincident11")
exported_items.append(link_28)


# Mate constraint: Coincident12 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_71 , SW name: M-410iB-300 -1/M-410iB-300-09-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_69 , SW name: M-410iB-300 -1/M-410iB-300-10-1 ,  SW ref.type:5 (2)

link_29 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(0.916474724406249,3.03081076163703,0.00217847651717851)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
cB = chrono.ChVectorD(0.912163419766748,3.03081076163706,-0.0499174324230198)
dB = chrono.ChVectorD(0.0824751241424785,-3.85108611666851e-16,0.996593123545252)
link_29.Initialize(body_71,body_69,False,cA,cB,dA,dB)
link_29.SetName("Coincident12")
exported_items.append(link_29)

link_30 = chrono.ChLinkMateGeneric()
link_30.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(0.916474724406249,3.03081076163703,0.00217847651717851)
cB = chrono.ChVectorD(0.912163419766748,3.03081076163706,-0.0499174324230198)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424785,-3.85108611666851e-16,0.996593123545252)
link_30.Initialize(body_71,body_69,False,cA,cB,dA,dB)
link_30.SetName("Coincident12")
exported_items.append(link_30)


# Mate constraint: Distance7 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_71 , SW name: M-410iB-300 -1/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_69 , SW name: M-410iB-300 -1/M-410iB-300-10-1 ,  SW ref.type:2 (2)

link_31 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.41507253573637,3.21365467148159,-0.0454557237046183)
cB = chrono.ChVectorD(0.915699623189481,3.03081076163706,-0.00718750565789344)
dA = chrono.ChVectorD(-0.0824751241424791,7.87401827767598e-18,-0.996593123545253)
dB = chrono.ChVectorD(0.0824751241424785,-3.85108611666851e-16,0.996593123545252)
link_31.Initialize(body_71,body_69,False,cA,cB,dB)
link_31.SetDistance(0)
link_31.SetName("Distance7")
exported_items.append(link_31)

link_32 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.41507253573637,3.21365467148159,-0.0454557237046183)
dA = chrono.ChVectorD(-0.0824751241424791,7.87401827767598e-18,-0.996593123545253)
cB = chrono.ChVectorD(0.915699623189481,3.03081076163706,-0.00718750565789344)
dB = chrono.ChVectorD(0.0824751241424785,-3.85108611666851e-16,0.996593123545252)
link_32.SetFlipped(True)
link_32.Initialize(body_71,body_69,False,cA,cB,dA,dB)
link_32.SetName("Distance7")
exported_items.append(link_32)


# Mate constraint: Coincident13 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_63 , SW name: M-410iB-300 -1/M-410iB-300-02-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_69 , SW name: M-410iB-300 -1/M-410iB-300-10-1 ,  SW ref.type:5 (2)

link_33 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.275466317544227,2.78749692402101,0.0944483138588827)
dA = chrono.ChVectorD(0.0824751241424792,1.35945749492389e-19,0.996593123545252)
cB = chrono.ChVectorD(-0.276115726671746,2.78749692402101,0.0866011396040883)
dB = chrono.ChVectorD(-0.0824751241424785,3.85108611666851e-16,-0.996593123545252)
link_33.SetFlipped(True)
link_33.Initialize(body_63,body_69,False,cA,cB,dA,dB)
link_33.SetName("Coincident13")
exported_items.append(link_33)

link_34 = chrono.ChLinkMateGeneric()
link_34.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-0.275466317544227,2.78749692402101,0.0944483138588827)
cB = chrono.ChVectorD(-0.276115726671746,2.78749692402101,0.0866011396040883)
dA = chrono.ChVectorD(0.0824751241424792,1.35945749492389e-19,0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424785,3.85108611666851e-16,-0.996593123545252)
link_34.Initialize(body_63,body_69,False,cA,cB,dA,dB)
link_34.SetName("Coincident13")
exported_items.append(link_34)


# Mate constraint: Coincident14 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_71 , SW name: M-410iB-300 -1/M-410iB-300-09-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_66 , SW name: M-410iB-300 -1/M-410iB-300-11-1 ,  SW ref.type:5 (2)

link_35 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.91445573042203,3.02764258400498,-0.0804115047082443)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
cB = chrono.ChVectorD(1.9229399464425,3.02764258400502,0.0221080299108611)
dB = chrono.ChVectorD(-0.0824751241424787,1.20736753927986e-15,-0.996593123545252)
link_35.SetFlipped(True)
link_35.Initialize(body_71,body_66,False,cA,cB,dA,dB)
link_35.SetName("Coincident14")
exported_items.append(link_35)

link_36 = chrono.ChLinkMateGeneric()
link_36.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(1.91445573042203,3.02764258400498,-0.0804115047082443)
cB = chrono.ChVectorD(1.9229399464425,3.02764258400502,0.0221080299108611)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424787,1.20736753927986e-15,-0.996593123545252)
link_36.Initialize(body_71,body_66,False,cA,cB,dA,dB)
link_36.SetName("Coincident14")
exported_items.append(link_36)


# Mate constraint: Distance8 [MateDistanceDim] type:5 align:1 flip:True
#   Entity 0: C::E name: body_71 , SW name: M-410iB-300 -1/M-410iB-300-09-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_66 , SW name: M-410iB-300 -1/M-410iB-300-11-1 ,  SW ref.type:2 (2)

link_37 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.41903183654596,3.21365467148159,0.00238672578429505)
cB = chrono.ChVectorD(1.91776562210405,3.02764258400502,-0.0404162294741209)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
dB = chrono.ChVectorD(-0.0824751241424787,1.20736753927986e-15,-0.996593123545253)
link_37.Initialize(body_71,body_66,False,cA,cB,dB)
link_37.SetDistance(0)
link_37.SetName("Distance8")
exported_items.append(link_37)

link_38 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.41903183654596,3.21365467148159,0.00238672578429505)
dA = chrono.ChVectorD(0.0824751241424791,-7.87401827767598e-18,0.996593123545253)
cB = chrono.ChVectorD(1.91776562210405,3.02764258400502,-0.0404162294741209)
dB = chrono.ChVectorD(-0.0824751241424787,1.20736753927986e-15,-0.996593123545253)
link_38.SetFlipped(True)
link_38.Initialize(body_71,body_66,False,cA,cB,dA,dB)
link_38.SetName("Distance8")
exported_items.append(link_38)


# Mate constraint: Coincident15 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_73 , SW name: M-410iB-300 -1/M-410iB-300-06-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_62 , SW name: M-410iB-300 -1/M-410iB-300-12-1 ,  SW ref.type:5 (2)

link_39 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(2.17391479491138,1.6937690405165,0.0697760081379131)
dA = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
cB = chrono.ChVectorD(2.17288698991433,1.69376904051648,0.057356464632293)
dB = chrono.ChVectorD(-0.082475124142479,9.74593356253719e-16,-0.996593123545253)
link_39.SetFlipped(True)
link_39.Initialize(body_73,body_62,False,cA,cB,dA,dB)
link_39.SetName("Coincident15")
exported_items.append(link_39)

link_40 = chrono.ChLinkMateGeneric()
link_40.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(2.17391479491138,1.6937690405165,0.0697760081379131)
cB = chrono.ChVectorD(2.17288698991433,1.69376904051648,0.057356464632293)
dA = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
dB = chrono.ChVectorD(-0.082475124142479,9.74593356253719e-16,-0.996593123545253)
link_40.Initialize(body_73,body_62,False,cA,cB,dA,dB)
link_40.SetName("Coincident15")
exported_items.append(link_40)


# Mate constraint: Distance9 [MateDistanceDim] type:5 align:1 flip:False
#   Entity 0: C::E name: body_73 , SW name: M-410iB-300 -1/M-410iB-300-06-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_62 , SW name: M-410iB-300 -1/M-410iB-300-12-1 ,  SW ref.type:2 (2)

link_41 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(1.54693693736679,2.27955349819168,0.262141450068309)
cB = chrono.ChVectorD(2.18650874636795,1.69376904051648,0.221955778103273)
dA = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
dB = chrono.ChVectorD(-0.082475124142479,9.74593356253719e-16,-0.996593123545253)
link_41.Initialize(body_73,body_62,False,cA,cB,dB)
link_41.SetDistance(0)
link_41.SetName("Distance9")
exported_items.append(link_41)

link_42 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(1.54693693736679,2.27955349819168,0.262141450068309)
dA = chrono.ChVectorD(0.0824751241424786,-9.85892140495381e-16,0.996593123545253)
cB = chrono.ChVectorD(2.18650874636795,1.69376904051648,0.221955778103273)
dB = chrono.ChVectorD(-0.082475124142479,9.74593356253719e-16,-0.996593123545253)
link_42.SetFlipped(True)
link_42.Initialize(body_73,body_62,False,cA,cB,dA,dB)
link_42.SetName("Distance9")
exported_items.append(link_42)


# Mate constraint: Coincident16 [MateCoincident] type:0 align:0 flip:False
#   Entity 0: C::E name: body_66 , SW name: M-410iB-300 -1/M-410iB-300-11-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_62 , SW name: M-410iB-300 -1/M-410iB-300-12-1 ,  SW ref.type:5 (2)

link_43 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(2.66683833509356,1.96329996858996,-0.0394548190631827)
dA = chrono.ChVectorD(-0.0824751241424787,1.20736753927986e-15,-0.996593123545252)
cB = chrono.ChVectorD(2.67143572623523,1.96329996858993,0.0160980333350047)
dB = chrono.ChVectorD(-0.082475124142479,9.74593356253719e-16,-0.996593123545253)
link_43.Initialize(body_66,body_62,False,cA,cB,dA,dB)
link_43.SetName("Coincident16")
exported_items.append(link_43)

link_44 = chrono.ChLinkMateGeneric()
link_44.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(2.66683833509356,1.96329996858996,-0.0394548190631827)
cB = chrono.ChVectorD(2.67143572623523,1.96329996858993,0.0160980333350047)
dA = chrono.ChVectorD(-0.0824751241424787,1.20736753927986e-15,-0.996593123545252)
dB = chrono.ChVectorD(-0.082475124142479,9.74593356253719e-16,-0.996593123545253)
link_44.Initialize(body_66,body_62,False,cA,cB,dA,dB)
link_44.SetName("Coincident16")
exported_items.append(link_44)


# Mate constraint: Coincident17 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_72 , SW name: M-410iB-300 -1/M-410iB-300-07-1 ,  SW ref.type:5 (2)
#   Entity 1: C::E name: body_70 , SW name: M-410iB-300 -1/M-410iB-300-08-1 ,  SW ref.type:5 (2)

link_45 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.0809607212164757,3.00995602354016,0.257774634285983)
dA = chrono.ChVectorD(0.0824751241424797,1.09694154801221e-16,0.996593123545252)
cB = chrono.ChVectorD(-0.0758729132832673,3.00995602354016,0.319253467484367)
dB = chrono.ChVectorD(-0.0824751241424794,3.71122403641788e-16,-0.996593123545252)
link_45.SetFlipped(True)
link_45.Initialize(body_72,body_70,False,cA,cB,dA,dB)
link_45.SetName("Coincident17")
exported_items.append(link_45)

link_46 = chrono.ChLinkMateGeneric()
link_46.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-0.0809607212164757,3.00995602354016,0.257774634285983)
cB = chrono.ChVectorD(-0.0758729132832673,3.00995602354016,0.319253467484367)
dA = chrono.ChVectorD(0.0824751241424797,1.09694154801221e-16,0.996593123545252)
dB = chrono.ChVectorD(-0.0824751241424794,3.71122403641788e-16,-0.996593123545252)
link_46.Initialize(body_72,body_70,False,cA,cB,dA,dB)
link_46.SetName("Coincident17")
exported_items.append(link_46)


# Mate constraint: Coincident18 [MateCoincident] type:0 align:1 flip:False
#   Entity 0: C::E name: body_63 , SW name: M-410iB-300 -1/M-410iB-300-02-1 ,  SW ref.type:2 (2)
#   Entity 1: C::E name: body_65 , SW name: M-410iB-300 -1/ArmBase-1 ,  SW ref.type:2 (2)

link_47 = chrono.ChLinkMateXdistance()
cA = chrono.ChVectorD(-0.140670357955037,2.04602671615662,0.37740311343739)
cB = chrono.ChVectorD(-0.382669423498732,2.04602671615662,0.37740311343739)
dA = chrono.ChVectorD(-1.32297045065857e-16,-1,1.10849259381635e-17)
dB = chrono.ChVectorD(0,1,0)
link_47.Initialize(body_63,body_65,False,cA,cB,dB)
link_47.SetDistance(0)
link_47.SetName("Coincident18")
exported_items.append(link_47)

link_48 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.140670357955037,2.04602671615662,0.37740311343739)
dA = chrono.ChVectorD(-1.32297045065857e-16,-1,1.10849259381635e-17)
cB = chrono.ChVectorD(-0.382669423498732,2.04602671615662,0.37740311343739)
dB = chrono.ChVectorD(0,1,0)
link_48.SetFlipped(True)
link_48.Initialize(body_63,body_65,False,cA,cB,dA,dB)
link_48.SetName("Coincident18")
exported_items.append(link_48)


# Mate constraint: Concentric1 [MateConcentric] type:1 align:0 flip:False
#   Entity 0: C::E name: body_63 , SW name: M-410iB-300 -1/M-410iB-300-02-1 ,  SW ref.type:1 (1)
#   Entity 1: C::E name: body_65 , SW name: M-410iB-300 -1/ArmBase-1 ,  SW ref.type:1 (1)

link_49 = chrono.ChLinkMateParallel()
cA = chrono.ChVectorD(-0.140670357955037,2.04755071615662,0.37740311343739)
dA = chrono.ChVectorD(1.32297045065857e-16,1,-1.10849259381635e-17)
cB = chrono.ChVectorD(-0.140670357955037,2.04602671615662,0.37740311343739)
dB = chrono.ChVectorD(0,1,0)
link_49.Initialize(body_63,body_65,False,cA,cB,dA,dB)
link_49.SetName("Concentric1")
exported_items.append(link_49)

link_50 = chrono.ChLinkMateGeneric()
link_50.SetConstrainedCoords(False, True, True, False, False, False)
cA = chrono.ChVectorD(-0.140670357955037,2.04755071615662,0.37740311343739)
cB = chrono.ChVectorD(-0.140670357955037,2.04602671615662,0.37740311343739)
dA = chrono.ChVectorD(1.32297045065857e-16,1,-1.10849259381635e-17)
dB = chrono.ChVectorD(0,1,0)
link_50.Initialize(body_63,body_65,False,cA,cB,dA,dB)
link_50.SetName("Concentric1")
exported_items.append(link_50)

